// BlueprintGeneratedClass BP_Phoebe_AIService_Loot.BP_Phoebe_AIService_Loot_C
// Size: 0x3c0 (Inherited: 0x3c0)
struct UBP_Phoebe_AIService_Loot_C : UAthenaAIServiceLoot {
};

