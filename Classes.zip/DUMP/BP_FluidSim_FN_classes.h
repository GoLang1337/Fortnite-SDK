// BlueprintGeneratedClass BP_FluidSim_FN.BP_FluidSim_FN_C
// Size: 0x628 (Inherited: 0x468)
struct ABP_FluidSim_FN_C : ABP_FluidSim_01_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x468(0x08)
	struct FFluidForceDynamic BoatForceSettings; // 0x470(0x70)
	struct FFluidForceDynamic PlayerForceSettings; // 0x4e0(0x70)
	struct FFluidForceDynamic MechForceSettings; // 0x550(0x70)
	struct TArray<struct AFortPawn*> RelevantFortPawns; // 0x5c0(0x10)
	bool Use FN Pawn Forces; // 0x5d0(0x01)
	char pad_5D1[0x7]; // 0x5d1(0x07)
	struct TMap<struct FGameplayTag, struct FFluidForceDynamic> VehicleTypeMap; // 0x5d8(0x50)

	void GetFortnitePawnForces(); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.GetFortnitePawnForces // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void GetLocalPawn(struct APawn*& Pawn); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.GetLocalPawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xccddc0
	void GetPlayerPawnForces(); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.GetPlayerPawnForces // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP_FluidSim_FN(int32_t EntryPoint); // Function BP_FluidSim_FN.BP_FluidSim_FN_C.ExecuteUbergraph_BP_FluidSim_FN // (Final|UbergraphFunction) // @ game+0xccddc0
};

