// WidgetBlueprintGeneratedClass BattlePassAlienTrooperCategoryTile.BattlePassAlienTrooperCategoryTile_C
// Size: 0x36d (Inherited: 0x320)
struct UBattlePassAlienTrooperCategoryTile_C : UFortBattlePassCustomSkinCategoryTile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x320(0x08)
	struct UImage* Image_Lock; // 0x328(0x08)
	struct UImage* Image_Progress; // 0x330(0x08)
	struct UImage* Image_Progress_Locked; // 0x338(0x08)
	struct UProgressBar* ProgressBar_2; // 0x340(0x08)
	struct UCommonVisibilitySwitcher* Switcher_State; // 0x348(0x08)
	struct UCommonRichTextBlock* Text_Progress; // 0x350(0x08)
	struct UCommonRichTextBlock* Text_Progress_Locked; // 0x358(0x08)
	struct UCommonRichTextBlock* Text_UnlockCondition; // 0x360(0x08)
	int32_t Number to unlock; // 0x368(0x04)
	bool Is locked; // 0x36c(0x01)

	void OnOwnedTilesUpdated(int32_t CurrentlyOwnedRewards, int32_t TotalRewards, float CategoryProgress); // Function BattlePassAlienTrooperCategoryTile.BattlePassAlienTrooperCategoryTile_C.OnOwnedTilesUpdated // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnLockedProgressUpdated(int32_t CurrentlyOwnedBeforeCategory, int32_t TotalRewardsBeforeCategory, float LockedProgress); // Function BattlePassAlienTrooperCategoryTile.BattlePassAlienTrooperCategoryTile_C.OnLockedProgressUpdated // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnLockedStateChanged(bool bCategoryLocked); // Function BattlePassAlienTrooperCategoryTile.BattlePassAlienTrooperCategoryTile_C.OnLockedStateChanged // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BattlePassAlienTrooperCategoryTile(int32_t EntryPoint); // Function BattlePassAlienTrooperCategoryTile.BattlePassAlienTrooperCategoryTile_C.ExecuteUbergraph_BattlePassAlienTrooperCategoryTile // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

