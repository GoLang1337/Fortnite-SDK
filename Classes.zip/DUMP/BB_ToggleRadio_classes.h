// BlueprintGeneratedClass BB_ToggleRadio.BB_ToggleRadio_C
// Size: 0x108 (Inherited: 0x108)
struct UBB_ToggleRadio_C : UFortMobileActionButtonBehavior_ToggleRadio {
};

