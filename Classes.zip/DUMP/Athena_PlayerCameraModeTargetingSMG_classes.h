// BlueprintGeneratedClass Athena_PlayerCameraModeTargetingSMG.Athena_PlayerCameraModeTargetingSMG_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeTargetingSMG_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

