// WidgetBlueprintGeneratedClass BPS18_LandingPage_SmallButton.BPS18_LandingPage_SmallButton_C
// Size: 0xd4c (Inherited: 0xc68)
struct UBPS18_LandingPage_SmallButton_C : UBattlePassLandingPageButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc68(0x08)
	struct UWidgetAnimation* Intro; // 0xc70(0x08)
	struct UWidgetAnimation* burst; // 0xc78(0x08)
	struct UWidgetAnimation* Selected_large; // 0xc80(0x08)
	struct UImage* Image_58; // 0xc88(0x08)
	struct UImage* Image_material; // 0xc90(0x08)
	struct UImage* Image_selected_LR; // 0xc98(0x08)
	struct UImage* Image_selected_TB; // 0xca0(0x08)
	struct UImage* Image_Shine; // 0xca8(0x08)
	struct USizeBox* SizeBox_BP; // 0xcb0(0x08)
	struct UCommonTextBlock* Text_Subtitle; // 0xcb8(0x08)
	struct UCommonTextBlock* Text_Title; // 0xcc0(0x08)
	struct FText In Text; // 0xcc8(0x18)
	struct FSlateColor In Color and Opacity; // 0xce0(0x28)
	struct UMaterialInterface* Material; // 0xd08(0x08)
	bool Show BP icon; // 0xd10(0x01)
	char pad_D11[0x7]; // 0xd11(0x07)
	struct FText In SubText; // 0xd18(0x18)
	struct FText Empty; // 0xd30(0x18)
	int32_t Title Font Size; // 0xd48(0x04)

	void Play intro(); // Function BPS18_LandingPage_SmallButton.BPS18_LandingPage_SmallButton_C.Play intro // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void PreConstruct(bool IsDesignTime); // Function BPS18_LandingPage_SmallButton.BPS18_LandingPage_SmallButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHovered(); // Function BPS18_LandingPage_SmallButton.BPS18_LandingPage_SmallButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function BPS18_LandingPage_SmallButton.BPS18_LandingPage_SmallButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnInitialized(); // Function BPS18_LandingPage_SmallButton.BPS18_LandingPage_SmallButton_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_LandingPage_SmallButton(int32_t EntryPoint); // Function BPS18_LandingPage_SmallButton.BPS18_LandingPage_SmallButton_C.ExecuteUbergraph_BPS18_LandingPage_SmallButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

