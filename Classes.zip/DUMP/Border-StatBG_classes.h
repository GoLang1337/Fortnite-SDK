// BlueprintGeneratedClass Border-StatBG.Border-StatBG_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-StatBG_C : UBorder-ShellTopBar_C {
};

