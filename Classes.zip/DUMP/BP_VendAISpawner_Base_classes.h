// BlueprintGeneratedClass BP_VendAISpawner_Base.BP_VendAISpawner_Base_C
// Size: 0x248 (Inherited: 0x220)
struct ABP_VendAISpawner_Base_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UNiagaraComponent* Niagara; // 0x228(0x08)
	float SpawnDelay; // 0x230(0x04)
	char pad_234[0x4]; // 0x234(0x04)
	struct FDataTableRowHandle EventRowHandle; // 0x238(0x10)

	void ReceiveBeginPlay(); // Function BP_VendAISpawner_Base.BP_VendAISpawner_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP_VendAISpawner_Base(int32_t EntryPoint); // Function BP_VendAISpawner_Base.BP_VendAISpawner_Base_C.ExecuteUbergraph_BP_VendAISpawner_Base // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

