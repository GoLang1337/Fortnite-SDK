// Class BlueCheeseUI.BlueCheeseWidgetBase
// Size: 0x328 (Inherited: 0x320)
struct UBlueCheeseWidgetBase : ULTMWidgetBase {
	struct AFortAthenaMutator_BlueCheese* CachedBlueCheeseMutator; // 0x320(0x08)

	void OnMutatorAvailable(struct AFortGameplayMutator* MutatorActor); // Function BlueCheeseUI.BlueCheeseWidgetBase.OnMutatorAvailable // (Native|Protected|BlueprintCallable) // @ game+0x3f2dc50
	void MutatorReady(); // Function BlueCheeseUI.BlueCheeseWidgetBase.MutatorReady // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	struct AFortAthenaMutator_BlueCheese* GetBlueCheeseMutator(); // Function BlueCheeseUI.BlueCheeseWidgetBase.GetBlueCheeseMutator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f2dc38
};

