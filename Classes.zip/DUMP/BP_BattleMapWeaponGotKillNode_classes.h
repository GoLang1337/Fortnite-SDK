// BlueprintGeneratedClass BP_BattleMapWeaponGotKillNode.BP_BattleMapWeaponGotKillNode_C
// Size: 0x358 (Inherited: 0x358)
struct ABP_BattleMapWeaponGotKillNode_C : ABP_BattleMapBaseNode_C {
};

