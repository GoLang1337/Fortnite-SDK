// WidgetBlueprintGeneratedClass BPS18_BattlePassScreen.BPS18_BattlePassScreen_C
// Size: 0xe01 (Inherited: 0xba8)
struct UBPS18_BattlePassScreen_C : UBattlePassScreenS18 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xba8(0x08)
	struct UWidgetAnimation* Intro; // 0xbb0(0x08)
	struct UWidgetAnimation* ViewRewardFraming; // 0xbb8(0x08)
	struct UWidgetAnimation* ShowPreviewAction; // 0xbc0(0x08)
	struct UWidgetAnimation* ShowVariantLabel; // 0xbc8(0x08)
	struct UWidgetAnimation* SeasonInformation; // 0xbd0(0x08)
	struct UWidgetAnimation* OnViewRewardAnimation; // 0xbd8(0x08)
	struct UBPS18_BattlePassRewardPage_C* BattlePassBonusRewardsS18; // 0xbe0(0x08)
	struct UBPS18_BulkClaimRewards_C* BattlePassBulkClaimRewards; // 0xbe8(0x08)
	struct UBPS18_BattlePassRewardPage_C* BattlePassCustomizationRewardsS18; // 0xbf0(0x08)
	struct UBPS18_LandingPages_C* BattlePassLandingPageS18; // 0xbf8(0x08)
	struct UBPS18_BattlePassRewardPage_C* BattlePassQuestsS18; // 0xc00(0x08)
	struct UBPS18_BattlePassRewardPage_C* BattlePassRewardOverviewS18; // 0xc08(0x08)
	struct UOverlay* BattlePassScreen; // 0xc10(0x08)
	struct UBPS18_AboutModal_C* BPS17_AboutModal; // 0xc18(0x08)
	struct UCommonRichTextBlock* CommonRichTextBlock; // 0xc20(0x08)
	struct UCommonRichTextBlock* CommonRichTextBlock_2; // 0xc28(0x08)
	struct UCommonRichTextBlock* CommonRichTextBlock_20; // 0xc30(0x08)
	struct UCommonRichTextBlock* CommonRichTextBlock_59; // 0xc38(0x08)
	struct USafeZone* currencies_position; // 0xc40(0x08)
	struct UImage* FakeHackGradient; // 0xc48(0x08)
	struct UOverlay* ForceBacchusMobileDownwards; // 0xc50(0x08)
	struct UHorizontalBox* HBox_Quest; // 0xc58(0x08)
	struct UImage* Icon_Currency_Cost; // 0xc60(0x08)
	struct UImage* Icon_Currency_Insufficient; // 0xc68(0x08)
	struct UImage* Image; // 0xc70(0x08)
	struct UImage* Image_2; // 0xc78(0x08)
	struct UImage* Image_3; // 0xc80(0x08)
	struct UImage* Image_8; // 0xc88(0x08)
	struct UImage* Image_79; // 0xc90(0x08)
	struct UImage* Image_95; // 0xc98(0x08)
	struct UImage* Image_141; // 0xca0(0x08)
	struct UImage* Image__ClaimedReward_progress; // 0xca8(0x08)
	struct UImage* Image_Lock_2; // 0xcb0(0x08)
	struct UImage* Image_Lock_7; // 0xcb8(0x08)
	struct UImage* Image_Prerequisite_progress; // 0xcc0(0x08)
	struct USizeBox* ItemDetailsContainer; // 0xcc8(0x08)
	struct USafeZone* LandingDescriptionPosition; // 0xcd0(0x08)
	struct UCommonTextBlock* LandingText_Description; // 0xcd8(0x08)
	struct UVerticalBox* LegalText; // 0xce0(0x08)
	struct UOverlay* Overlay_Currencies; // 0xce8(0x08)
	struct UOverlay* OwnsBattlePassContainer; // 0xcf0(0x08)
	struct UHorizontalBox* PlatformSharedButtons; // 0xcf8(0x08)
	struct UCommonRichTextBlock* RichText_ClaimedReward_Progress; // 0xd00(0x08)
	struct UCommonRichTextBlock* RichText_Prerequisite_Progress; // 0xd08(0x08)
	struct URichTextBlock* RichText_Title; // 0xd10(0x08)
	struct USafeZone* SafeZone_1; // 0xd18(0x08)
	struct USizeBox* SizeBox_119; // 0xd20(0x08)
	struct USizeBox* SizeBox_AlienArtifactInfo; // 0xd28(0x08)
	struct USizeBox* SizeBox_COntextualAction; // 0xd30(0x08)
	struct USizeBox* SizeBox_FreePassInfo; // 0xd38(0x08)
	struct UCommonVisibilitySwitcher* Switcher_Description_State_LandingPage; // 0xd40(0x08)
	struct USafeZone* SZButtonsAndLegal; // 0xd48(0x08)
	struct UBorder* Tag_BattlePass; // 0xd50(0x08)
	struct UBorder* Tag_ComingSoon; // 0xd58(0x08)
	struct UBorder* Tag_RequiresCustomizationSkin; // 0xd60(0x08)
	struct UCommonTextBlock* Text_Cost_Currency; // 0xd68(0x08)
	struct UCommonTextBlock* Text_Delayed; // 0xd70(0x08)
	struct UCommonTextBlock* Text_Legal_refund; // 0xd78(0x08)
	struct UCommonTextBlock* Text_NotEnough_Currency; // 0xd80(0x08)
	struct UCommonTextBlock* Text_Prerequisite; // 0xd88(0x08)
	struct UCommonTextBlock* Text_Tag_LandingPageComing; // 0xd90(0x08)
	struct UCommonBorder* VariantLabel; // 0xd98(0x08)
	struct UCommonTextBlock* VariantUnlockPreviewSet; // 0xda0(0x08)
	struct UVerticalBox* VerticalBox_currency; // 0xda8(0x08)
	struct UVerticalBox* VerticalBox_Description; // 0xdb0(0x08)
	struct UVerticalBox* VerticalBox_LandingText; // 0xdb8(0x08)
	struct UWrapBox* WrapBox_Tags; // 0xdc0(0x08)
	bool AutoPlayVideo; // 0xdc8(0x01)
	bool ForceAutoPlayVideo; // 0xdc9(0x01)
	char pad_DCA[0x2]; // 0xdca(0x02)
	struct FLinearColor MPC-ManualSunlightVector; // 0xdcc(0x10)
	struct FLinearColor MPC-ManualSunlightColor; // 0xddc(0x10)
	bool BP owned; // 0xdec(0x01)
	char pad_DED[0x3]; // 0xded(0x03)
	struct UMaterialInterface* Custom Skin Icon; // 0xdf0(0x08)
	struct UMaterialInterface* Battle Star Icon; // 0xdf8(0x08)
	bool HaveAllBpReward; // 0xe00(0x01)

	void Set landing Page text(struct FText Title, struct FText Description, int32_t State Index); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.Set landing Page text // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void HandleRewardTimelineAnimation(bool bAnimateRewardTimeline); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.HandleRewardTimelineAnimation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void HandleWatchVideoRequest(bool PlayFromDisc); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.HandleWatchVideoRequest // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void HandleViewReward(bool bInNoReward, int32_t InNumRewardsToPurchase); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.HandleViewReward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BP_OnActivated(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnRequestViewReward(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnRequestViewReward // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnRequestViewRewardComplete(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnRequestViewRewardComplete // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnVariantUpdate(int32_t CurrentIndex, int32_t TotalNumVariants); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnVariantUpdate // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnBattlePassViewChanged(enum class EBattlePassView NewView); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnBattlePassViewChanged // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnPreviewActionButtonUpdated(struct FText& RowDisplayName); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnPreviewActionButtonUpdated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void OnViewReward(struct FFortRarityItemData Rarity, bool bNoReward, struct UFortItemDefinition* RewardItem); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnViewReward // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnWatchVideo(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnWatchVideo // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_0_On show BP character__DelegateSignature(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_0_On show BP character__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_1_On show Custo Character__DelegateSignature(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_1_On show Custo Character__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_2_On show Mystery Character__DelegateSignature(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_2_On show Mystery Character__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_3_On show Bonus Character__DelegateSignature(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_3_On show Bonus Character__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_4_On show Crew Character__DelegateSignature(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_4_On show Crew Character__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_8_On show Buy BP__DelegateSignature(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_8_On show Buy BP__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_9_On show Buy Level__DelegateSignature(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_9_On show Buy Level__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_10_On show Gift Battle Pass__DelegateSignature(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_10_On show Gift Battle Pass__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void PreConstruct(bool IsDesignTime); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void OnSetPrerequisiteInfo(struct FText& Description, int32_t OwnedRewards, int32_t NeededRewards, bool bShowPrerequisiteLock); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnSetPrerequisiteInfo // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void OnBattlePassOwned(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnBattlePassOwned // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnSetClaimedRewardInfo(int32_t OwnedRewards, int32_t TotalRewards); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnSetClaimedRewardInfo // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnSetItemPrice(int32_t Cost, enum class EBattlePassCurrencyType CurrencyType); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnSetItemPrice // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnInsufficientFunds(enum class EBattlePassCurrencyType CurrencyType); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnInsufficientFunds // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnTransitionItemDetails(bool bTransitionForward); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnTransitionItemDetails // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void Construct(); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void OnItemDelayed(struct FTimespan Delay); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnItemDelayed // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnSetDynamicInput(enum class EBattlePassInputs InputType, struct UBattlePassInputData* InputData); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnSetDynamicInput // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnLevelChanged(int32_t Level); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.OnLevelChanged // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void SetTagVisibility(bool BattlePassRequiredVisible, bool ComingSoonVisible, bool CustomizationSkinRequiredVisible); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.SetTagVisibility // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_BattlePassScreen(int32_t EntryPoint); // Function BPS18_BattlePassScreen.BPS18_BattlePassScreen_C.ExecuteUbergraph_BPS18_BattlePassScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

