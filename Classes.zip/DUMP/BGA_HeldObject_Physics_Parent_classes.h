// BlueprintGeneratedClass BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C
// Size: 0x9a8 (Inherited: 0x898)
struct ABGA_HeldObject_Physics_Parent_C : ABuildingGameplayActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x898(0x08)
	struct UStaticMeshComponent* ParentMesh; // 0x8a0(0x08)
	struct UFortPhysicsObjectComponent* FortPhysicsObject; // 0x8a8(0x08)
	struct UFortLinkToActorComponent* FortLinkToActor; // 0x8b0(0x08)
	struct UFortHeldObjectComponent* FortHeldObject; // 0x8b8(0x08)
	int32_t RepStartMoving; // 0x8c0(0x04)
	struct FGameplayTag GC_HitPlayer; // 0x8c4(0x08)
	struct FGameplayTag GC_HitWorld; // 0x8cc(0x08)
	struct FGameplayTag GC_Throw; // 0x8d4(0x08)
	struct FGameplayTag GC_EnterWater; // 0x8dc(0x08)
	struct FGameplayTag GC_Pickup; // 0x8e4(0x08)
	struct FGameplayTag GC_Death; // 0x8ec(0x08)
	bool PlayDeathGC; // 0x8f4(0x01)
	bool RepHideActor; // 0x8f5(0x01)
	bool SetHideActorOnDeath; // 0x8f6(0x01)
	bool IsDestructable; // 0x8f7(0x01)
	struct FGameplayTag GC_GenericDeath; // 0x8f8(0x08)
	float WorldStopSlop; // 0x900(0x04)
	bool AttachToWallsAndCeilings; // 0x904(0x01)
	char pad_905[0x3]; // 0x905(0x03)
	struct FText FirstInteractString; // 0x908(0x18)
	struct FText SecondInteractString; // 0x920(0x18)
	float SecondInteractTime; // 0x938(0x04)
	float FirstInteractTime; // 0x93c(0x04)
	bool EverBeenThrownPlaced; // 0x940(0x01)
	enum class Enum_HeldObject_GenericWeights ObjectWeights; // 0x941(0x01)
	char pad_942[0x6]; // 0x942(0x06)
	struct FGameplayTagContainer ThrownQuestCreditTargetTag; // 0x948(0x20)
	struct FGameplayTagContainer TC_BlockPickup; // 0x968(0x20)
	float Hit Velocity Threshold; // 0x988(0x04)
	bool ShouldKillWhenSpawningUnderwater; // 0x98c(0x01)
	char pad_98D[0x3]; // 0x98d(0x03)
	struct UPrimitiveComponent* HitComponentToAttachTo; // 0x990(0x08)
	enum class ECollisionResponse CapsuleDefaultCollisionResponseToPawn; // 0x998(0x01)
	bool RestoreDefaultPawnCollisionOnInteract; // 0x999(0x01)
	char pad_99A[0x6]; // 0x99a(0x06)
	struct AActor* VehicleAttached; // 0x9a0(0x08)

	void IsInWater(bool InWater); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.IsInWater // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xcda090
	void SetBeenThrownPlaced(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.SetBeenThrownPlaced // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void GetCanFirstInteract(struct AFortPawn* InteractingPawn, bool Return); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.GetCanFirstInteract // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xcda090
	void GetAttachComponent(struct USceneComponent* Component); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.GetAttachComponent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xcda090
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xcda090
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xcda090
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnRep_RepHideActor(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.OnRep_RepHideActor // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnRep_RepStartMoving(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.OnRep_RepStartMoving // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xcda090
	void OnReady_0431BC1545476EBF2FA5ACBD6BB620A6(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer PlaylistContextTags); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.OnReady_0431BC1545476EBF2FA5ACBD6BB620A6 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_2_OnHeldObjectThrown__DelegateSignature(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_2_OnHeldObjectThrown__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void HideActor(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.HideActor // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void PlayGenericDeath(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.PlayGenericDeath // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult Hit); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.ReceiveHit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_0_OnLinkedActorDestroyed__DelegateSignature(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_0_OnLinkedActorDestroyed__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_6_OnHeldObjectPickedUp__DelegateSignature(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_6_OnHeldObjectPickedUp__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void ReceiveBeginPlay(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnFirstInteract(struct AFortPawn* Interacting Pawn); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.OnFirstInteract // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_5_OnHeldObjectPlaced__DelegateSignature(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.BndEvt__FortHeldObject_K2Node_ComponentBoundEvent_5_OnHeldObjectPlaced__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnSecondInteract(struct AFortPawn* InteractingPawn); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.OnSecondInteract // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveDestroyed(); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnEnterWater(struct FSphericalPontoon Pontoon); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.OnEnterWater // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BGA_HeldObject_Physics_Parent(int32_t EntryPoint); // Function BGA_HeldObject_Physics_Parent.BGA_HeldObject_Physics_Parent_C.ExecuteUbergraph_BGA_HeldObject_Physics_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

