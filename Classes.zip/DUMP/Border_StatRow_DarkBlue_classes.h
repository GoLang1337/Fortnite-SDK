// BlueprintGeneratedClass Border_StatRow_DarkBlue.Border_StatRow_DarkBlue_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_StatRow_DarkBlue_C : UCommonBorderStyle {
};

