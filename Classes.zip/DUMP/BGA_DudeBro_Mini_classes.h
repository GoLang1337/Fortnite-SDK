// BlueprintGeneratedClass BGA_DudeBro_Mini.BGA_DudeBro_Mini_C
// Size: 0xa59 (Inherited: 0x898)
struct ABGA_DudeBro_Mini_C : AFortAthenaLowGravZone {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x898(0x08)
	struct UAudioComponent* LoopingAmbAudio; // 0x8a0(0x08)
	struct UParticleSystemComponent* P_GeyserSteamBottom; // 0x8a8(0x08)
	struct UParticleSystemComponent* P_GeyserSteam; // 0x8b0(0x08)
	struct UStaticMeshComponent* S_FX_GeyserCone; // 0x8b8(0x08)
	struct UStaticMeshComponent* SM_CorruptedVent_A; // 0x8c0(0x08)
	struct USceneComponent* Scene; // 0x8c8(0x08)
	float Grow_Lerp_Control_4CC9621E45AEA6FFC645F1904E950F8D; // 0x8d0(0x04)
	enum class ETimelineDirection Grow__Direction_4CC9621E45AEA6FFC645F1904E950F8D; // 0x8d4(0x01)
	char pad_8D5[0x3]; // 0x8d5(0x03)
	struct UTimelineComponent* Grow; // 0x8d8(0x08)
	float Gravity; // 0x8e0(0x04)
	char pad_8E4[0x4]; // 0x8e4(0x04)
	struct UStaticMeshComponent* MeshComponent; // 0x8e8(0x08)
	struct UParticleSystemComponent* PrintingEffect; // 0x8f0(0x08)
	struct UParticleSystemComponent* RuneAmbientEffect; // 0x8f8(0x08)
	float DebrisSpawnRateScale; // 0x900(0x04)
	float SmokeSpawnRateScale; // 0x904(0x04)
	float EmberSpawnRateScale; // 0x908(0x04)
	float GlowSpawnRateScale; // 0x90c(0x04)
	float DebrisReset; // 0x910(0x04)
	char pad_914[0x4]; // 0x914(0x04)
	struct TArray<struct AActor*> TraceGroundIgnoredActors; // 0x918(0x10)
	bool IsAtRune; // 0x928(0x01)
	char pad_929[0x3]; // 0x929(0x03)
	struct FVector GroundLocation; // 0x92c(0x0c)
	bool EnableSafeZone; // 0x938(0x01)
	char pad_939[0x3]; // 0x939(0x03)
	float ZeroGravPrj; // 0x93c(0x04)
	struct FVector CubeLookDirection; // 0x940(0x0c)
	char pad_94C[0x4]; // 0x94c(0x04)
	struct TArray<struct AActor*> Overlaps; // 0x950(0x10)
	struct AActor* ZapTarget; // 0x960(0x08)
	struct FVector DirectionToPlayer; // 0x968(0x0c)
	struct FVector TraceEndLocation; // 0x974(0x0c)
	struct FVector TraceStartLocation; // 0x980(0x0c)
	float TraceMaxDistance; // 0x98c(0x04)
	struct FVector TraceHitLocation; // 0x990(0x0c)
	struct FVector TraceHitNormal; // 0x99c(0x0c)
	struct AFortPlayerPawn* ZapInstigator; // 0x9a8(0x08)
	struct FScalableFloat CubeZapStrength; // 0x9b0(0x28)
	bool TraceDown; // 0x9d8(0x01)
	char pad_9D9[0x3]; // 0x9d9(0x03)
	struct FLinearColor Base Bubbling Mesh Color; // 0x9dc(0x10)
	struct FLinearColor Geyser Illuminated Mesh Color; // 0x9ec(0x10)
	bool IsActive; // 0x9fc(0x01)
	char pad_9FD[0x3]; // 0x9fd(0x03)
	float GeyserContrast; // 0xa00(0x04)
	float UpwardLaunchVelocity; // 0xa04(0x04)
	struct USoundBase* SoundOnActivate; // 0xa08(0x08)
	struct USoundBase* SoundOnDeactivate; // 0xa10(0x08)
	bool ShouldBoost; // 0xa18(0x01)
	bool AllowEffects; // 0xa19(0x01)
	bool IsDisabled; // 0xa1a(0x01)
	bool EnabledLive; // 0xa1b(0x01)
	struct FVector Vent_1_loc; // 0xa1c(0x0c)
	float StartDisabledOffset; // 0xa28(0x04)
	float CharacterLaunchVelocity; // 0xa2c(0x04)
	bool ZOverride; // 0xa30(0x01)
	bool XYOverride; // 0xa31(0x01)
	char pad_A32[0x2]; // 0xa32(0x02)
	struct FVector SavedConeScale; // 0xa34(0x0c)
	struct FGameplayTag VolcanoCue; // 0xa40(0x08)
	struct FGameplayTag VentCue; // 0xa48(0x08)
	struct AActor* VehicleActor; // 0xa50(0x08)
	bool EditParticleSystems; // 0xa58(0x01)

	void OnRep_isDisabled(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.OnRep_isDisabled // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnRep_IsActive(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.OnRep_IsActive // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ToyExit(struct APhysicsBall_Master_C* Projectile); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.ToyExit // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ToyEnter(struct APhysicsBall_Master_C* Projectile); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.ToyEnter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ProjExit(struct AFortProjectileBase* Projectile); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.ProjExit // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ProjEnter(struct AFortProjectileBase* Projectile); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.ProjEnter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void UserConstructionScript(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Grow__FinishedFunc(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.Grow__FinishedFunc // (BlueprintEvent) // @ game+0xcda090
	void Grow__UpdateFunc(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.Grow__UpdateFunc // (BlueprintEvent) // @ game+0xcda090
	void OnReady_4FB5731B488F3EF6AE379C861ACDFAB8(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.OnReady_4FB5731B488F3EF6AE379C861ACDFAB8 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BndEvt__S_FX_GeyserCone_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.BndEvt__S_FX_GeyserCone_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xcda090
	void BndEvt__S_FX_GeyserCone_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.BndEvt__S_FX_GeyserCone_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void ActiveGeyser(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.ActiveGeyser // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void DeactivateGeyser(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.DeactivateGeyser // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SetGeiserActive(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.SetGeiserActive // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void GeiserTimeout(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.GeiserTimeout // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveBeginPlay(); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BGA_DudeBro_Mini(int32_t EntryPoint); // Function BGA_DudeBro_Mini.BGA_DudeBro_Mini_C.ExecuteUbergraph_BGA_DudeBro_Mini // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

