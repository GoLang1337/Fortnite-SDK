// BlueprintGeneratedClass ATM_parent_Container_Athena_NoSearch.ATM_parent_Container_Athena_NoSearch_C
// Size: 0xe01 (Inherited: 0xe01)
struct AATM_parent_Container_Athena_NoSearch_C : AHotfix_BuildingPropWithLootComp_Parent_C {
};

