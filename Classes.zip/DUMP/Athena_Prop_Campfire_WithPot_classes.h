// BlueprintGeneratedClass Athena_Prop_Campfire_WithPot.Athena_Prop_Campfire_WithPot_C
// Size: 0xcd0 (Inherited: 0xcb8)
struct AAthena_Prop_Campfire_WithPot_C : ABuildingProp {
	struct USceneComponent* SpawnLocation; // 0xcb8(0x08)
	struct UStaticMeshComponent* Stand; // 0xcc0(0x08)
	struct UStaticMeshComponent* Wood; // 0xcc8(0x08)
};

