// BlueprintGeneratedClass BP_ProjectileTrajectory_Athena_FloppingRabbit.BP_ProjectileTrajectory_Athena_FloppingRabbit_C
// Size: 0x269 (Inherited: 0x269)
struct ABP_ProjectileTrajectory_Athena_FloppingRabbit_C : ABP_ProjectileTrajectory_Athena_C {
};

