// BlueprintGeneratedClass ButtonStyle-TextOnlyBase_S-B.ButtonStyle-TextOnlyBase_S-B_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-TextOnlyBase_S-B_C : UButtonStyle-TextOnlyBase_C {
};

