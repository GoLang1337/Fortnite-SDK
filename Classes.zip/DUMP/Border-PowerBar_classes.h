// BlueprintGeneratedClass Border-PowerBar.Border-PowerBar_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-PowerBar_C : UCommonBorderStyle {
};

