// BlueprintGeneratedClass Athena_PlayerCameraModeTargeting_1P.Athena_PlayerCameraModeTargeting_1P_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeTargeting_1P_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

