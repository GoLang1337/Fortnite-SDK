// WidgetBlueprintGeneratedClass AthenaChatWidget.AthenaChatWidget_C
// Size: 0x3b8 (Inherited: 0x368)
struct UAthenaChatWidget_C : UAthenaActivatableChatWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x368(0x08)
	struct FDataTableRowHandle CloseUserListAction; // 0x370(0x10)
	struct FDataTableRowHandle OpenUserListAction; // 0x380(0x10)
	struct FDataTableRowHandle CurrentUserListAction; // 0x390(0x10)
	bool bEnteringChat; // 0x3a0(0x01)
	char pad_3A1[0x7]; // 0x3a1(0x07)
	struct FMulticastInlineDelegate OnEnteredChat; // 0x3a8(0x10)

	void FocusChat(bool bFocus); // Function AthenaChatWidget.AthenaChatWidget_C.FocusChat // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_AthenaChatWidget(int32_t EntryPoint); // Function AthenaChatWidget.AthenaChatWidget_C.ExecuteUbergraph_AthenaChatWidget // (Final|UbergraphFunction) // @ game+0xccddc0
	void OnEnteredChat__DelegateSignature(bool EnteredChat); // Function AthenaChatWidget.AthenaChatWidget_C.OnEnteredChat__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
};

