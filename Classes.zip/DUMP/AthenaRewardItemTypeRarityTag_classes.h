// WidgetBlueprintGeneratedClass AthenaRewardItemTypeRarityTag.AthenaRewardItemTypeRarityTag_C
// Size: 0x2c8 (Inherited: 0x2a8)
struct UAthenaRewardItemTypeRarityTag_C : UAthenaRewardItemTypeRarityTag {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a8(0x08)
	struct UBorder* Border_ItemType; // 0x2b0(0x08)
	struct FLinearColor ItemTypeTextColor; // 0x2b8(0x10)

	void OnInitializeRarityWithSeries(struct UFortItemSeriesDefinition* SeriesData); // Function AthenaRewardItemTypeRarityTag.AthenaRewardItemTypeRarityTag_C.OnInitializeRarityWithSeries // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnInitializeRarityWithoutSeries(struct FFortRarityItemData RarityData); // Function AthenaRewardItemTypeRarityTag.AthenaRewardItemTypeRarityTag_C.OnInitializeRarityWithoutSeries // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_AthenaRewardItemTypeRarityTag(int32_t EntryPoint); // Function AthenaRewardItemTypeRarityTag.AthenaRewardItemTypeRarityTag_C.ExecuteUbergraph_AthenaRewardItemTypeRarityTag // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

