// BlueprintGeneratedClass ButtonStyle-Com-LSkew.ButtonStyle-Com-LSkew_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Com-LSkew_C : UCommonButtonStyle {
};

