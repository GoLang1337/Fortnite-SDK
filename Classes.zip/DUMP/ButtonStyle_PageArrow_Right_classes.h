// BlueprintGeneratedClass ButtonStyle_PageArrow_Right.ButtonStyle_PageArrow_Right_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_PageArrow_Right_C : UButtonStyle-MediumTransparentNoCues_C {
};

