// BlueprintGeneratedClass Athena_CageSaddle_BallPrototype.Athena_CageSaddle_BallPrototype_C
// Size: 0x8f8 (Inherited: 0x8cc)
struct AAthena_CageSaddle_BallPrototype_C : ABGA_Athena_Physics_Parent_C {
	char pad_8CC[0x4]; // 0x8cc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x8d0(0x08)
	struct USceneComponent* Pivot; // 0x8d8(0x08)
	struct AFortPlayerPawn* MyOwner; // 0x8e0(0x08)
	bool Clipping; // 0x8e8(0x01)
	char pad_8E9[0x7]; // 0x8e9(0x07)
	struct FTimerHandle UpdateTimer; // 0x8f0(0x08)

	void UpdatePlayerPosition(); // Function Athena_CageSaddle_BallPrototype.Athena_CageSaddle_BallPrototype_C.UpdatePlayerPosition // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void TurnOn(); // Function Athena_CageSaddle_BallPrototype.Athena_CageSaddle_BallPrototype_C.TurnOn // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Turn Off(); // Function Athena_CageSaddle_BallPrototype.Athena_CageSaddle_BallPrototype_C.Turn Off // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_Athena_CageSaddle_BallPrototype(int32_t EntryPoint); // Function Athena_CageSaddle_BallPrototype.Athena_CageSaddle_BallPrototype_C.ExecuteUbergraph_Athena_CageSaddle_BallPrototype // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

