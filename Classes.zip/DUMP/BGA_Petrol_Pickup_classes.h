// BlueprintGeneratedClass BGA_Petrol_Pickup.BGA_Petrol_Pickup_C
// Size: 0xde1 (Inherited: 0xa80)
struct ABGA_Petrol_Pickup_C : ABGA_HeldObject_Parent_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa80(0x08)
	struct UNiagaraComponent* NS_Object_FloatingInWater; // 0xa88(0x08)
	struct UFortItemEntryComponent* FortItemEntry; // 0xa90(0x08)
	struct UStaticMeshComponent* PetrolCan; // 0xa98(0x08)
	struct USphereComponent* Sphere; // 0xaa0(0x08)
	struct AFortPlayerPawn* PlayerPawn; // 0xaa8(0x08)
	struct AFortPlayerControllerAthena* PlayerController; // 0xab0(0x08)
	bool ShouldExplode; // 0xab8(0x01)
	char pad_AB9[0x7]; // 0xab9(0x07)
	struct AFortPawn* ExplodeInstigator; // 0xac0(0x08)
	struct TArray<struct AActor*> TargetedActors; // 0xac8(0x10)
	struct FGameplayTag GC_Explode; // 0xad8(0x08)
	struct TArray<enum class EObjectTypeQuery> ObjectArray; // 0xae0(0x10)
	struct FScalableFloat SpawnedProjectileMinSpeed; // 0xaf0(0x28)
	struct FScalableFloat SpawnedProjectileMaxSpeed; // 0xb18(0x28)
	struct FScalableFloat ConeHalfAngleInDegrees; // 0xb40(0x28)
	struct ABuildingGameplayActor* CurieBGAtoSpawn; // 0xb68(0x08)
	struct AFortProjectileBase* CurieFireballsToSpawn; // 0xb70(0x08)
	struct FScalableFloat FireBallsToSpawn; // 0xb78(0x28)
	struct UFortWorldItemDefinition* WeaponItemDefinition; // 0xba0(0x08)
	struct AFortPickup* WeaponPickupToGrant; // 0xba8(0x08)
	struct FHitResult LastHit; // 0xbb0(0x88)
	struct FTimerHandle FuseTimerHandle; // 0xc38(0x08)
	struct FScalableFloat FuseMinDuration; // 0xc40(0x28)
	struct FScalableFloat FuseMaxDuration; // 0xc68(0x28)
	struct FGuid HeldItemGUID; // 0xc90(0x10)
	struct TScriptInterface<IFortInventoryOwnerInterface> HeldItemInventoryInterface; // 0xca0(0x10)
	bool IsAttachedToWeapon; // 0xcb0(0x01)
	bool Dropped; // 0xcb1(0x01)
	char pad_CB2[0x2]; // 0xcb2(0x02)
	struct FGameplayTag GC_OnFire; // 0xcb4(0x08)
	char pad_CBC[0x4]; // 0xcbc(0x04)
	struct FScalableFloat ExplosionRadius; // 0xcc0(0x28)
	struct FScalableFloat VehicleDamage; // 0xce8(0x28)
	struct AFortWeapon* WeaponAttachedTo; // 0xd10(0x08)
	struct FGameplayTag GC_Refuel; // 0xd18(0x08)
	struct TArray<enum class EObjectTypeQuery> SpawnCollisionCheck_ObjectTypes; // 0xd20(0x10)
	float Max_Spawn_Z; // 0xd30(0x04)
	bool SpawnCollisionBlocked; // 0xd34(0x01)
	char pad_D35[0x3]; // 0xd35(0x03)
	struct FVector VelocityAfterVehicleOverlap; // 0xd38(0x0c)
	char pad_D44[0x4]; // 0xd44(0x04)
	struct FScalableFloat HotfixExplodeVehicleImpulse; // 0xd48(0x28)
	struct FScalableFloat HotfixExplodeSpinThrust; // 0xd70(0x28)
	struct UGameplayEffect* GE_ExplodePlayerDamage; // 0xd98(0x08)
	struct UGameplayEffect* GE_ExplodeVehicleDamage; // 0xda0(0x08)
	struct UGameplayEffect* GE_ExplodeBuildingDamage; // 0xda8(0x08)
	bool FuseLit; // 0xdb0(0x01)
	char pad_DB1[0x3]; // 0xdb1(0x03)
	float MinSpeedOfNoStickBounce; // 0xdb4(0x04)
	struct USoundBase* FailedInteractSound; // 0xdb8(0x08)
	struct FGameplayTagContainer Tag_FailedInteract_InventoryIsFull; // 0xdc0(0x20)
	bool InWater; // 0xde0(0x01)

	void GetGameplayEffectClassForTarget(struct AActor* Target, struct UGameplayEffect*& GE Class); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.GetGameplayEffectClassForTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xccddc0
	bool BlueprintOnLocalInteract(struct AFortPlayerPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BlueprintOnLocalInteract // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void CalcVehicleImpulse(struct AActor* Vehicle, float Magnitude, struct FVector& Vector); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.CalcVehicleImpulse // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xccddc0
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnRep_LastHit(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnRep_LastHit // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnRep_ShouldExplode(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnRep_ShouldExplode // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xccddc0
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xccddc0
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float& OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xccddc0
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ReceiveDestroyed(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void SpawnCurieFireballs(struct AFortPawn* ExplodeInstigator); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.SpawnCurieFireballs // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnDeathServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void SetFuseAndDrop(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.SetFuseAndDrop // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SpawnFireBallsExplodeAndDie(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.SpawnFireBallsExplodeAndDie // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExplodeAndDie(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.ExplodeAndDie // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetHeldItemInfo(struct TScriptInterface<IFortInventoryOwnerInterface> InventoryInterface, struct FGuid Guid, struct AFortWeapon* WeaponAttachedTo); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.SetHeldItemInfo // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void DropHeldItem(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.DropHeldItem // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void HideAndDestroy(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.HideAndDestroy // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void (ServerOnly)HideAndDestroy(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.(ServerOnly)HideAndDestroy // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void Refuel(int32_t FuelToAdd); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.Refuel // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ReceiveBeginPlay(); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BndEvt__FortProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileBounceDelegate__DelegateSignature(struct FHitResult& ImpactResult, struct FVector& ImpactVelocity); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BndEvt__FortProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileBounceDelegate__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void OnCurieElementInteract_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag, struct FCurieInteractParamsHandle& InteractParamsHandle); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnCurieElementInteract_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void OnCurieElementInteractBegun_BP(struct FCurieContainerHandle CurieContainerHandle, struct FGameplayTag ElementTag, struct FCurieInteractParamsHandle& InteractParamsHandle); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnCurieElementInteractBegun_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void OnDamageServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void BndEvt__FortWaterInteraction_K2Node_ComponentBoundEvent_1_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BndEvt__FortWaterInteraction_K2Node_ComponentBoundEvent_1_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__FortWaterInteraction_K2Node_ComponentBoundEvent_2_WaterInteractionOnExitWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsLastBody); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.BndEvt__FortWaterInteraction_K2Node_ComponentBoundEvent_2_WaterInteractionOnExitWater__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BGA_Petrol_Pickup(int32_t EntryPoint); // Function BGA_Petrol_Pickup.BGA_Petrol_Pickup_C.ExecuteUbergraph_BGA_Petrol_Pickup // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

