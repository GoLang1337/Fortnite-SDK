// BlueprintGeneratedClass BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C
// Size: 0xf01 (Inherited: 0xe40)
struct ABP_ZippyTroutTrap_Floor_C : ABuildingTrapFloor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xe40(0x08)
	struct UParticleSystemComponent* P_ZippyTrout_Deploy_2; // 0xe48(0x08)
	struct UParticleSystemComponent* P_ZippyTrout_Idle1; // 0xe50(0x08)
	struct UParticleSystemComponent* P_ZippyTrout_Lightning2; // 0xe58(0x08)
	struct UParticleSystemComponent* P_ZippyTrout_Lightning; // 0xe60(0x08)
	struct UParticleSystemComponent* P_ZippyTrout_Idle; // 0xe68(0x08)
	struct UStaticMeshComponent* StaticMeshComponent01; // 0xe70(0x08)
	struct USceneComponent* TraceLocation3; // 0xe78(0x08)
	struct USceneComponent* TraceLocation2; // 0xe80(0x08)
	struct UBoxComponent* Trigger; // 0xe88(0x08)
	struct USceneComponent* Root; // 0xe90(0x08)
	struct USoundCue* Place_Trap_Sound; // 0xe98(0x08)
	struct USoundCue* Trap_Active_Sound; // 0xea0(0x08)
	struct USoundCue* Trap_Explode_Sound; // 0xea8(0x08)
	struct USoundCue* Trap_Fire_Sound; // 0xeb0(0x08)
	struct UMaterialInterface* FriendlyTrapMaterial; // 0xeb8(0x08)
	struct UMaterialInterface* NormalTrapMaterial; // 0xec0(0x08)
	bool bPlayFewerSounds; // 0xec8(0x01)
	char pad_EC9[0x7]; // 0xec9(0x07)
	struct TArray<struct FName> MuzzleSockets; // 0xed0(0x10)
	float Timespan of Jiggle; // 0xee0(0x04)
	struct FVector Vector of Jiggle; // 0xee4(0x0c)
	struct UParticleSystem* DestructionFX; // 0xef0(0x08)
	struct UAudioComponent* Active Loop Audio; // 0xef8(0x08)
	bool bIsFinishedBuilding; // 0xf00(0x01)

	void OnRep_bIsFinishedBuilding(); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.OnRep_bIsFinishedBuilding // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ChangeToNormalMaterial(); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.ChangeToNormalMaterial // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void  ChangeToFriendlyMaterial(); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C. ChangeToFriendlyMaterial // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnReloadEnd(); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.OnReloadEnd // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void OnPlaced(); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.OnPlaced // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void OnFinishedBuilding(); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.OnFinishedBuilding // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void GameplayCue.Abilities.Activation.Traps.ActivateTrap(enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.GameplayCue.Abilities.Activation.Traps.ActivateTrap // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnWorldReady(); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.OnWorldReady // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void OnInitTeam(); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.OnInitTeam // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void MuzzleFire(struct FName Socket Name); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.MuzzleFire // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void Jiggle(struct FVector Vector); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.Jiggle // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ReceiveDestroyed(); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP_ZippyTroutTrap_Floor(int32_t EntryPoint); // Function BP_ZippyTroutTrap_Floor.BP_ZippyTroutTrap_Floor_C.ExecuteUbergraph_BP_ZippyTroutTrap_Floor // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

