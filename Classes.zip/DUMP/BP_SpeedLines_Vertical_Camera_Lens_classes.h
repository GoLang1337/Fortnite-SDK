// BlueprintGeneratedClass BP_SpeedLines_Vertical_Camera_Lens.BP_SpeedLines_Vertical_Camera_Lens_C
// Size: 0x2e0 (Inherited: 0x2e0)
struct ABP_SpeedLines_Vertical_Camera_Lens_C : AEmitterCameraLensEffectBase {
};

