// BlueprintGeneratedClass AI_skill_phoebe_bot_emote.AI_skill_phoebe_bot_emote_C
// Size: 0x148 (Inherited: 0x148)
struct UAI_skill_phoebe_bot_emote_C : UFortAthenaAIBotEmoteSkillSet {
};

