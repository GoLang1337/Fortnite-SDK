// WidgetBlueprintGeneratedClass AthenaDirectAcquisitonDetails_BattlePassStarDetails.AthenaDirectAcquisitonDetails_BattlePassStarDetails_C
// Size: 0x280 (Inherited: 0x260)
struct UAthenaDirectAcquisitonDetails_BattlePassStarDetails_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UHorizontalBox* HB_BattlePassStarsSupplemental; // 0x268(0x08)
	struct UImage* Image_BattleStarSupplemental; // 0x270(0x08)
	struct UCommonTextBlock* T_BattleStarInfoSupplemental; // 0x278(0x08)

	void SetNumOfBattlePassStars(int32_t NumOfBattlePassStars); // Function AthenaDirectAcquisitonDetails_BattlePassStarDetails.AthenaDirectAcquisitonDetails_BattlePassStarDetails_C.SetNumOfBattlePassStars // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_AthenaDirectAcquisitonDetails_BattlePassStarDetails(int32_t EntryPoint); // Function AthenaDirectAcquisitonDetails_BattlePassStarDetails.AthenaDirectAcquisitonDetails_BattlePassStarDetails_C.ExecuteUbergraph_AthenaDirectAcquisitonDetails_BattlePassStarDetails // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

