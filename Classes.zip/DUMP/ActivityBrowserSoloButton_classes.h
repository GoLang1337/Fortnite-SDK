// WidgetBlueprintGeneratedClass ActivityBrowserSoloButton.ActivityBrowserSoloButton_C
// Size: 0xd81 (Inherited: 0xcc8)
struct UActivityBrowserSoloButton_C : UFortTextButton_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xcc8(0x08)
	struct UWidgetAnimation* Pressed; // 0xcd0(0x08)
	struct UWidgetAnimation* Hover; // 0xcd8(0x08)
	struct UBorder* ButtonMaterialBorder; // 0xce0(0x08)
	struct UHorizontalBox* ContentHB; // 0xce8(0x08)
	struct UBorder* DynamicPaddingBorder; // 0xcf0(0x08)
	struct USizeBox* MinSizesSB; // 0xcf8(0x08)
	struct FText Button Description; // 0xd00(0x18)
	float TextShearX; // 0xd18(0x04)
	float TextShearY; // 0xd1c(0x04)
	struct FMargin TextPadding; // 0xd20(0x10)
	bool IsDisabled; // 0xd30(0x01)
	char pad_D31[0x7]; // 0xd31(0x07)
	struct UMaterialInterface* ButtonMaterial; // 0xd38(0x08)
	float ButtonSharpnessX; // 0xd40(0x04)
	float ButtonSharpnessY; // 0xd44(0x04)
	float UseBoxScalingX; // 0xd48(0x04)
	float UseBoxScalingY; // 0xd4c(0x04)
	float ButtonBoxScaleSizeX; // 0xd50(0x04)
	float ButtonBoxScaleSizeY; // 0xd54(0x04)
	struct FName DisabledParamName; // 0xd58(0x08)
	struct FName SharpnessVParamName; // 0xd60(0x08)
	struct FName SharpnessUParamName; // 0xd68(0x08)
	struct FName UseBoxScaleUParamName; // 0xd70(0x08)
	struct FName UseBoxScaleVParamName; // 0xd78(0x08)
	bool HideButtonBackingOnGamepad; // 0xd80(0x01)

	void UpdateStylingOnInputType(enum class ECommonInputType Index); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.UpdateStylingOnInputType // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ResetMaterials(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.ResetMaterials // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ResetFontMaterial(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.ResetFontMaterial // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetButtonMaterial(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.SetButtonMaterial // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetText(struct FText Text); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.SetText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetTextStyle(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.SetTextStyle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void Finished_3B04A1D04A2128E7C8B3D5BC22792871(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.Finished_3B04A1D04A2128E7C8B3D5BC22792871 // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void PreConstruct(bool IsDesignTime); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void Construct(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHovered(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnClicked(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.BP_OnClicked // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnDisabled(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.BP_OnDisabled // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnEnabled(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.BP_OnEnabled // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnSelected(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnDeselected(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void EventOnInputMethodChanged(enum class ECommonInputType bNewInputType); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.EventOnInputMethodChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void Destruct(); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_ActivityBrowserSoloButton(int32_t EntryPoint); // Function ActivityBrowserSoloButton.ActivityBrowserSoloButton_C.ExecuteUbergraph_ActivityBrowserSoloButton // (Final|UbergraphFunction) // @ game+0xccddc0
};

