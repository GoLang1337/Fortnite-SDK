// BlueprintGeneratedClass ButtonStyle_Plus.ButtonStyle_Plus_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_Plus_C : UButtonStyle-MediumTransparentNoCues_C {
};

