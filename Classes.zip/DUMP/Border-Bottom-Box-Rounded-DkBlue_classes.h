// BlueprintGeneratedClass Border-Bottom-Box-Rounded-DkBlue.Border-Bottom-Box-Rounded-DkBlue_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-Bottom-Box-Rounded-DkBlue_C : UCommonBorderStyle {
};

