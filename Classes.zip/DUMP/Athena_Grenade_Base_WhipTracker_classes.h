// BlueprintGeneratedClass Athena_Grenade_Base_WhipTracker.Athena_Grenade_Base_WhipTracker_C
// Size: 0xf0 (Inherited: 0xf0)
struct UAthena_Grenade_Base_WhipTracker_C : UBulletWhipTrackerComponent_C {
};

