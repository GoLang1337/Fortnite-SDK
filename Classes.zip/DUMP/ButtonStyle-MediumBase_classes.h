// BlueprintGeneratedClass ButtonStyle-MediumBase.ButtonStyle-MediumBase_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-MediumBase_C : UButtonStyle-Base_C {
};

