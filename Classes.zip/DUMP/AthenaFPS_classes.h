// WidgetBlueprintGeneratedClass AthenaFPS.AthenaFPS_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct UAthenaFPS_C : UFortHUDElementWidget {
	struct UAthenaFPSTicker_C* AthenaFPSTicker; // 0x2c8(0x08)
};

