// BlueprintGeneratedClass BP_CaptureItem.BP_CaptureItem_C
// Size: 0x360 (Inherited: 0x230)
struct ABP_CaptureItem_C : AFortItemCaptureActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x230(0x08)
	struct UPointLightComponent* PointLight_Fill_SkylightComp1; // 0x238(0x08)
	struct UPointLightComponent* PointLight_Fill_SkylightComp; // 0x240(0x08)
	struct UPointLightComponent* PointLight_Fill_Right; // 0x248(0x08)
	struct UPointLightComponent* PointLight_RimTopLeft; // 0x250(0x08)
	struct UPointLightComponent* PointLight_Rim_Topright; // 0x258(0x08)
	struct USpotLightComponent* SpotLight_Key; // 0x260(0x08)
	struct UPointLightComponent* PointLight_Rim_Bottom; // 0x268(0x08)
	struct UCameraComponent* Camera; // 0x270(0x08)
	struct USkeletalMeshComponent* Wrapping_Papper_Aligned_Temp; // 0x278(0x08)
	struct USkeletalMeshComponent* SK_SCAR_Temp; // 0x280(0x08)
	struct UArrowComponent* ArrowScar_Rotate; // 0x288(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x290(0x08)
	enum class ETimelineDirection Play_Reaction_Effects__Direction_9574FA204C8F1705D11D02837101ACE9; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
	struct UTimelineComponent* Play Reaction Effects; // 0x2a0(0x08)
	float Timeline_PanCamera_Lerp_BC75346B47960E00A7D11BAE8EDAE242; // 0x2a8(0x04)
	enum class ETimelineDirection Timeline_PanCamera__Direction_BC75346B47960E00A7D11BAE8EDAE242; // 0x2ac(0x01)
	char pad_2AD[0x3]; // 0x2ad(0x03)
	struct UTimelineComponent* Timeline_PanCamera; // 0x2b0(0x08)
	struct AActor* Current_Item; // 0x2b8(0x08)
	struct USkeletalMeshComponentBudgeted* AxeMesh; // 0x2c0(0x08)
	char pad_2C8[0x8]; // 0x2c8(0x08)
	struct FTransform LargeTile_Wrap_Transform; // 0x2d0(0x30)
	struct FTransform LargeTile_Wrap_Transform_B; // 0x300(0x30)
	struct FTransform SmallTile_Wrap_Transform; // 0x330(0x30)

	void OnWrapAsyncLoaded(); // Function BP_CaptureItem.BP_CaptureItem_C.OnWrapAsyncLoaded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void CreateWrapPreview(struct AActor*& WrapActor); // Function BP_CaptureItem.BP_CaptureItem_C.CreateWrapPreview // (Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetIsLarge(bool Is Large Tile); // Function BP_CaptureItem.BP_CaptureItem_C.SetIsLarge // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetWrapIsGun(bool WrapIsGun); // Function BP_CaptureItem.BP_CaptureItem_C.SetWrapIsGun // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void UserConstructionScript(); // Function BP_CaptureItem.BP_CaptureItem_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void Timeline_PanCamera__FinishedFunc(); // Function BP_CaptureItem.BP_CaptureItem_C.Timeline_PanCamera__FinishedFunc // (BlueprintEvent) // @ game+0xccddc0
	void Timeline_PanCamera__UpdateFunc(); // Function BP_CaptureItem.BP_CaptureItem_C.Timeline_PanCamera__UpdateFunc // (BlueprintEvent) // @ game+0xccddc0
	void Play Reaction Effects__FinishedFunc(); // Function BP_CaptureItem.BP_CaptureItem_C.Play Reaction Effects__FinishedFunc // (BlueprintEvent) // @ game+0xccddc0
	void Play Reaction Effects__UpdateFunc(); // Function BP_CaptureItem.BP_CaptureItem_C.Play Reaction Effects__UpdateFunc // (BlueprintEvent) // @ game+0xccddc0
	void Play Reaction Effects__Weapon Fire__EventFunc(); // Function BP_CaptureItem.BP_CaptureItem_C.Play Reaction Effects__Weapon Fire__EventFunc // (BlueprintEvent) // @ game+0xccddc0
	void OnSetupCapture(struct UFortItemThumbnailRenderer* InRenderer, struct UFortItemDefinition* InItemDefinition); // Function BP_CaptureItem.BP_CaptureItem_C.OnSetupCapture // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ReceiveBeginPlay(); // Function BP_CaptureItem.BP_CaptureItem_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ReceiveDestroyed(); // Function BP_CaptureItem.BP_CaptureItem_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void Start Reaction Effects(); // Function BP_CaptureItem.BP_CaptureItem_C.Start Reaction Effects // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP_CaptureItem(int32_t EntryPoint); // Function BP_CaptureItem.BP_CaptureItem_C.ExecuteUbergraph_BP_CaptureItem // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

