// BlueprintGeneratedClass BP_BattleMapBaseEdge.BP_BattleMapBaseEdge_C
// Size: 0x288 (Inherited: 0x278)
struct ABP_BattleMapBaseEdge_C : ABattleMapEdge {
	struct USplineMeshComponent* SplineMesh; // 0x278(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x280(0x08)
};

