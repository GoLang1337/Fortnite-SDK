// BlueprintGeneratedClass AthenaFrontEndMiniMapManager.AthenaFrontEndMiniMapManager_C
// Size: 0x458 (Inherited: 0x450)
struct AAthenaFrontEndMiniMapManager_C : AFortFrontEndMiniMapManager {
	struct USceneComponent* DefaultSceneRoot; // 0x450(0x08)
};

