// WidgetBlueprintGeneratedClass AthenaFPSTicker.AthenaFPSTicker_C
// Size: 0x2a8 (Inherited: 0x2a8)
struct UAthenaFPSTicker_C : UAthenaFPSBase {
};

