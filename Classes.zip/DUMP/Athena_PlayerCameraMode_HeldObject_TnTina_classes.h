// BlueprintGeneratedClass Athena_PlayerCameraMode_HeldObject_TnTina.Athena_PlayerCameraMode_HeldObject_TnTina_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraMode_HeldObject_TnTina_C : UAthena_PlayerCameraMode_HeldObject_C {
};

