// BlueprintGeneratedClass BP_AISC_Inv_DangerGrape.BP_AISC_Inv_DangerGrape_C
// Size: 0xb8 (Inherited: 0xa8)
struct UBP_AISC_Inv_DangerGrape_C : UFortAthenaAISpawnerDataComponent_RandomInventory {
	struct FItemAndCount PlayerWeapon; // 0xa8(0x10)

	void GetInventoryItems(struct TArray<struct FItemAndCount> OutList); // Function BP_AISC_Inv_DangerGrape.BP_AISC_Inv_DangerGrape_C.GetInventoryItems // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
};

