// BlueprintGeneratedClass BGA_Athena_Keycard_Lock_OilRig.BGA_Athena_Keycard_Lock_OilRig_C
// Size: 0xae9 (Inherited: 0xae9)
struct ABGA_Athena_Keycard_Lock_OilRig_C : ABGA_Athena_Keycard_Lock_Parent_C {
};

