// BlueprintGeneratedClass BP_BattleMapGroundMoveNode.BP_BattleMapGroundMoveNode_C
// Size: 0x368 (Inherited: 0x358)
struct ABP_BattleMapGroundMoveNode_C : ABattleMapGroundMoveNode {
	struct UStaticMeshComponent* StaticMesh; // 0x358(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x360(0x08)
};

