// BlueprintGeneratedClass BP_CameraShake_Lava_Bounce.BP_CameraShake_Lava_Bounce_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UBP_CameraShake_Lava_Bounce_C : UMatineeCameraShake {
};

