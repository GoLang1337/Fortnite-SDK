// BlueprintGeneratedClass Athena_PlayerCameraModeRocket.Athena_PlayerCameraModeRocket_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeRocket_C : UAthena_PlayerCameraModeRanged_C {
};

