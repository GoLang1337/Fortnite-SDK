// BlueprintGeneratedClass Border-SolidBG-Purple.Border-SolidBG-Purple_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-SolidBG-Purple_C : UBorder-ShellTopBar_C {
};

