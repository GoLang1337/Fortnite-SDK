// WidgetBlueprintGeneratedClass AccountPinLinkingWindow.AccountPinLinkingWindow_C
// Size: 0x610 (Inherited: 0x5f8)
struct UAccountPinLinkingWindow_C : UFortAccountPinLinkingWindow {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5f8(0x08)
	struct UImage* Image_84; // 0x600(0x08)
	struct UImage* Image_256; // 0x608(0x08)

	void BndEvt__Switcher_Main_K2Node_ComponentBoundEvent_0_OnActiveWidgetChanged__DelegateSignature(struct UWidget* ActiveWidget, int32_t ActiveWidgetIndex); // Function AccountPinLinkingWindow.AccountPinLinkingWindow_C.BndEvt__Switcher_Main_K2Node_ComponentBoundEvent_0_OnActiveWidgetChanged__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_AccountPinLinkingWindow(int32_t EntryPoint); // Function AccountPinLinkingWindow.AccountPinLinkingWindow_C.ExecuteUbergraph_AccountPinLinkingWindow // (Final|UbergraphFunction) // @ game+0xccddc0
};

