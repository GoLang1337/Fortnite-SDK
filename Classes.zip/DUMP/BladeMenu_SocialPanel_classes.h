// WidgetBlueprintGeneratedClass BladeMenu_SocialPanel.BladeMenu_SocialPanel_C
// Size: 0x3a8 (Inherited: 0x388)
struct UBladeMenu_SocialPanel_C : UFortBladeMenu_SocialPanel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x388(0x08)
	struct UWidgetAnimation* OnClose; // 0x390(0x08)
	struct UWidgetAnimation* OnOpen; // 0x398(0x08)
	struct USafeZone* SafeZone_Content; // 0x3a0(0x08)

	void OnOpened(); // Function BladeMenu_SocialPanel.BladeMenu_SocialPanel_C.OnOpened // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnClosed(); // Function BladeMenu_SocialPanel.BladeMenu_SocialPanel_C.OnClosed // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnInitialized(); // Function BladeMenu_SocialPanel.BladeMenu_SocialPanel_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void OnCloseAnimationFinished(); // Function BladeMenu_SocialPanel.BladeMenu_SocialPanel_C.OnCloseAnimationFinished // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BladeMenu_SocialPanel(int32_t EntryPoint); // Function BladeMenu_SocialPanel.BladeMenu_SocialPanel_C.ExecuteUbergraph_BladeMenu_SocialPanel // (Final|UbergraphFunction) // @ game+0xccddc0
};

