// WidgetBlueprintGeneratedClass AthenaMainMenuLeaveButton.AthenaMainMenuLeaveButton_C
// Size: 0xcf8 (Inherited: 0xcf8)
struct UAthenaMainMenuLeaveButton_C : UFortMainMenuLeaveButton {
};

