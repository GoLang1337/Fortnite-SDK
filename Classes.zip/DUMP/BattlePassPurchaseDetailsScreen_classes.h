// WidgetBlueprintGeneratedClass BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C
// Size: 0x498 (Inherited: 0x348)
struct UBattlePassPurchaseDetailsScreen_C : UCommonActivatableWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x348(0x08)
	struct UWidgetAnimation* OnLogoIntro; // 0x350(0x08)
	struct UWidgetAnimation* FadeToSubs_Smoother; // 0x358(0x08)
	struct UWidgetAnimation* FadeBacktoBP; // 0x360(0x08)
	struct UWidgetAnimation* SetActivatedState; // 0x368(0x08)
	struct UWidgetAnimation* ShowComicBubble_Landing; // 0x370(0x08)
	struct UWidgetAnimation* ReverseShowPurchaseConfirmation; // 0x378(0x08)
	struct UWidgetAnimation* OnShowPurchaseConfirmation_Final; // 0x380(0x08)
	struct UWidgetAnimation* ShowComicBubble_Confirmation; // 0x388(0x08)
	struct UWidgetAnimation* ShowCallouts; // 0x390(0x08)
	struct UFortLazyImage* BottomImage; // 0x398(0x08)
	struct UFortLazyImage* CenterLeftImage; // 0x3a0(0x08)
	struct UFortLazyImage* CenterRightImage; // 0x3a8(0x08)
	struct UFortLazyImage* CenterTopLeftImage; // 0x3b0(0x08)
	struct UFortLazyImage* CenterTopRightImage; // 0x3b8(0x08)
	struct UCommonRichTextBlock* CommonRichTextBlock_164; // 0x3c0(0x08)
	struct UImage* Copy; // 0x3c8(0x08)
	struct UDonut_ComicBubble_C* Donut_ComicBubble_Confirmation; // 0x3d0(0x08)
	struct UDonut_ComicBubble_C* Donut_ComicBubble_Landing; // 0x3d8(0x08)
	struct UImage* Glow; // 0x3e0(0x08)
	struct UImage* Image_2; // 0x3e8(0x08)
	struct UImage* Image_62; // 0x3f0(0x08)
	struct UImage* Image_Glow; // 0x3f8(0x08)
	struct UImage* Image_Glow_2; // 0x400(0x08)
	struct UImage* Image_Sideways; // 0x408(0x08)
	struct USizeBox* LargeTriangles; // 0x410(0x08)
	struct UImage* LargeTriangles_Left; // 0x418(0x08)
	struct UImage* LargeTriangles_Right; // 0x420(0x08)
	struct UImage* OrangeTri; // 0x428(0x08)
	struct UImage* OrangeTri_2; // 0x430(0x08)
	struct USafeZone* SafeZone_1; // 0x438(0x08)
	struct UImage* Shadow; // 0x440(0x08)
	struct USizeBox* SmallTriangles; // 0x448(0x08)
	struct UImage* SmallTriangles_Left; // 0x450(0x08)
	struct UImage* SmallTriangles_Right; // 0x458(0x08)
	struct UVerticalBox* TagsVB; // 0x460(0x08)
	struct UFortLazyImage* TopLeftImage; // 0x468(0x08)
	struct UFortLazyImage* TopRightImage; // 0x470(0x08)
	struct UImage* YellowTri; // 0x478(0x08)
	struct UImage* YellowTri_2; // 0x480(0x08)
	struct UWidgetAnimation* BPTransitionAnim; // 0x488(0x08)
	struct UAudioComponent* IntroSound; // 0x490(0x08)

	void OnScreenIntro(); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.OnScreenIntro // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetImageBrushMaterials(); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.SetImageBrushMaterials // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void AnimateBackToNormalState(); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.AnimateBackToNormalState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void HideFinalPurchaseConfirmation(); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.HideFinalPurchaseConfirmation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ShowFinalPurchaseConfirmation(); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.ShowFinalPurchaseConfirmation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void TriggerSubsTransition(); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.TriggerSubsTransition // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BP_OnActivated(); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void Construct(); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void IntroAudio(); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.IntroAudio // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void Destruct(); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BattlePassPurchaseDetailsScreen(int32_t EntryPoint); // Function BattlePassPurchaseDetailsScreen.BattlePassPurchaseDetailsScreen_C.ExecuteUbergraph_BattlePassPurchaseDetailsScreen // (Final|UbergraphFunction) // @ game+0xccddc0
};

