// WidgetBlueprintGeneratedClass BattlePassScreenS17.BattlePassScreenS17_C
// Size: 0xdc9 (Inherited: 0xb80)
struct UBattlePassScreenS17_C : UBattlePassScreenS17 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb80(0x08)
	struct UWidgetAnimation* Intro; // 0xb88(0x08)
	struct UWidgetAnimation* ViewRewardFraming; // 0xb90(0x08)
	struct UWidgetAnimation* ShowPreviewAction; // 0xb98(0x08)
	struct UWidgetAnimation* ShowVariantLabel; // 0xba0(0x08)
	struct UWidgetAnimation* SeasonInformation; // 0xba8(0x08)
	struct UWidgetAnimation* OnViewRewardAnimation; // 0xbb0(0x08)
	struct UBattlePassAlienTrooperPage_C* BattlePassAlienTrooperPage; // 0xbb8(0x08)
	struct UBattlePassRewardOverviewS17_C* BattlePassBonusRewardsS17; // 0xbc0(0x08)
	struct UBPS17_BulkClaimRewards_C* BattlePassBulkClaimRewards; // 0xbc8(0x08)
	struct UBattlePassLandingPages17_C* BattlePassLandingPageS17; // 0xbd0(0x08)
	struct UBattlePassRewardOverviewS17_C* BattlePassQuestsS17; // 0xbd8(0x08)
	struct UBattlePassRewardOverviewS17_C* BattlePassRewardOverviewS17; // 0xbe0(0x08)
	struct UOverlay* BattlePassScreen; // 0xbe8(0x08)
	struct UBPS17_AboutModal_C* BPS17_AboutModal; // 0xbf0(0x08)
	struct UCommonRichTextBlock* CommonRichTextBlock; // 0xbf8(0x08)
	struct UCommonRichTextBlock* CommonRichTextBlock_2; // 0xc00(0x08)
	struct UCommonRichTextBlock* CommonRichTextBlock_20; // 0xc08(0x08)
	struct UCommonRichTextBlock* CommonRichTextBlock_59; // 0xc10(0x08)
	struct USafeZone* currencies_position; // 0xc18(0x08)
	struct UImage* FakeHackGradient; // 0xc20(0x08)
	struct UOverlay* ForceBacchusMobileDownwards; // 0xc28(0x08)
	struct UHorizontalBox* HBox_Quest; // 0xc30(0x08)
	struct UImage* Icon_Currency_Cost; // 0xc38(0x08)
	struct UImage* Icon_Currency_Insufficient; // 0xc40(0x08)
	struct UImage* Image; // 0xc48(0x08)
	struct UImage* Image_2; // 0xc50(0x08)
	struct UImage* Image_3; // 0xc58(0x08)
	struct UImage* Image_8; // 0xc60(0x08)
	struct UImage* Image_79; // 0xc68(0x08)
	struct UImage* Image_95; // 0xc70(0x08)
	struct UImage* Image_141; // 0xc78(0x08)
	struct UImage* Image__ClaimedReward_progress; // 0xc80(0x08)
	struct UImage* Image_Lock_2; // 0xc88(0x08)
	struct UImage* Image_Lock_7; // 0xc90(0x08)
	struct UImage* Image_Prerequisite_progress; // 0xc98(0x08)
	struct USizeBox* ItemDetailsContainer; // 0xca0(0x08)
	struct USafeZone* LandingDescriptionPosition; // 0xca8(0x08)
	struct UCommonTextBlock* LandingText_Description; // 0xcb0(0x08)
	struct UVerticalBox* LegalText; // 0xcb8(0x08)
	struct UOverlay* Overlay_Currencies; // 0xcc0(0x08)
	struct UOverlay* OwnsBattlePassContainer; // 0xcc8(0x08)
	struct UHorizontalBox* PlatformSharedButtons; // 0xcd0(0x08)
	struct UCommonRichTextBlock* RichText_ClaimedReward_Progress; // 0xcd8(0x08)
	struct UCommonRichTextBlock* RichText_Prerequisite_Progress; // 0xce0(0x08)
	struct URichTextBlock* RichText_Title; // 0xce8(0x08)
	struct USafeZone* SafeZone_1; // 0xcf0(0x08)
	struct USizeBox* SizeBox_119; // 0xcf8(0x08)
	struct USizeBox* SizeBox_AlienArtifactInfo; // 0xd00(0x08)
	struct USizeBox* SizeBox_COntextualAction; // 0xd08(0x08)
	struct USizeBox* SizeBox_FreePassInfo; // 0xd10(0x08)
	struct UCommonVisibilitySwitcher* Switcher_Description_State_LandingPage; // 0xd18(0x08)
	struct USafeZone* SZButtonsAndLegal; // 0xd20(0x08)
	struct UBorder* Tag_BattlePass; // 0xd28(0x08)
	struct UBorder* Tag_ComingSoon; // 0xd30(0x08)
	struct UCommonTextBlock* Text_Cost_Currency; // 0xd38(0x08)
	struct UCommonTextBlock* Text_Delayed; // 0xd40(0x08)
	struct UCommonTextBlock* Text_Legal_refund; // 0xd48(0x08)
	struct UCommonTextBlock* Text_NotEnough_Currency; // 0xd50(0x08)
	struct UCommonTextBlock* Text_Tag_LandingPageComing; // 0xd58(0x08)
	struct UCommonBorder* VariantLabel; // 0xd60(0x08)
	struct UCommonTextBlock* VariantUnlockPreviewSet; // 0xd68(0x08)
	struct UVerticalBox* VerticalBox_currency; // 0xd70(0x08)
	struct UVerticalBox* VerticalBox_Description; // 0xd78(0x08)
	struct UVerticalBox* VerticalBox_LandingText; // 0xd80(0x08)
	struct UWrapBox* WrapBox_Tags; // 0xd88(0x08)
	bool AutoPlayVideo; // 0xd90(0x01)
	bool ForceAutoPlayVideo; // 0xd91(0x01)
	char pad_D92[0x2]; // 0xd92(0x02)
	struct FLinearColor MPC-ManualSunlightVector; // 0xd94(0x10)
	struct FLinearColor MPC-ManualSunlightColor; // 0xda4(0x10)
	bool BP owned; // 0xdb4(0x01)
	char pad_DB5[0x3]; // 0xdb5(0x03)
	struct UMaterialInterface* Custom Skin Icon; // 0xdb8(0x08)
	struct UMaterialInterface* Battle Star Icon; // 0xdc0(0x08)
	bool HaveAllBpReward; // 0xdc8(0x01)

	void Set landing Page text(struct FText Title, struct FText Description, int32_t State Index); // Function BattlePassScreenS17.BattlePassScreenS17_C.Set landing Page text // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void HandleRewardTimelineAnimation(bool bAnimateRewardTimeline); // Function BattlePassScreenS17.BattlePassScreenS17_C.HandleRewardTimelineAnimation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void HandleWatchVideoRequest(bool PlayFromDisc); // Function BattlePassScreenS17.BattlePassScreenS17_C.HandleWatchVideoRequest // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void HandleViewReward(bool bInNoReward, int32_t InNumRewardsToPurchase); // Function BattlePassScreenS17.BattlePassScreenS17_C.HandleViewReward // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BP_OnActivated(); // Function BattlePassScreenS17.BattlePassScreenS17_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnRequestViewReward(); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnRequestViewReward // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnRequestViewRewardComplete(); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnRequestViewRewardComplete // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnVariantUpdate(int32_t CurrentIndex, int32_t TotalNumVariants); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnVariantUpdate // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnBattlePassViewChanged(enum class EBattlePassView NewView); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnBattlePassViewChanged // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnPreviewActionButtonUpdated(struct FText RowDisplayName); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnPreviewActionButtonUpdated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void OnViewReward(struct FFortRarityItemData Rarity, bool bNoReward, struct UFortItemDefinition* RewardItem); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnViewReward // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnWatchVideo(); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnWatchVideo // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_0_On show BP character__DelegateSignature(); // Function BattlePassScreenS17.BattlePassScreenS17_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_0_On show BP character__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_1_On show Custo Character__DelegateSignature(); // Function BattlePassScreenS17.BattlePassScreenS17_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_1_On show Custo Character__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_2_On show Mystery Character__DelegateSignature(); // Function BattlePassScreenS17.BattlePassScreenS17_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_2_On show Mystery Character__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_3_On show Bonus Character__DelegateSignature(); // Function BattlePassScreenS17.BattlePassScreenS17_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_3_On show Bonus Character__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_4_On show Crew Character__DelegateSignature(); // Function BattlePassScreenS17.BattlePassScreenS17_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_4_On show Crew Character__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_8_On show Buy BP__DelegateSignature(); // Function BattlePassScreenS17.BattlePassScreenS17_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_8_On show Buy BP__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_9_On show Buy Level__DelegateSignature(); // Function BattlePassScreenS17.BattlePassScreenS17_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_9_On show Buy Level__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_10_On show Gift Battle Pass__DelegateSignature(); // Function BattlePassScreenS17.BattlePassScreenS17_C.BndEvt__BattlePassLandingPages17_K2Node_ComponentBoundEvent_10_On show Gift Battle Pass__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void PreConstruct(bool IsDesignTime); // Function BattlePassScreenS17.BattlePassScreenS17_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnSetPrerequisiteInfo(struct FText Description, int32_t OwnedRewards, int32_t NeededRewards); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnSetPrerequisiteInfo // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void OnBattlePassOwned(); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnBattlePassOwned // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnSetClaimedRewardInfo(int32_t OwnedRewards, int32_t TotalRewards); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnSetClaimedRewardInfo // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnSetItemPrice(int32_t Cost, enum class EBattlePassCurrencyType CurrencyType); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnSetItemPrice // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnInsufficientFunds(enum class EBattlePassCurrencyType CurrencyType); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnInsufficientFunds // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnTransitionItemDetails(bool bTransitionForward); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnTransitionItemDetails // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void Construct(); // Function BattlePassScreenS17.BattlePassScreenS17_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnItemDelayed(struct FTimespan Delay); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnItemDelayed // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnSetDynamicInput(enum class EBattlePassInputs InputType, struct UBattlePassInputData* InputData); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnSetDynamicInput // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnLevelChanged(int32_t Level); // Function BattlePassScreenS17.BattlePassScreenS17_C.OnLevelChanged // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BattlePassScreenS17(int32_t EntryPoint); // Function BattlePassScreenS17.BattlePassScreenS17_C.ExecuteUbergraph_BattlePassScreenS17 // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

