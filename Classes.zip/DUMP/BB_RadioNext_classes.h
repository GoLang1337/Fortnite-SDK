// BlueprintGeneratedClass BB_RadioNext.BB_RadioNext_C
// Size: 0xf8 (Inherited: 0xf8)
struct UBB_RadioNext_C : UFortMobileActionButtonBehavior {
};

