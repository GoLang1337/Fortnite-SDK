// BlueprintGeneratedClass BP_DeimosRift.BP_DeimosRift_C
// Size: 0xb7c (Inherited: 0x9c8)
struct ABP_DeimosRift_C : ABuildingRift {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9c8(0x08)
	struct UParticleSystemComponent* P_Rift_IdleFog; // 0x9d0(0x08)
	struct UStaticMeshComponent* SM_CubeRunes; // 0x9d8(0x08)
	struct UAudioComponent* Deimos_Spawner_Loop_Sound; // 0x9e0(0x08)
	struct UStaticMeshComponent* FogMesh; // 0x9e8(0x08)
	struct UBoxComponent* NoBuildZone; // 0x9f0(0x08)
	struct UParticleSystemComponent* P_Deimos_Rift_Dying; // 0x9f8(0x08)
	struct UStaticMeshComponent* CosmeticBaseMesh; // 0xa00(0x08)
	struct UParticleSystemComponent* P_Deimos_RiftSpawn_DamageState; // 0xa08(0x08)
	struct UStaticMeshComponent* CubeMesh; // 0xa10(0x08)
	struct UPointLightComponent* PointLight; // 0xa18(0x08)
	struct UMaterialInstanceDynamic* MaskedMID; // 0xa20(0x08)
	struct UMaterialInstanceDynamic* OpaqueMID; // 0xa28(0x08)
	struct UMaterialInstanceDynamic* CubeMat; // 0xa30(0x08)
	struct UMaterialInstanceDynamic* CubeMatLOD1; // 0xa38(0x08)
	struct UMaterialInterface* BaseMaterial; // 0xa40(0x08)
	struct UGameplayEffect* GE_Destroyed; // 0xa48(0x08)
	struct FGameplayCueParameters CueParamsChargeUp; // 0xa50(0xc0)
	int32_t DamageState; // 0xb10(0x04)
	char pad_B14[0x4]; // 0xb14(0x04)
	struct UMaterialInterface* BaseLODMaterial; // 0xb18(0x08)
	struct UMaterialInterface* BaseMeshMat; // 0xb20(0x08)
	struct USoundBase* Sound_StageOneExplode; // 0xb28(0x08)
	struct USoundBase* Sound_StageTwoExplode; // 0xb30(0x08)
	struct USoundBase* Sound_DeimosSpawnerLoop; // 0xb38(0x08)
	struct USoundBase* Sound_StageThreeBuildup; // 0xb40(0x08)
	struct UGameplayEffect* GE_DamagePerSpawn; // 0xb48(0x08)
	struct UGameplayEffect* GE_DamageReduction; // 0xb50(0x08)
	bool DoSpawnEffects; // 0xb58(0x01)
	char pad_B59[0x3]; // 0xb59(0x03)
	float SpawnAnimDuration; // 0xb5c(0x04)
	struct FGameplayTag FiendSpawnFXGC; // 0xb60(0x08)
	struct FGameplayTag ChargeUpFXGC; // 0xb68(0x08)
	struct FGameplayTag SpawnFXGC; // 0xb70(0x08)
	float HitAnimLength; // 0xb78(0x04)

	void Get Spawn Meshes(struct TArray<struct UStaticMeshComponent*>& Meshes); // Function BP_DeimosRift.BP_DeimosRift_C.Get Spawn Meshes // (Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void FlashCubeMaterial(float Length); // Function BP_DeimosRift.BP_DeimosRift_C.FlashCubeMaterial // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnRep_DamageState(); // Function BP_DeimosRift.BP_DeimosRift_C.OnRep_DamageState // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void UserConstructionScript(); // Function BP_DeimosRift.BP_DeimosRift_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BP_Cosmetic_RampUp(); // Function BP_DeimosRift.BP_DeimosRift_C.BP_Cosmetic_RampUp // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnDeathPlayEffects(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BP_DeimosRift.BP_DeimosRift_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void OnDeathServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BP_DeimosRift.BP_DeimosRift_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void BP_Cosmetic_Intro(); // Function BP_DeimosRift.BP_DeimosRift_C.BP_Cosmetic_Intro // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_Cosmetic_Idle(); // Function BP_DeimosRift.BP_DeimosRift_C.BP_Cosmetic_Idle // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnStartedEncounterSpawn(struct AFortAIPawn* SpawnedAI); // Function BP_DeimosRift.BP_DeimosRift_C.OnStartedEncounterSpawn // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ReceiveBeginPlay(); // Function BP_DeimosRift.BP_DeimosRift_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnDamaged_Bind(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BP_DeimosRift.BP_DeimosRift_C.OnDamaged_Bind // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BP_Cosmetic_ShouldDie(); // Function BP_DeimosRift.BP_DeimosRift_C.BP_Cosmetic_ShouldDie // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnBuildingRiftSpawnedAI_Bind(); // Function BP_DeimosRift.BP_DeimosRift_C.OnBuildingRiftSpawnedAI_Bind // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void StartDynamicRiftSpawnCosmetics(); // Function BP_DeimosRift.BP_DeimosRift_C.StartDynamicRiftSpawnCosmetics // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SpawnEffects(); // Function BP_DeimosRift.BP_DeimosRift_C.SpawnEffects // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void UpdateDamageState(float HealthPercent); // Function BP_DeimosRift.BP_DeimosRift_C.UpdateDamageState // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP_DeimosRift(int32_t EntryPoint); // Function BP_DeimosRift.BP_DeimosRift_C.ExecuteUbergraph_BP_DeimosRift // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

