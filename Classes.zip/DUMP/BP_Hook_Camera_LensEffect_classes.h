// BlueprintGeneratedClass BP_Hook_Camera_LensEffect.BP_Hook_Camera_LensEffect_C
// Size: 0x2e0 (Inherited: 0x2e0)
struct ABP_Hook_Camera_LensEffect_C : AEmitterCameraLensEffectBase {
};

