// WidgetBlueprintGeneratedClass BuiltInEmotePopUP.BuiltInEmotePopUP_C
// Size: 0x378 (Inherited: 0x358)
struct UBuiltInEmotePopUP_C : UFortStoreSkinDetailsPopup {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x358(0x08)
	struct UWidgetAnimation* FadeAnim; // 0x360(0x08)
	struct UWidgetAnimation* IntroAnim; // 0x368(0x08)
	struct UBorder* Border_ItemRarity; // 0x370(0x08)

	void RequestFadeIn(); // Function BuiltInEmotePopUP.BuiltInEmotePopUP_C.RequestFadeIn // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void RequuestFadeOut(); // Function BuiltInEmotePopUP.BuiltInEmotePopUP_C.RequuestFadeOut // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BuiltInEmotePopUP(int32_t EntryPoint); // Function BuiltInEmotePopUP.BuiltInEmotePopUP_C.ExecuteUbergraph_BuiltInEmotePopUP // (Final|UbergraphFunction) // @ game+0xccddc0
};

