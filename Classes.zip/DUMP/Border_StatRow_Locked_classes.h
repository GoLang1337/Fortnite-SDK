// BlueprintGeneratedClass Border_StatRow_Locked.Border_StatRow_Locked_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_StatRow_Locked_C : UCommonBorderStyle {
};

