// WidgetBlueprintGeneratedClass AffiliateEntry.AffiliateEntry_C
// Size: 0xc40 (Inherited: 0xc40)
struct UAffiliateEntry_C : UFortAffiliateEntry {
};

