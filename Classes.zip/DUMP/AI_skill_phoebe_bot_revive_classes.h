// BlueprintGeneratedClass AI_skill_phoebe_bot_revive.AI_skill_phoebe_bot_revive_C
// Size: 0xa8 (Inherited: 0xa8)
struct UAI_skill_phoebe_bot_revive_C : UFortAthenaAIBotReviveSkillSet {
};

