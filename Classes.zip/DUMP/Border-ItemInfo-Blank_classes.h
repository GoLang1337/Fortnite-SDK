// BlueprintGeneratedClass Border-ItemInfo-Blank.Border-ItemInfo-Blank_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-ItemInfo-Blank_C : UBorder-ItemInfo-Unlocked_C {
};

