// BlueprintGeneratedClass AISpawnerData_DangerGrape.AISpawnerData_DangerGrape_C
// Size: 0xe0 (Inherited: 0xe0)
struct UAISpawnerData_DangerGrape_C : UBP_AISpawnerData_Phoebe_C {
};

