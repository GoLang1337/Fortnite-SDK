// WidgetBlueprintGeneratedClass BPS18_BattlePassRewardPage.BPS18_BattlePassRewardPage_C
// Size: 0x508 (Inherited: 0x4c8)
struct UBPS18_BattlePassRewardPage_C : UBattlePassRewardPageS18 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4c8(0x08)
	struct UWidgetAnimation* Intro; // 0x4d0(0x08)
	struct UWidgetAnimation* Header_intro; // 0x4d8(0x08)
	struct UImage* Image_86; // 0x4e0(0x08)
	struct USafeZone* SafeZone_1; // 0x4e8(0x08)
	struct UCommonTextBlock* Subtitle; // 0x4f0(0x08)
	struct UCommonTextBlock* Title; // 0x4f8(0x08)
	struct UVerticalBox* VerticalBox_24; // 0x500(0x08)

	void SequenceEvent__ENTRYPOINTBPS18_BattlePassRewardPage_1(struct UPageNavigator_C* PageNavigator); // Function BPS18_BattlePassRewardPage.BPS18_BattlePassRewardPage_C.SequenceEvent__ENTRYPOINTBPS18_BattlePassRewardPage_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void PageNavigator_Event_1(struct UPageNavigator_C* PageNavigator); // Function BPS18_BattlePassRewardPage.BPS18_BattlePassRewardPage_C.PageNavigator_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnPageChanged(int32_t PageNumber); // Function BPS18_BattlePassRewardPage.BPS18_BattlePassRewardPage_C.OnPageChanged // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void BP_OnActivated(); // Function BPS18_BattlePassRewardPage.BPS18_BattlePassRewardPage_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnInputMethodChanged(enum class ECommonInputType InputType); // Function BPS18_BattlePassRewardPage.BPS18_BattlePassRewardPage_C.OnInputMethodChanged // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnInitForPageType(enum class ERewardPageType InRewardPageType); // Function BPS18_BattlePassRewardPage.BPS18_BattlePassRewardPage_C.OnInitForPageType // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_BattlePassRewardPage(int32_t EntryPoint); // Function BPS18_BattlePassRewardPage.BPS18_BattlePassRewardPage_C.ExecuteUbergraph_BPS18_BattlePassRewardPage // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

