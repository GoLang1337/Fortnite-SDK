// BlueprintGeneratedClass ButtonStyle-Tab-Secondary.ButtonStyle-Tab-Secondary_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Tab-Secondary_C : UCommonButtonStyle {
};

