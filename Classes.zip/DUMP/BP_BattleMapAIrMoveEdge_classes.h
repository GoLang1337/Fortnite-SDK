// BlueprintGeneratedClass BP_BattleMapAIrMoveEdge.BP_BattleMapAIrMoveEdge_C
// Size: 0x288 (Inherited: 0x288)
struct ABP_BattleMapAIrMoveEdge_C : ABP_BattleMapBaseEdge_C {
};

