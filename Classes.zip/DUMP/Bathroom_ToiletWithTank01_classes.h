// BlueprintGeneratedClass Bathroom_ToiletWithTank01.Bathroom_ToiletWithTank01_C
// Size: 0xcb8 (Inherited: 0xcb8)
struct ABathroom_ToiletWithTank01_C : ABuildingProp {
};

