// BlueprintGeneratedClass ButtonStyle_TransparentList.ButtonStyle_TransparentList_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_TransparentList_C : UCommonButtonStyle {
};

