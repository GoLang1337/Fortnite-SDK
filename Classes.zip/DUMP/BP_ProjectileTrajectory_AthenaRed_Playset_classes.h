// BlueprintGeneratedClass BP_ProjectileTrajectory_AthenaRed_Playset.BP_ProjectileTrajectory_AthenaRed_Playset_C
// Size: 0x300 (Inherited: 0x2f0)
struct ABP_ProjectileTrajectory_AthenaRed_Playset_C : ABP_ProjectileTrajectory_Athena_SnapBoxToGrid_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2f0(0x08)
	struct UAudioComponent* Creative_Grenade_LoopRed_Cue; // 0x2f8(0x08)

	void ReceiveBeginPlay(); // Function BP_ProjectileTrajectory_AthenaRed_Playset.BP_ProjectileTrajectory_AthenaRed_Playset_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ReceiveDestroyed(); // Function BP_ProjectileTrajectory_AthenaRed_Playset.BP_ProjectileTrajectory_AthenaRed_Playset_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BP_ProjectileTrajectory_AthenaRed_Playset(int32_t EntryPoint); // Function BP_ProjectileTrajectory_AthenaRed_Playset.BP_ProjectileTrajectory_AthenaRed_Playset_C.ExecuteUbergraph_BP_ProjectileTrajectory_AthenaRed_Playset // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

