// BlueprintGeneratedClass BP_Pawn_DangerGrape.BP_Pawn_DangerGrape_C
// Size: 0x4988 (Inherited: 0x4978)
struct ABP_Pawn_DangerGrape_C : ABP_PlayerPawn_Athena_Phoebe_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4978(0x08)
	struct UParticleSystemComponent* Effect_Hologram; // 0x4980(0x08)

	void ReceiveBeginPlay(); // Function BP_Pawn_DangerGrape.BP_Pawn_DangerGrape_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnDeathPlayEffects(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BP_Pawn_DangerGrape.BP_Pawn_DangerGrape_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void PlayResOut_2(); // Function BP_Pawn_DangerGrape.BP_Pawn_DangerGrape_C.PlayResOut_2 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BP_Pawn_DangerGrape(int32_t EntryPoint); // Function BP_Pawn_DangerGrape.BP_Pawn_DangerGrape_C.ExecuteUbergraph_BP_Pawn_DangerGrape // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

