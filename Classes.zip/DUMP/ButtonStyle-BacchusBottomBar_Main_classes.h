// BlueprintGeneratedClass ButtonStyle-BacchusBottomBar_Main.ButtonStyle-BacchusBottomBar_Main_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-BacchusBottomBar_Main_C : UCommonButtonStyle {
};

