// BlueprintGeneratedClass BP_BattleMapTimeIndicator.BP_BattleMapTimeIndicator_C
// Size: 0x298 (Inherited: 0x288)
struct ABP_BattleMapTimeIndicator_C : ABattleMapTimeIndicator {
	struct UStaticMeshComponent* Arrow; // 0x288(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x290(0x08)
};

