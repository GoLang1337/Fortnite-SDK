// BlueprintGeneratedClass BP_Frontend_EventLevel_NavObject.BP_Frontend_EventLevel_NavObject_C
// Size: 0x4d0 (Inherited: 0x4d0)
struct ABP_Frontend_EventLevel_NavObject_C : AFortEventLevelNavigationActor {
};

