// BlueprintGeneratedClass Border_DarkBlue_VGrad.Border_DarkBlue_VGrad_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_DarkBlue_VGrad_C : UCommonBorderStyle {
};

