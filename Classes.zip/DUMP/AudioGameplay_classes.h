// Class AudioGameplay.AudioGameplayComponent
// Size: 0xb8 (Inherited: 0xb0)
struct UAudioGameplayComponent : UActorComponent {
	char pad_B0[0x8]; // 0xb0(0x08)
};

