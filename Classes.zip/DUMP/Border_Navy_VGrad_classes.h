// BlueprintGeneratedClass Border_Navy_VGrad.Border_Navy_VGrad_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_Navy_VGrad_C : UCommonBorderStyle {
};

