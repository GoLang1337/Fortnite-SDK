// BlueprintGeneratedClass Athena_PlayerCameraModeBucketNice.Athena_PlayerCameraModeBucketNice_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeBucketNice_C : UAthena_PlayerCameraModeRanged_C {
};

