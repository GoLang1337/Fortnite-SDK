// BlueprintGeneratedClass ButtonStyle-Tab-Main-S11.ButtonStyle-Tab-Main-S11_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Tab-Main-S11_C : UCommonButtonStyle {
};

