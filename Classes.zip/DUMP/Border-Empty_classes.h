// BlueprintGeneratedClass Border-Empty.Border-Empty_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-Empty_C : UCommonBorderStyle {
};

