// BlueprintGeneratedClass Athena_GameState.Athena_GameState_C
// Size: 0x2d00 (Inherited: 0x2ce8)
struct AAthena_GameState_C : AFortGameStateBR {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2ce8(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2cf0(0x08)
	struct USoundBase* Victory_Royale_Sound; // 0x2cf8(0x08)

	void OnWinnerAnnounced(); // Function Athena_GameState.Athena_GameState_C.OnWinnerAnnounced // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_Athena_GameState(int32_t EntryPoint); // Function Athena_GameState.Athena_GameState_C.ExecuteUbergraph_Athena_GameState // (Final|UbergraphFunction) // @ game+0xcda090
};

