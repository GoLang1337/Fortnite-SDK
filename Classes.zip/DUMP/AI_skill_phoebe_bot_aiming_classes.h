// BlueprintGeneratedClass AI_skill_phoebe_bot_aiming.AI_skill_phoebe_bot_aiming_C
// Size: 0x8c0 (Inherited: 0x8c0)
struct UAI_skill_phoebe_bot_aiming_C : UFortAthenaAIBotAimingSkillSet {
};

