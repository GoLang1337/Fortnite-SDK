// WidgetBlueprintGeneratedClass AthenaStatsRow.AthenaStatsRow_C
// Size: 0x2c8 (Inherited: 0x2c0)
struct UAthenaStatsRow_C : UFortProfileStatsRow {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)

	void SetStatValueAsText(struct FText StatValue); // Function AthenaStatsRow.AthenaStatsRow_C.SetStatValueAsText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void PreConstruct(bool IsDesignTime); // Function AthenaStatsRow.AthenaStatsRow_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_AthenaStatsRow(int32_t EntryPoint); // Function AthenaStatsRow.AthenaStatsRow_C.ExecuteUbergraph_AthenaStatsRow // (Final|UbergraphFunction) // @ game+0xcda090
};

