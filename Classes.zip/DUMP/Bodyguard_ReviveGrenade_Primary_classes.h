// BlueprintGeneratedClass Bodyguard_ReviveGrenade_Primary.Bodyguard_ReviveGrenade_Primary_C
// Size: 0xe2c (Inherited: 0xe2c)
struct UBodyguard_ReviveGrenade_Primary_C : UGA_Athena_DanceGrenade_WithTrajectory_C {
};

