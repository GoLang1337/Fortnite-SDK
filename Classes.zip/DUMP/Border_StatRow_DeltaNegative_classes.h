// BlueprintGeneratedClass Border_StatRow_DeltaNegative.Border_StatRow_DeltaNegative_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_StatRow_DeltaNegative_C : UCommonBorderStyle {
};

