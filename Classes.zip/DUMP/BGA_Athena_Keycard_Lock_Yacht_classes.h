// BlueprintGeneratedClass BGA_Athena_Keycard_Lock_Yacht.BGA_Athena_Keycard_Lock_Yacht_C
// Size: 0xae9 (Inherited: 0xae9)
struct ABGA_Athena_Keycard_Lock_Yacht_C : ABGA_Athena_Keycard_Lock_Parent_C {
};

