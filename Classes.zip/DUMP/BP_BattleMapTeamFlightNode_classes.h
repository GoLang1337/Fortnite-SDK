// BlueprintGeneratedClass BP_BattleMapTeamFlightNode.BP_BattleMapTeamFlightNode_C
// Size: 0x358 (Inherited: 0x358)
struct ABP_BattleMapTeamFlightNode_C : ABP_BattleMapBaseNode_C {
};

