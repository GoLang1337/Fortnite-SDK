// BlueprintGeneratedClass BP_BattleMapAirMoveNode.BP_BattleMapAirMoveNode_C
// Size: 0x368 (Inherited: 0x358)
struct ABP_BattleMapAirMoveNode_C : ABattleMapGroundMoveNode {
	struct UStaticMeshComponent* StaticMesh; // 0x358(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x360(0x08)
};

