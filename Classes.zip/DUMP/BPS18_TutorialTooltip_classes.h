// WidgetBlueprintGeneratedClass BPS18_TutorialTooltip.BPS18_TutorialTooltip_C
// Size: 0x390 (Inherited: 0x298)
struct UBPS18_TutorialTooltip_C : UFortBattlePassTutorialTooltipS18 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)
	struct UWidgetAnimation* burstLoop; // 0x2a0(0x08)
	struct UWidgetAnimation* Show; // 0x2a8(0x08)
	struct UHorizontalBox* HorizontalBoxcontent; // 0x2b0(0x08)
	struct UImage* Icon; // 0x2b8(0x08)
	struct UImage* Image_Arrow; // 0x2c0(0x08)
	struct FText In Text; // 0x2c8(0x18)
	struct FSlateBrush In Brush; // 0x2e0(0x88)
	enum class EHorizontalAlignment In Horizontal Alignment; // 0x368(0x01)
	enum class EVerticalAlignment In Vertical Alignment; // 0x369(0x01)
	char pad_36A[0x2]; // 0x36a(0x02)
	struct FWidgetTransform In Transform; // 0x36c(0x1c)
	bool Show Icon; // 0x388(0x01)
	char pad_389[0x3]; // 0x389(0x03)
	float Right; // 0x38c(0x04)

	void PreConstruct(bool IsDesignTime); // Function BPS18_TutorialTooltip.BPS18_TutorialTooltip_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ShowTooltip(); // Function BPS18_TutorialTooltip.BPS18_TutorialTooltip_C.ShowTooltip // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void HideTooltip(); // Function BPS18_TutorialTooltip.BPS18_TutorialTooltip_C.HideTooltip // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_TutorialTooltip(int32_t EntryPoint); // Function BPS18_TutorialTooltip.BPS18_TutorialTooltip_C.ExecuteUbergraph_BPS18_TutorialTooltip // (Final|UbergraphFunction) // @ game+0xccddc0
};

