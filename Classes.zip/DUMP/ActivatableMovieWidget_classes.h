// WidgetBlueprintGeneratedClass ActivatableMovieWidget.ActivatableMovieWidget_C
// Size: 0x5a0 (Inherited: 0x590)
struct UActivatableMovieWidget_C : UFortActivatableVideoPanel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x590(0x08)
	struct USafeZone* MainSafeZone; // 0x598(0x08)

	void Construct(); // Function ActivatableMovieWidget.ActivatableMovieWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_ActivatableMovieWidget(int32_t EntryPoint); // Function ActivatableMovieWidget.ActivatableMovieWidget_C.ExecuteUbergraph_ActivatableMovieWidget // (Final|UbergraphFunction) // @ game+0xcda090
};

