// BlueprintGeneratedClass BGA_Pickup_Dummy_GravyGoblin.BGA_Pickup_Dummy_GravyGoblin_C
// Size: 0x8f0 (Inherited: 0x8cc)
struct ABGA_Pickup_Dummy_GravyGoblin_C : ABGA_Athena_Physics_Parent_C {
	char pad_8CC[0x4]; // 0x8cc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x8d0(0x08)
	bool Thrown; // 0x8d8(0x01)
	char pad_8D9[0x7]; // 0x8d9(0x07)
	struct UFortWorldItemDefinition* ItemDef; // 0x8e0(0x08)
	struct AFortPickup* AttachedPickup; // 0x8e8(0x08)

	void OnRep_Thrown(); // Function BGA_Pickup_Dummy_GravyGoblin.BGA_Pickup_Dummy_GravyGoblin_C.OnRep_Thrown // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BndEvt__ParentMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult Hit); // Function BGA_Pickup_Dummy_GravyGoblin.BGA_Pickup_Dummy_GravyGoblin_C.BndEvt__ParentMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xcda090
	void Detach(struct FVector NewLocation); // Function BGA_Pickup_Dummy_GravyGoblin.BGA_Pickup_Dummy_GravyGoblin_C.Detach // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Throw(); // Function BGA_Pickup_Dummy_GravyGoblin.BGA_Pickup_Dummy_GravyGoblin_C.Throw // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BGA_Pickup_Dummy_GravyGoblin(int32_t EntryPoint); // Function BGA_Pickup_Dummy_GravyGoblin.BGA_Pickup_Dummy_GravyGoblin_C.ExecuteUbergraph_BGA_Pickup_Dummy_GravyGoblin // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

