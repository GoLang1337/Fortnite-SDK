// WidgetBlueprintGeneratedClass BP_SkewedTabButton.BP_SkewedTabButton_C
// Size: 0xc78 (Inherited: 0xc40)
struct UBP_SkewedTabButton_C : UAthenaSkewedTabButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc40(0x08)
	struct UWidgetAnimation* Unhovered; // 0xc48(0x08)
	struct UWidgetAnimation* Hovered; // 0xc50(0x08)
	struct UWidgetAnimation* Selected; // 0xc58(0x08)
	struct UImage* No-Count-1; // 0xc60(0x08)
	struct FLinearColor RGB1 Text Color; // 0xc68(0x10)

	void BP_OnHovered(); // Function BP_SkewedTabButton.BP_SkewedTabButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function BP_SkewedTabButton.BP_SkewedTabButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnSelected(); // Function BP_SkewedTabButton.BP_SkewedTabButton_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnDeselected(); // Function BP_SkewedTabButton.BP_SkewedTabButton_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void PreConstruct(bool IsDesignTime); // Function BP_SkewedTabButton.BP_SkewedTabButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP_SkewedTabButton(int32_t EntryPoint); // Function BP_SkewedTabButton.BP_SkewedTabButton_C.ExecuteUbergraph_BP_SkewedTabButton // (Final|UbergraphFunction) // @ game+0xccddc0
};

