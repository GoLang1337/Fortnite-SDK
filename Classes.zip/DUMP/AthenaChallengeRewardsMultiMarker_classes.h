// WidgetBlueprintGeneratedClass AthenaChallengeRewardsMultiMarker.AthenaChallengeRewardsMultiMarker_C
// Size: 0x280 (Inherited: 0x260)
struct UAthenaChallengeRewardsMultiMarker_C : UAthenaChallengeRewardsMultiMarker {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UWidgetAnimation* Inactive; // 0x268(0x08)
	struct UWidgetAnimation* Active; // 0x270(0x08)
	struct UImage* Image_Circle; // 0x278(0x08)

	void BP_OnSetMarkerActive(bool bIsActive); // Function AthenaChallengeRewardsMultiMarker.AthenaChallengeRewardsMultiMarker_C.BP_OnSetMarkerActive // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_AthenaChallengeRewardsMultiMarker(int32_t EntryPoint); // Function AthenaChallengeRewardsMultiMarker.AthenaChallengeRewardsMultiMarker_C.ExecuteUbergraph_AthenaChallengeRewardsMultiMarker // (Final|UbergraphFunction) // @ game+0xccddc0
};

