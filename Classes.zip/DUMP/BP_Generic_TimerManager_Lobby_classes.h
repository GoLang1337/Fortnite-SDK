// BlueprintGeneratedClass BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C
// Size: 0x274 (Inherited: 0x220)
struct ABP_Generic_TimerManager_Lobby_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x228(0x08)
	float TotalSecondsAtEvent; // 0x230(0x04)
	char pad_234[0x4]; // 0x234(0x04)
	struct FTimespan TimeUntilCountdownEnd; // 0x238(0x08)
	struct FString CalendarEventName; // 0x240(0x10)
	struct FTimerHandle CountdownTimerHandle; // 0x250(0x08)
	float Phase3VisualDuration; // 0x258(0x04)
	char pad_25C[0x4]; // 0x25c(0x04)
	struct FTimerHandle AccuracyTimer; // 0x260(0x08)
	struct FTimespan TimeSinceCountdownBegin; // 0x268(0x08)
	float TimespanRatio; // 0x270(0x04)

	void OnEventEnded_2CA6194447CC90E72CA40FB1A2CD843E(struct FString EventName, struct FTimespan TimeUntilEnd, struct FTimespan TimeSinceBegin, float TimespanRatio); // Function BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C.OnEventEnded_2CA6194447CC90E72CA40FB1A2CD843E // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnEventUpdated_2CA6194447CC90E72CA40FB1A2CD843E(struct FString EventName, struct FTimespan TimeUntilEnd, struct FTimespan TimeSinceBegin, float TimespanRatio); // Function BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C.OnEventUpdated_2CA6194447CC90E72CA40FB1A2CD843E // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnEventActive_2CA6194447CC90E72CA40FB1A2CD843E(struct FString EventName, struct FTimespan TimeUntilEnd, struct FTimespan TimeSinceBegin, float TimespanRatio); // Function BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C.OnEventActive_2CA6194447CC90E72CA40FB1A2CD843E // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void CountdownTimer_New(); // Function BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C.CountdownTimer_New // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void VisualUpdateEverySecond(); // Function BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C.VisualUpdateEverySecond // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ContinueClockCountdown(); // Function BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C.ContinueClockCountdown // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ClearTimerVisuals(); // Function BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C.ClearTimerVisuals // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void CountDownTimer_AccuracyFix(); // Function BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C.CountDownTimer_AccuracyFix // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveBeginPlay(); // Function BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BP_Generic_TimerManager_Lobby(int32_t EntryPoint); // Function BP_Generic_TimerManager_Lobby.BP_Generic_TimerManager_Lobby_C.ExecuteUbergraph_BP_Generic_TimerManager_Lobby // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

