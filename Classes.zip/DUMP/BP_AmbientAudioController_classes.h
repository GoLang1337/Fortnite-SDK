// BlueprintGeneratedClass BP_AmbientAudioController.BP_AmbientAudioController_C
// Size: 0x1c0 (Inherited: 0xd8)
struct UBP_AmbientAudioController_C : UFortAmbientAudioController {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd8(0x08)
	float CheckFrequency; // 0xe0(0x04)
	bool bAboveSnowAltitude; // 0xe4(0x01)
	char pad_E5[0x3]; // 0xe5(0x03)
	struct UAmbientAudioDataAsset* WinterAudioBank; // 0xe8(0x08)
	bool bSnowAltitudeEnabled; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
	struct UAmbientAudioDataAsset* StormAudioBank; // 0xf8(0x08)
	struct FGameplayTag AmbientAudioInsideTag; // 0x100(0x08)
	struct UAmbientAudioDataAsset* CurieAudioBank; // 0x108(0x08)
	struct FVector SnowOriginWorldLoc; // 0x110(0x0c)
	float SnowRadius; // 0x11c(0x04)
	struct TArray<struct FGameplayTag> SnowTagsToApply; // 0x120(0x10)
	struct FName SnowEntryName; // 0x130(0x08)
	float IndoorInterpTime; // 0x138(0x04)
	float IndoorStateChangedTime; // 0x13c(0x04)
	bool bIsIndoors; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	float IsPlayerIndoorsInterp; // 0x144(0x04)
	struct AActor* CurrViewTarget; // 0x148(0x08)
	struct TArray<struct FGameplayTag> GenericTagsToApply; // 0x150(0x10)
	bool bTagApplicationEnabled; // 0x160(0x01)
	enum class EInteriorAudioState Current State; // 0x161(0x01)
	char pad_162[0x2]; // 0x162(0x02)
	struct FGameplayTag Current Room Size Tag; // 0x164(0x08)
	char pad_16C[0x4]; // 0x16c(0x04)
	struct TMap<struct FGameplayTag, struct UReverbEffect*> Reverbs; // 0x170(0x50)

	void OnViewTargetChanged(struct AActor* New Target, struct AActor* Prev Target); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.OnViewTargetChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void CacheViewTarget(); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.CacheViewTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void RemovePlayerTags(struct AActor* Player, struct TArray<struct FGameplayTag>& Array); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.RemovePlayerTags // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ApplyPlayerTags(struct AActor* Player, struct TArray<struct FGameplayTag>& Tag Array); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.ApplyPlayerTags // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void UpdateSnowSetupBP(); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.UpdateSnowSetupBP // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ReceiveBeginPlay(); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void Update(); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.Update // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void InteriorStateChanged(enum class EInteriorAudioState PreviousState, enum class EInteriorAudioState CurrentState); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.InteriorStateChanged // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ReceiveTick(float DeltaSeconds); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void On Room Size Changed(struct FGameplayTag Curr, struct FGameplayTag Prev); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.On Room Size Changed // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void On Room State Changed(enum class EInteriorAudioState Curr, enum class EInteriorAudioState Prev); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.On Room State Changed // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void Update Interior Audio Verb(); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.Update Interior Audio Verb // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP_AmbientAudioController(int32_t EntryPoint); // Function BP_AmbientAudioController.BP_AmbientAudioController_C.ExecuteUbergraph_BP_AmbientAudioController // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

