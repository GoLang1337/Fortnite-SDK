// BlueprintGeneratedClass Buff_PartyXPBoost.Buff_PartyXPBoost_C
// Size: 0x800 (Inherited: 0x800)
struct UBuff_PartyXPBoost_C : UGameplayEffect {
};

