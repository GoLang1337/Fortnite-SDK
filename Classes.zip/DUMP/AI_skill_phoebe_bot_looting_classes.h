// BlueprintGeneratedClass AI_skill_phoebe_bot_looting.AI_skill_phoebe_bot_looting_C
// Size: 0x270 (Inherited: 0x270)
struct UAI_skill_phoebe_bot_looting_C : UFortAthenaAIBotLootingSkillSet {
};

