// WidgetBlueprintGeneratedClass BPS18_BattlePassTileEmpty.BPS18_BattlePassTileEmpty_C
// Size: 0xca0 (Inherited: 0xca0)
struct UBPS18_BattlePassTileEmpty_C : UFortBattlePassTileBase {
};

