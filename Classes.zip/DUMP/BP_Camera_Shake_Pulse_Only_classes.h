// BlueprintGeneratedClass BP_Camera_Shake_Pulse_Only.BP_Camera_Shake_Pulse_Only_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UBP_Camera_Shake_Pulse_Only_C : UMatineeCameraShake {
};

