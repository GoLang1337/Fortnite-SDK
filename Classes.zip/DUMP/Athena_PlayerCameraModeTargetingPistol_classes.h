// BlueprintGeneratedClass Athena_PlayerCameraModeTargetingPistol.Athena_PlayerCameraModeTargetingPistol_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeTargetingPistol_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

