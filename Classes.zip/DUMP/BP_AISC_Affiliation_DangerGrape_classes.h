// BlueprintGeneratedClass BP_AISC_Affiliation_DangerGrape.BP_AISC_Affiliation_DangerGrape_C
// Size: 0x260 (Inherited: 0x260)
struct UBP_AISC_Affiliation_DangerGrape_C : UBP_AISpawnerComp_Affiliation_Phoebe_C {
};

