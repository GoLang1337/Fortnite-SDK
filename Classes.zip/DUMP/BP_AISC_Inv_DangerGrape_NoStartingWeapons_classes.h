// BlueprintGeneratedClass BP_AISC_Inv_DangerGrape_NoStartingWeapons.BP_AISC_Inv_DangerGrape_NoStartingWeapons_C
// Size: 0xa8 (Inherited: 0xa8)
struct UBP_AISC_Inv_DangerGrape_NoStartingWeapons_C : UFortAthenaAISpawnerDataComponent_RandomInventory {
};

