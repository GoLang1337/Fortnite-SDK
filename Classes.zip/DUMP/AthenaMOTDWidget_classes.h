// WidgetBlueprintGeneratedClass AthenaMOTDWidget.AthenaMOTDWidget_C
// Size: 0x508 (Inherited: 0x470)
struct UAthenaMOTDWidget_C : UFortAthenaMOTDWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x470(0x08)
	struct UWidgetAnimation* NewAnimation; // 0x478(0x08)
	struct UWidgetAnimation* IntroAnim; // 0x480(0x08)
	struct UWidgetAnimation* OnNewSelect; // 0x488(0x08)
	struct UCircleArrowButton_C* CircleArrowButton_Left; // 0x490(0x08)
	struct UCircleArrowButton_C* CircleArrowButton_Right; // 0x498(0x08)
	struct UCommonTextBlock* CommonText_NewsHeader; // 0x4a0(0x08)
	struct UImage* Image_157; // 0x4a8(0x08)
	struct UImage* Image_TextFloater; // 0x4b0(0x08)
	struct USafeZone* SafeZone_1; // 0x4b8(0x08)
	struct USafeZone* SafeZone_2; // 0x4c0(0x08)
	struct USafeZone* SafeZone_3; // 0x4c8(0x08)
	struct USafeZone* SafeZone_4; // 0x4d0(0x08)
	struct UImage* SaveSpinner_NormalAction; // 0x4d8(0x08)
	struct UImage* SaveSpinner_SecondaryNormalAction; // 0x4e0(0x08)
	struct UImage* SaveSpinner_SecondarySpecialAction; // 0x4e8(0x08)
	struct UImage* SaveSpinner_SpecialAction; // 0x4f0(0x08)
	struct FMulticastInlineDelegate UpdateStyle; // 0x4f8(0x10)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void UpdateCustomColorStyle(bool bHasCustomColor, struct FColor CustomDarkColor, struct FColor CustomLightColor); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.UpdateCustomColorStyle // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void DialogResult_B7839D98483DEF9593D448BA28AE74F7(enum class EFortDialogResult Result, struct FName ResultName); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.DialogResult_B7839D98483DEF9593D448BA28AE74F7 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BndEvt__CircleArrowButton_Right_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature(struct UCommonButtonLegacy* Button); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.BndEvt__CircleArrowButton_Right_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__CircleArrowButton_Left_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature(struct UCommonButtonLegacy* Button); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.BndEvt__CircleArrowButton_Left_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void StartSTWUpsell(); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.StartSTWUpsell // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void SetSpecialButtonText(struct FText InText); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.SetSpecialButtonText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void SetNormalButtonText(struct FText InText); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.SetNormalButtonText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void OnSelectedNews(struct FAthenaMOTDBase NewsEntry); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.OnSelectedNews // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void PlayIntroAnimation(); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.PlayIntroAnimation // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void SetSecondarySpecialButtonText(struct FText InText); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.SetSecondarySpecialButtonText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void SetSecondaryNormalButtonText(struct FText InText); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.SetSecondaryNormalButtonText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void OnIsActivityLoadingChanged(bool bIsLoading); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.OnIsActivityLoadingChanged // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_AthenaMOTDWidget(int32_t EntryPoint); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.ExecuteUbergraph_AthenaMOTDWidget // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
	void UpdateStyle__DelegateSignature(enum class EAthenaNewsStyle NewStyle); // Function AthenaMOTDWidget.AthenaMOTDWidget_C.UpdateStyle__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
};

