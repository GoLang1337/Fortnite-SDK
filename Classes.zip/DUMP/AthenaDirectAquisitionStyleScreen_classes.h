// WidgetBlueprintGeneratedClass AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C
// Size: 0x7d0 (Inherited: 0x768)
struct UAthenaDirectAquisitionStyleScreen_C : UFortStoreFrontOfferDetailsWidgetBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x768(0x08)
	struct UPanelButton_C* Button_Next; // 0x770(0x08)
	struct UPanelButton_C* Button_Previous; // 0x778(0x08)
	struct USizeBox* CameraFramingWidget; // 0x780(0x08)
	struct UCloseButton_C* CloseButton; // 0x788(0x08)
	struct UItemInfoHeaderWidget_C* ItemInfoHeader; // 0x790(0x08)
	struct UAthenaLockedStyleNotification_C* LockedNotification; // 0x798(0x08)
	struct UCommonTextBlock* StyleDisclaimer; // 0x7a0(0x08)
	bool OfferSet; // 0x7a8(0x01)
	char pad_7A9[0x3]; // 0x7a9(0x03)
	int32_t IndexIntoOffersWithVariantsList; // 0x7ac(0x04)
	struct TArray<int32_t> OfferSubIndicesWithVariants; // 0x7b0(0x10)
	struct UFortItemDefinition* InitialTriggeringItemDef; // 0x7c0(0x08)
	struct UFortItem* CharacterItem; // 0x7c8(0x08)

	void ViewVaultItemWithBackpack(struct UFortItemDefinition* ItemToRepresent); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.ViewVaultItemWithBackpack // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetupCharacterItem(); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.SetupCharacterItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	struct UFortAccountItemDefinition* GetOfferGrantedItemDef(); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.GetOfferGrantedItemDef // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xccddc0
	void RebuildStylesFromOffer(); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.RebuildStylesFromOffer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SwitchToNextItemInOffer(int32_t Direction); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.SwitchToNextItemInOffer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ScanOfferForVariants(); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.ScanOfferForVariants // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void UpdateFromVariant(struct FGameplayTag VariantChannelTag, struct FGameplayTag VariantTag, struct FString Variant CustomData, bool IsOwned); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.UpdateFromVariant // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	struct UWidget* GetWidgetForFramingViewedItem(); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.GetWidgetForFramingViewedItem // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void HandleBack(bool& bPassThrough); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.HandleBack // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BP_OnOfferSet(); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.BP_OnOfferSet // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void BP_OnActivated(); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnDeactivated(); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.BP_OnDeactivated // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BndEvt__Button_Previous_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature(struct UCommonButtonLegacy* Button); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.BndEvt__Button_Previous_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__Button_Next_K2Node_ComponentBoundEvent_2_CommonButtonClicked__DelegateSignature(struct UCommonButtonLegacy* Button); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.BndEvt__Button_Next_K2Node_ComponentBoundEvent_2_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void OnVariantChanged(struct FGameplayTag VariantChannel, struct FGameplayTag VariantTag, struct FString VariantCustomData, bool IsOwned); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.OnVariantChanged // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BndEvt__CloseButton_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature(struct UCommonButtonLegacy* Button); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.BndEvt__CloseButton_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_AthenaDirectAquisitionStyleScreen(int32_t EntryPoint); // Function AthenaDirectAquisitionStyleScreen.AthenaDirectAquisitionStyleScreen_C.ExecuteUbergraph_AthenaDirectAquisitionStyleScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

