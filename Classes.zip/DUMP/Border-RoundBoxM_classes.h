// BlueprintGeneratedClass Border-RoundBoxM.Border-RoundBoxM_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-RoundBoxM_C : UCommonBorderStyle {
};

