// BlueprintGeneratedClass BGA_Alpaca.BGA_Alpaca_C
// Size: 0x998 (Inherited: 0x898)
struct ABGA_Alpaca_C : ABuildingGameplayActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x898(0x08)
	struct UStaticMeshComponent* CollisionMesh; // 0x8a0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x8a8(0x08)
	struct UGameplayEffect* GE_GrantedInBGA_Pawns; // 0x8b0(0x08)
	struct UGameplayEffect* GE_GrantedInBGA_Vehicles; // 0x8b8(0x08)
	struct FScalableFloat Row_MaxLifespan; // 0x8c0(0x28)
	struct FGameplayTag Tag_InBiome; // 0x8e8(0x08)
	struct FGameplayTagContainer TagContainer_InBiome; // 0x8f0(0x20)
	struct FScalableFloat Row_PhysicsObjectsOverlapCheckInterval; // 0x910(0x28)
	struct FTimerHandle Handle_UpdateOverlappedPhysicsObjectsTimer; // 0x938(0x08)
	struct TArray<enum class EObjectTypeQuery> ObjectType_PhysicsObjects; // 0x940(0x10)
	struct TArray<struct AActor*> CachedOverlappedPhysicsObjects; // 0x950(0x10)
	struct AActor* OverlappedActor; // 0x960(0x08)
	struct TArray<struct AFortPawn*> PawnsWithInvalidASC; // 0x968(0x10)
	float DelayBeforeTryValidatePlayerASC; // 0x978(0x04)
	char pad_97C[0x4]; // 0x97c(0x04)
	struct FTimerHandle Handle_TryValidatePlayerASCTimer; // 0x980(0x08)
	struct TArray<struct AFortPawn*> PendingPawnsWithInvalidASC; // 0x988(0x10)

	void UpdateCachedPhysicsActors(struct TArray<struct AActor*> PhysicsActorsToProcess, struct TArray<struct AActor*> CachedOverlappedPhysicsActors, struct FGameplayTag TagCachedOverlappedPhysicsActors, struct TArray<struct AActor*> SetCachedOverlappedPhysicsActors); // Function BGA_Alpaca.BGA_Alpaca_C.UpdateCachedPhysicsActors // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void RemoveVehicleEffects(struct TScriptInterface<IFortVehicleInterface> VehicleInterface); // Function BGA_Alpaca.BGA_Alpaca_C.RemoveVehicleEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ApplyVehicleEffects(struct TScriptInterface<IFortVehicleInterface> VehicleInterface); // Function BGA_Alpaca.BGA_Alpaca_C.ApplyVehicleEffects // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void RemovePawnEffects(struct AFortPawn* Pawn); // Function BGA_Alpaca.BGA_Alpaca_C.RemovePawnEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ApplyPawnEffects(struct AFortPawn* Pawn); // Function BGA_Alpaca.BGA_Alpaca_C.ApplyPawnEffects // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveBeginPlay(); // Function BGA_Alpaca.BGA_Alpaca_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void KillSelf(); // Function BGA_Alpaca.BGA_Alpaca_C.KillSelf // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BndEvt__Cylinder_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function BGA_Alpaca.BGA_Alpaca_C.BndEvt__Cylinder_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xcda090
	void BndEvt__Cylinder_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BGA_Alpaca.BGA_Alpaca_C.BndEvt__Cylinder_K2Node_ComponentBoundEvent_3_ComponentEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void TryGetVehicleAbilitySystemComponent(); // Function BGA_Alpaca.BGA_Alpaca_C.TryGetVehicleAbilitySystemComponent // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnMatchStarted(); // Function BGA_Alpaca.BGA_Alpaca_C.OnMatchStarted // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void UpdateOverlappedPhysicsObjects(); // Function BGA_Alpaca.BGA_Alpaca_C.UpdateOverlappedPhysicsObjects // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void TryValidatePawnASC(); // Function BGA_Alpaca.BGA_Alpaca_C.TryValidatePawnASC // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void AddPawnTagsAndEffects(struct AFortPawn* FortPawn); // Function BGA_Alpaca.BGA_Alpaca_C.AddPawnTagsAndEffects // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BGA_Alpaca(int32_t EntryPoint); // Function BGA_Alpaca.BGA_Alpaca_C.ExecuteUbergraph_BGA_Alpaca // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

