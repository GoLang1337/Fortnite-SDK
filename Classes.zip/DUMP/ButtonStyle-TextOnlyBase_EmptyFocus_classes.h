// BlueprintGeneratedClass ButtonStyle-TextOnlyBase_EmptyFocus.ButtonStyle-TextOnlyBase_EmptyFocus_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-TextOnlyBase_EmptyFocus_C : UButtonStyle-Base_C {
};

