// BlueprintGeneratedClass BP_AISpawnerComp_Construction_Phoebe.BP_AISpawnerComp_Construction_Phoebe_C
// Size: 0xc0 (Inherited: 0xc0)
struct UBP_AISpawnerComp_Construction_Phoebe_C : UFortAthenaAISpawnerDataComponent_AIBotConstruction {
};

