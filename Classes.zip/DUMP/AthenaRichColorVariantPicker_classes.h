// WidgetBlueprintGeneratedClass AthenaRichColorVariantPicker.AthenaRichColorVariantPicker_C
// Size: 0x338 (Inherited: 0x338)
struct UAthenaRichColorVariantPicker_C : UFortVariantRichColorPicker {
};

