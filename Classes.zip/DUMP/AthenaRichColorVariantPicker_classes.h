// WidgetBlueprintGeneratedClass AthenaRichColorVariantPicker.AthenaRichColorVariantPicker_C
// Size: 0x340 (Inherited: 0x340)
struct UAthenaRichColorVariantPicker_C : UFortVariantRichColorPicker {
};

