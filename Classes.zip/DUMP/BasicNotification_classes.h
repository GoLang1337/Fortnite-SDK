// BlueprintGeneratedClass BasicNotification.BasicNotification_C
// Size: 0xd0 (Inherited: 0xd0)
struct UBasicNotification_C : UFortUINotification {
};

