// BlueprintGeneratedClass BP_AISpawnerComp_SkillSet_Phoebe.BP_AISpawnerComp_SkillSet_Phoebe_C
// Size: 0xf8 (Inherited: 0xf8)
struct UBP_AISpawnerComp_SkillSet_Phoebe_C : UFortAthenaAISpawnerDataComponent_PlayerBotSkillset {
};

