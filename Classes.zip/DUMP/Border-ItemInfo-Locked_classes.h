// BlueprintGeneratedClass Border-ItemInfo-Locked.Border-ItemInfo-Locked_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-ItemInfo-Locked_C : UBorder-ItemInfo-Unlocked_C {
};

