// BlueprintGeneratedClass ButtonStyle-BottomBar_Refresh.ButtonStyle-BottomBar_Refresh_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-BottomBar_Refresh_C : UCommonButtonStyle {
};

