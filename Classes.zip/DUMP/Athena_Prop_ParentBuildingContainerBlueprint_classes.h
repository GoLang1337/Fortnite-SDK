// BlueprintGeneratedClass Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C
// Size: 0xd98 (Inherited: 0xcb8)
struct AAthena_Prop_ParentBuildingContainerBlueprint_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xcb8(0x08)
	bool DebugWind; // 0xcc0(0x01)
	char pad_CC1[0x7]; // 0xcc1(0x07)
	struct TArray<struct UMaterialInterface*> IntenseWindMaterialsForPreview; // 0xcc8(0x10)
	struct UStaticMeshComponent* Wind Intensity Debug Mesh; // 0xcd8(0x08)
	struct TArray<struct UMaterialInterface*> OriginalMaterials; // 0xce0(0x10)
	struct UMaterialInstanceDynamic* Debug_TempMaterial; // 0xcf0(0x08)
	float DebugWindYaw; // 0xcf8(0x04)
	float Debug Wind Intensity; // 0xcfc(0x04)
	bool Set Max Actor Scale; // 0xd00(0x01)
	char pad_D01[0x3]; // 0xd01(0x03)
	float Max Scale; // 0xd04(0x04)
	bool Disable TOD Lights and Material Emissive Values; // 0xd08(0x01)
	bool Disable Static Mesh Shadow Casting When Lights Are Active; // 0xd09(0x01)
	bool Use An Alternate Shadow Mesh When The Light is On ; // 0xd0a(0x01)
	char pad_D0B[0x5]; // 0xd0b(0x05)
	struct UStaticMesh* AlternateShadowStaticMesh; // 0xd10(0x08)
	bool Animate Emissive and Lights Over Time; // 0xd18(0x01)
	char pad_D19[0x7]; // 0xd19(0x07)
	struct TArray<struct FLinearColor> CodeControlled_EmissiveColor; // 0xd20(0x10)
	struct TArray<float> CodeControlled_LightConeOpacity; // 0xd30(0x10)
	struct FDayPhaseFloats Light Intensity Over Time of Day ; // 0xd40(0x10)
	float Day Phase Transition Length; // 0xd50(0x04)
	struct FDayPhaseFloats Emissive Intensity Over Time of Day; // 0xd54(0x10)
	float Volumetric Light Scattering Intensity; // 0xd64(0x04)
	bool Cast Volumetric Shadows; // 0xd68(0x01)
	bool Animate Lights With A Curve - Disables time of day light controls; // 0xd69(0x01)
	bool Animate Mesh MID Emissive Value with a Curve - Disables time of day light controls; // 0xd6a(0x01)
	char pad_D6B[0x5]; // 0xd6b(0x05)
	struct UCurveFloat* LightAnimationCurve; // 0xd70(0x08)
	float CodeControlled_Animation Curve Animation Length; // 0xd78(0x04)
	int32_t CodeControlled_NumberOfMaterials; // 0xd7c(0x04)
	struct TArray<float> NewVar_1; // 0xd80(0x10)
	float Random Time Scale Percent; // 0xd90(0x04)
	float CodeControlled_CurrentPlayLength; // 0xd94(0x04)

	void GetTimeOfDayBlueprintDefaultVariables(struct FTimeOfDayBlueprintDefaultVariables OutVariables); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.GetTimeOfDayBlueprintDefaultVariables // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void UserConstructionScript(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveBeginPlay(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnDayPhaseChanged(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnDayPhaseChanged // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void Loop Animation Curve(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.Loop Animation Curve // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnBounceAnimationUpdate(struct FFortBounceData Data); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnBounceAnimationUpdate // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void OnSetSearched(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnSetSearched // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint(int32_t EntryPoint); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

