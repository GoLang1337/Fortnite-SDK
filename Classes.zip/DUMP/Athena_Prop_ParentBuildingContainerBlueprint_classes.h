// BlueprintGeneratedClass Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C
// Size: 0xe60 (Inherited: 0xd80)
struct AAthena_Prop_ParentBuildingContainerBlueprint_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd80(0x08)
	bool DebugWind; // 0xd88(0x01)
	char pad_D89[0x7]; // 0xd89(0x07)
	struct TArray<struct UMaterialInterface*> IntenseWindMaterialsForPreview; // 0xd90(0x10)
	struct UStaticMeshComponent* Wind Intensity Debug Mesh; // 0xda0(0x08)
	struct TArray<struct UMaterialInterface*> OriginalMaterials; // 0xda8(0x10)
	struct UMaterialInstanceDynamic* Debug_TempMaterial; // 0xdb8(0x08)
	float DebugWindYaw; // 0xdc0(0x04)
	float Debug Wind Intensity; // 0xdc4(0x04)
	bool Set Max Actor Scale; // 0xdc8(0x01)
	char pad_DC9[0x3]; // 0xdc9(0x03)
	float Max Scale; // 0xdcc(0x04)
	bool Disable TOD Lights and Material Emissive Values; // 0xdd0(0x01)
	bool Disable Static Mesh Shadow Casting When Lights Are Active; // 0xdd1(0x01)
	bool Use An Alternate Shadow Mesh When The Light is On ; // 0xdd2(0x01)
	char pad_DD3[0x5]; // 0xdd3(0x05)
	struct UStaticMesh* AlternateShadowStaticMesh; // 0xdd8(0x08)
	bool Animate Emissive and Lights Over Time; // 0xde0(0x01)
	char pad_DE1[0x7]; // 0xde1(0x07)
	struct TArray<struct FLinearColor> CodeControlled_EmissiveColor; // 0xde8(0x10)
	struct TArray<float> CodeControlled_LightConeOpacity; // 0xdf8(0x10)
	struct FDayPhaseFloats Light Intensity Over Time of Day ; // 0xe08(0x10)
	float Day Phase Transition Length; // 0xe18(0x04)
	struct FDayPhaseFloats Emissive Intensity Over Time of Day; // 0xe1c(0x10)
	float Volumetric Light Scattering Intensity; // 0xe2c(0x04)
	bool Cast Volumetric Shadows; // 0xe30(0x01)
	bool Animate Lights With A Curve - Disables time of day light controls; // 0xe31(0x01)
	bool Animate Mesh MID Emissive Value with a Curve - Disables time of day light controls; // 0xe32(0x01)
	char pad_E33[0x5]; // 0xe33(0x05)
	struct UCurveFloat* LightAnimationCurve; // 0xe38(0x08)
	float CodeControlled_Animation Curve Animation Length; // 0xe40(0x04)
	int32_t CodeControlled_NumberOfMaterials; // 0xe44(0x04)
	struct TArray<float> NewVar_1; // 0xe48(0x10)
	float Random Time Scale Percent; // 0xe58(0x04)
	float CodeControlled_CurrentPlayLength; // 0xe5c(0x04)

	void GetTimeOfDayBlueprintDefaultVariables(struct FTimeOfDayBlueprintDefaultVariables& OutVariables); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.GetTimeOfDayBlueprintDefaultVariables // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void UserConstructionScript(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ReceiveBeginPlay(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnDayPhaseChanged(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnDayPhaseChanged // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void Loop Animation Curve(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.Loop Animation Curve // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnBounceAnimationUpdate(struct FFortBounceData& Data); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnBounceAnimationUpdate // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void OnSetSearched(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnSetSearched // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint(int32_t EntryPoint); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

