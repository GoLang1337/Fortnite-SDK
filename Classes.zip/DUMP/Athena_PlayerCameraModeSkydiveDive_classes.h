// BlueprintGeneratedClass Athena_PlayerCameraModeSkydiveDive.Athena_PlayerCameraModeSkydiveDive_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCameraModeSkydiveDive_C : UAthena_PlayerCameraModeBase_C {
};

