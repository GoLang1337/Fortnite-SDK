// WidgetBlueprintGeneratedClass BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C
// Size: 0xd88 (Inherited: 0xc68)
struct UBattlePassLandingPageButtonS17_C : UBattlePassLandingPageButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc68(0x08)
	struct UWidgetAnimation* burst; // 0xc70(0x08)
	struct UWidgetAnimation* Intro; // 0xc78(0x08)
	struct UWidgetAnimation* Selected; // 0xc80(0x08)
	struct USpacer* ExtraSpace; // 0xc88(0x08)
	struct UImage* Image; // 0xc90(0x08)
	struct UImage* Image_33; // 0xc98(0x08)
	struct UImage* Image_Background; // 0xca0(0x08)
	struct UImage* Image_Lock_Purple; // 0xca8(0x08)
	struct UImage* Image_selected_LR; // 0xcb0(0x08)
	struct UImage* Image_selected_TB; // 0xcb8(0x08)
	struct UOverlay* Overlay_clock; // 0xcc0(0x08)
	struct UCommonRichTextBlock* RichText_Title; // 0xcc8(0x08)
	struct UCommonVisibilitySwitcher* Switcher_locked; // 0xcd0(0x08)
	struct UCommonRichTextBlock* Text_Bottom; // 0xcd8(0x08)
	struct UCommonRichTextBlock* Text_Top; // 0xce0(0x08)
	struct FText Title Text; // 0xce8(0x18)
	enum class ETextJustify Justification; // 0xd00(0x01)
	char pad_D01[0x7]; // 0xd01(0x07)
	struct UMaterialInterface* Material; // 0xd08(0x08)
	struct FVector2D In Size; // 0xd10(0x08)
	float Extra Space; // 0xd18(0x04)
	bool IsLocked; // 0xd1c(0x01)
	char pad_D1D[0x3]; // 0xd1d(0x03)
	struct FText BottomText; // 0xd20(0x18)
	struct FText Empty text; // 0xd38(0x18)
	struct FText Top text; // 0xd50(0x18)
	bool TimeGated; // 0xd68(0x01)
	char pad_D69[0x7]; // 0xd69(0x07)
	struct FText TopText_SubscriptionOwned; // 0xd70(0x18)

	void Play intro(); // Function BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C.Play intro // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnInitialized(); // Function BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void BP_OnHovered(); // Function BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnUnhovered(); // Function BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void PreConstruct(bool IsDesignTime); // Function BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void Hide Lock(bool Show Lock Icon); // Function BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C.Hide Lock // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnSubscriptionOwnershipUpdated(bool bOwnsSubsciption); // Function BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C.OnSubscriptionOwnershipUpdated // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnSubscriptionTextureLoaded(struct UTexture2D* Texture); // Function BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C.OnSubscriptionTextureLoaded // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void Hide Clock(bool Show Clock Icon); // Function BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C.Hide Clock // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BattlePassLandingPageButtonS17(int32_t EntryPoint); // Function BattlePassLandingPageButtonS17.BattlePassLandingPageButtonS17_C.ExecuteUbergraph_BattlePassLandingPageButtonS17 // (Final|UbergraphFunction) // @ game+0xcda090
};

