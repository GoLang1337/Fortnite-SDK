// BlueprintGeneratedClass BP_NS_Sideways_CameraFX_Interact.BP_NS_Sideways_CameraFX_Interact_C
// Size: 0x290 (Inherited: 0x290)
struct ABP_NS_Sideways_CameraFX_Interact_C : ANiagaraLensEffectBase {
};

