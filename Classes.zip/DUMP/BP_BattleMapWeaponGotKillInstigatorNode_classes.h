// BlueprintGeneratedClass BP_BattleMapWeaponGotKillInstigatorNode.BP_BattleMapWeaponGotKillInstigatorNode_C
// Size: 0x358 (Inherited: 0x358)
struct ABP_BattleMapWeaponGotKillInstigatorNode_C : ABP_BattleMapBaseNode_C {
};

