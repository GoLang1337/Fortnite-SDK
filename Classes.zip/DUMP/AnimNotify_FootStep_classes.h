// BlueprintGeneratedClass AnimNotify_FootStep.AnimNotify_FootStep_C
// Size: 0x3c (Inherited: 0x38)
struct UAnimNotify_FootStep_C : UAnimNotify {
	int32_t FootIndex; // 0x38(0x04)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_FootStep.AnimNotify_FootStep_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xccddc0
};

