// BlueprintGeneratedClass Border_Notification_Rectangle.Border_Notification_Rectangle_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_Notification_Rectangle_C : UCommonBorderStyle {
};

