// BlueprintGeneratedClass Border-SolidBG-Yellow.Border-SolidBG-Yellow_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-SolidBG-Yellow_C : UCommonBorderStyle {
};

