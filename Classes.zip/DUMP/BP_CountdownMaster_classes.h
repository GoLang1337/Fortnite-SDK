// BlueprintGeneratedClass BP_CountdownMaster.BP_CountdownMaster_C
// Size: 0x334 (Inherited: 0x220)
struct ABP_CountdownMaster_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UStaticMeshComponent* HologramSkybeam; // 0x228(0x08)
	struct UStaticMeshComponent* HologramCountdown; // 0x230(0x08)
	struct UStaticMeshComponent* CountdownScreen; // 0x238(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x240(0x08)
	bool Debug_Phase2; // 0x248(0x01)
	bool Debug_Phase3; // 0x249(0x01)
	char pad_24A[0x2]; // 0x24a(0x02)
	int32_t NumberofDigits; // 0x24c(0x04)
	float HologramHeight; // 0x250(0x04)
	bool ScreenVisible; // 0x254(0x01)
	bool HologramVisible; // 0x255(0x01)
	char pad_256[0x2]; // 0x256(0x02)
	struct UMaterialInterface* CountdownScreen_Override; // 0x258(0x08)
	struct UMaterialInterface* Beam_Override; // 0x260(0x08)
	struct UMaterialInterface* CountdownHologram_Override; // 0x268(0x08)
	struct UMaterialInstanceDynamic* MI_CountdownScreen; // 0x270(0x08)
	struct UMaterialInstanceDynamic* MI_Countdown_Hologram; // 0x278(0x08)
	struct UMaterialInstanceDynamic* MI_Skybeam; // 0x280(0x08)
	struct FColor Color; // 0x288(0x04)
	float UV_Padding_x; // 0x28c(0x04)
	float UV_Padding_y; // 0x290(0x04)
	float UV_Offset_x; // 0x294(0x04)
	float UV_Offset_y; // 0x298(0x04)
	float ScaleHologram_x; // 0x29c(0x04)
	float ScaleHologram_y; // 0x2a0(0x04)
	float HologramVignette; // 0x2a4(0x04)
	struct UTexture* BackgroundTexture; // 0x2a8(0x08)
	struct UTexture* PostCountdownTexture; // 0x2b0(0x08)
	bool ShowHologramInHLOD; // 0x2b8(0x01)
	bool ShowScreenInHLOD; // 0x2b9(0x01)
	bool ExcludefromMediumHLOD; // 0x2ba(0x01)
	char pad_2BB[0x5]; // 0x2bb(0x05)
	struct UMaterialInstanceDynamic* DontUSEMI_Countdown_Hologram_HLOD; // 0x2c0(0x08)
	float DistanceFadeLength; // 0x2c8(0x04)
	float DistanceFadeOffset; // 0x2cc(0x04)
	struct UMaterialInterface* HLOD Override_Hologram; // 0x2d0(0x08)
	struct UMaterialInterface* HLOD Override_SkyBeam; // 0x2d8(0x08)
	int32_t HLODElementIndex; // 0x2e0(0x04)
	char pad_2E4[0x4]; // 0x2e4(0x04)
	struct FString OptionalCalendarEvent; // 0x2e8(0x10)
	bool bManuallyTrackCalendarEvent; // 0x2f8(0x01)
	char pad_2F9[0x7]; // 0x2f9(0x07)
	struct UAudioComponent* CountdownAudioComp; // 0x300(0x08)
	struct USoundBase* CountdownAsset; // 0x308(0x08)
	struct USoundBase* CountdownEndAsset; // 0x310(0x08)
	struct USoundMix* CountdownSoundMix; // 0x318(0x08)
	bool bUseAudioLocationOverride; // 0x320(0x01)
	char pad_321[0x3]; // 0x321(0x03)
	struct FVector AudioLocationOverride; // 0x324(0x0c)
	float CountdownAudioFadeOut; // 0x330(0x04)

	void StopCountdownAudio(); // Function BP_CountdownMaster.BP_CountdownMaster_C.StopCountdownAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void StartCountdownAudio(); // Function BP_CountdownMaster.BP_CountdownMaster_C.StartCountdownAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SetupVisibility(); // Function BP_CountdownMaster.BP_CountdownMaster_C.SetupVisibility // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void HandleSetupMIDs(); // Function BP_CountdownMaster.BP_CountdownMaster_C.HandleSetupMIDs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void HandleHLODMaterialOverrides(); // Function BP_CountdownMaster.BP_CountdownMaster_C.HandleHLODMaterialOverrides // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SetHologramRelativeTransform(); // Function BP_CountdownMaster.BP_CountdownMaster_C.SetHologramRelativeTransform // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OverrideComponentMaterial(struct UPrimitiveComponent* InComponent, struct UMaterialInterface* OverrideMaterial, int32_t ElementIndex, bool bSuccesful); // Function BP_CountdownMaster.BP_CountdownMaster_C.OverrideComponentMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void HandleMaterialPropertyOverrides(); // Function BP_CountdownMaster.BP_CountdownMaster_C.HandleMaterialPropertyOverrides // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void UserConstructionScript(); // Function BP_CountdownMaster.BP_CountdownMaster_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveBeginPlay(); // Function BP_CountdownMaster.BP_CountdownMaster_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BP_CountdownMaster(int32_t EntryPoint); // Function BP_CountdownMaster.BP_CountdownMaster_C.ExecuteUbergraph_BP_CountdownMaster // (Final|UbergraphFunction) // @ game+0xcda090
};

