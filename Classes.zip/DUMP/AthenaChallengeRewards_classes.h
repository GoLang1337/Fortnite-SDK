// WidgetBlueprintGeneratedClass AthenaChallengeRewards.AthenaChallengeRewards_C
// Size: 0x2a0 (Inherited: 0x2a0)
struct UAthenaChallengeRewards_C : UAthenaChallengeRewards {
};

