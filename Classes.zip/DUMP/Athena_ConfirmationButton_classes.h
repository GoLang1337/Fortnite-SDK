// WidgetBlueprintGeneratedClass Athena_ConfirmationButton.Athena_ConfirmationButton_C
// Size: 0xd21 (Inherited: 0xd21)
struct UAthena_ConfirmationButton_C : UIconTextButton_C {
};

