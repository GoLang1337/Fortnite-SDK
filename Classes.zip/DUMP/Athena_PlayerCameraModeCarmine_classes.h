// BlueprintGeneratedClass Athena_PlayerCameraModeCarmine.Athena_PlayerCameraModeCarmine_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeCarmine_C : UAthena_PlayerCameraModeBase_C {
};

