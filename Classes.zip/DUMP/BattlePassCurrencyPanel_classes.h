// WidgetBlueprintGeneratedClass BattlePassCurrencyPanel.BattlePassCurrencyPanel_C
// Size: 0x2b0 (Inherited: 0x2a0)
struct UBattlePassCurrencyPanel_C : UFortBattlePassCurrencyPanel {
	struct UImage* BattleStarIcon; // 0x2a0(0x08)
	struct UImage* CustomSkinIcon; // 0x2a8(0x08)
};

