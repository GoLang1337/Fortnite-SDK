// WidgetBlueprintGeneratedClass BPS18_AboutModal_Pip.BPS18_AboutModal_Pip_C
// Size: 0xc08 (Inherited: 0xbd0)
struct UBPS18_AboutModal_Pip_C : UCommonButtonBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd0(0x08)
	struct UWidgetAnimation* Hover; // 0xbd8(0x08)
	struct UWidgetAnimation* Select; // 0xbe0(0x08)
	struct UImage* PIP; // 0xbe8(0x08)
	bool IsFocused; // 0xbf0(0x01)
	char pad_BF1[0x7]; // 0xbf1(0x07)
	struct FMulticastInlineDelegate ClickedOnPip; // 0xbf8(0x10)

	void Is focused(bool Is focused); // Function BPS18_AboutModal_Pip.BPS18_AboutModal_Pip_C.Is focused // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHovered(); // Function BPS18_AboutModal_Pip.BPS18_AboutModal_Pip_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function BPS18_AboutModal_Pip.BPS18_AboutModal_Pip_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnClicked(); // Function BPS18_AboutModal_Pip.BPS18_AboutModal_Pip_C.BP_OnClicked // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_AboutModal_Pip(int32_t EntryPoint); // Function BPS18_AboutModal_Pip.BPS18_AboutModal_Pip_C.ExecuteUbergraph_BPS18_AboutModal_Pip // (Final|UbergraphFunction) // @ game+0xccddc0
	void ClickedOnPip__DelegateSignature(); // Function BPS18_AboutModal_Pip.BPS18_AboutModal_Pip_C.ClickedOnPip__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
};

