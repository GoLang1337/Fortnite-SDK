// WidgetBlueprintGeneratedClass BPS18_BattlePassCurrencyPanel.BPS18_BattlePassCurrencyPanel_C
// Size: 0x2b0 (Inherited: 0x2a0)
struct UBPS18_BattlePassCurrencyPanel_C : UFortBattlePassCurrencyPanel {
	struct UImage* BattleStarIcon; // 0x2a0(0x08)
	struct UImage* CustomSkinIcon; // 0x2a8(0x08)
};

