// BlueprintGeneratedClass Border-Bang.Border-Bang_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-Bang_C : UCommonBorderStyle {
};

