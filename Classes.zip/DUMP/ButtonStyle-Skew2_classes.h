// BlueprintGeneratedClass ButtonStyle-Skew2.ButtonStyle-Skew2_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Skew2_C : UCommonButtonStyle {
};

