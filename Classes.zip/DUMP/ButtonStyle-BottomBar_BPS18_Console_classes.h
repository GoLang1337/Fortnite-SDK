// BlueprintGeneratedClass ButtonStyle-BottomBar_BPS18_Console.ButtonStyle-BottomBar_BPS18_Console_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-BottomBar_BPS18_Console_C : UCommonButtonStyle {
};

