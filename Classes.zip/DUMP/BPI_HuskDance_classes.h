// BlueprintGeneratedClass BPI_HuskDance.BPI_HuskDance_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_HuskDance_C : UInterface {

	void OnEndDance(); // Function BPI_HuskDance.BPI_HuskDance_C.OnEndDance // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnBeginDance(); // Function BPI_HuskDance.BPI_HuskDance_C.OnBeginDance // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
};

