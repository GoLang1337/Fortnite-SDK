// BlueprintGeneratedClass AI_skill_phoebe_bot_perception.AI_skill_phoebe_bot_perception_C
// Size: 0xc08 (Inherited: 0xc08)
struct UAI_skill_phoebe_bot_perception_C : UFortAthenaAIBotPerceptionSkillSet {
};

