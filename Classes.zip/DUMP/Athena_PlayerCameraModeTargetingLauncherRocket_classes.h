// BlueprintGeneratedClass Athena_PlayerCameraModeTargetingLauncherRocket.Athena_PlayerCameraModeTargetingLauncherRocket_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeTargetingLauncherRocket_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

