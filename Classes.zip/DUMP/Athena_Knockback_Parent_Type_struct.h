// UserDefinedEnum Athena_Knockback_Parent_Type.Athena_Knockback_Parent_Type
enum class Athena_Knockback_Parent_Type : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator3 = 1,
	Athena_Knockback_Parent_MAX = 2
};

