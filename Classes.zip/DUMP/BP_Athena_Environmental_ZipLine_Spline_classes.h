// BlueprintGeneratedClass BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C
// Size: 0xb50 (Inherited: 0xa98)
struct ABP_Athena_Environmental_ZipLine_Spline_C : AFortAthenaSplineZipline {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa98(0x08)
	struct UStaticMesh* SplineStaticMesh; // 0xaa0(0x08)
	float TangentSmoothStrength; // 0xaa8(0x04)
	bool AutoSmoothTangents; // 0xaac(0x01)
	enum class ESplineMeshAxis ForwardMeshAxis; // 0xaad(0x01)
	char pad_AAE[0x2]; // 0xaae(0x02)
	struct FVector MotorOffset; // 0xab0(0x0c)
	char pad_ABC[0x4]; // 0xabc(0x04)
	struct AActor* PoleA; // 0xac0(0x08)
	struct AActor* PoleB; // 0xac8(0x08)
	struct FVector PoleASocketLocation; // 0xad0(0x0c)
	struct FVector PoleBSocketLocation; // 0xadc(0x0c)
	int32_t LowerPointID; // 0xae8(0x04)
	int32_t HigherPointID; // 0xaec(0x04)
	struct FVector HigherEndLocation; // 0xaf0(0x0c)
	struct FVector LowerEndLocation; // 0xafc(0x0c)
	float AutoLinearFactorLow; // 0xb08(0x04)
	float AutoLinearFactorHigh; // 0xb0c(0x04)
	float AutoSplineTangentLengthCoef; // 0xb10(0x04)
	float AutoSplineTangentHorizCoef; // 0xb14(0x04)
	float AutoSplineTangentVertCoef; // 0xb18(0x04)
	bool Auto Set Spline Ends; // 0xb1c(0x01)
	bool Auto Set Spline Mids; // 0xb1d(0x01)
	char pad_B1E[0x2]; // 0xb1e(0x02)
	struct TArray<struct UMaterialInstanceDynamic*> SplineMaterials; // 0xb20(0x10)
	struct FGameplayTagContainer BlockInteractTags; // 0xb30(0x20)

	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xccddc0
	void GetAutoHorizAndVertVectors(struct FVector highVector, struct FVector LowVector, struct FVector& VertVec, struct FVector& HorizVec); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.GetAutoHorizAndVertVectors // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void Calc Auto Location At Alpha(float InAlpha, bool DrawDebug, struct FVector& PointLocation); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.Calc Auto Location At Alpha // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetSplinePositionAndTangent(bool SetPosition, bool SetTangent, int32_t ID); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.SetSplinePositionAndTangent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void CalculatePositionOfPoles(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.CalculatePositionOfPoles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void AutoSmoothTanget(struct FVector Tangent, struct FVector PointA, struct FVector PointB, struct FVector& SmoothedTangent); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.AutoSmoothTanget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xccddc0
	void AddSplineMeshSegment(struct USplineMeshComponent*& SplineMeshSegment); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.AddSplineMeshSegment // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void UserConstructionScript(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ReceiveBeginPlay(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void PlayerAttachedToZipline(struct AFortPlayerPawn* PlayerPawn); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.PlayerAttachedToZipline // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void PlayerDetachedFromZipline(struct AFortPlayerPawn* PlayerPawn); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.PlayerDetachedFromZipline // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP_Athena_Environmental_ZipLine_Spline(int32_t EntryPoint); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.ExecuteUbergraph_BP_Athena_Environmental_ZipLine_Spline // (Final|UbergraphFunction) // @ game+0xccddc0
};

