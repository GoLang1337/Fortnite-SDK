// BlueprintGeneratedClass Athena_PlayerCameraModeMelee.Athena_PlayerCameraModeMelee_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCameraModeMelee_C : UAthena_PlayerCameraModeBase_C {
};

