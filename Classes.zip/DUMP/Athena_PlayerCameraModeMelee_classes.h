// BlueprintGeneratedClass Athena_PlayerCameraModeMelee.Athena_PlayerCameraModeMelee_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeMelee_C : UAthena_PlayerCameraModeBase_C {
};

