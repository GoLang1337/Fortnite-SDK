// WidgetBlueprintGeneratedClass AthenaDirectAcquisitonDetails_RefundDisclaimer.AthenaDirectAcquisitonDetails_RefundDisclaimer_C
// Size: 0x290 (Inherited: 0x260)
struct UAthenaDirectAcquisitonDetails_RefundDisclaimer_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x260(0x08)
	struct UCommonTextBlock* DisclaimerText; // 0x268(0x08)
	struct UHorizontalBox* HorizontalBoxDisclaimer; // 0x270(0x08)
	struct FText OverrideText; // 0x278(0x18)

	void PreConstruct(bool IsDesignTime); // Function AthenaDirectAcquisitonDetails_RefundDisclaimer.AthenaDirectAcquisitonDetails_RefundDisclaimer_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_AthenaDirectAcquisitonDetails_RefundDisclaimer(int32_t EntryPoint); // Function AthenaDirectAcquisitonDetails_RefundDisclaimer.AthenaDirectAcquisitonDetails_RefundDisclaimer_C.ExecuteUbergraph_AthenaDirectAcquisitonDetails_RefundDisclaimer // (Final|UbergraphFunction) // @ game+0xcda090
};

