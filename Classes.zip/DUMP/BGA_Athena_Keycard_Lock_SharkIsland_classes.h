// BlueprintGeneratedClass BGA_Athena_Keycard_Lock_SharkIsland.BGA_Athena_Keycard_Lock_SharkIsland_C
// Size: 0xae9 (Inherited: 0xae9)
struct ABGA_Athena_Keycard_Lock_SharkIsland_C : ABGA_Athena_Keycard_Lock_Parent_C {
};

