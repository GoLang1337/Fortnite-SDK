// BlueprintGeneratedClass ButtonStyle-Tab-Main.ButtonStyle-Tab-Main_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Tab-Main_C : UCommonButtonStyle {
};

