// BlueprintGeneratedClass Athena_Prop_Bathroom_Toilet_01.Athena_Prop_Bathroom_Toilet_01_C
// Size: 0xcb8 (Inherited: 0xcb8)
struct AAthena_Prop_Bathroom_Toilet_01_C : ABuildingProp {
};

