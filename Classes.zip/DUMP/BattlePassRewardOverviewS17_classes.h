// WidgetBlueprintGeneratedClass BattlePassRewardOverviewS17.BattlePassRewardOverviewS17_C
// Size: 0x4c8 (Inherited: 0x488)
struct UBattlePassRewardOverviewS17_C : UBattlePassRewardPageS17 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UWidgetAnimation* Intro; // 0x490(0x08)
	struct UWidgetAnimation* Header_intro; // 0x498(0x08)
	struct UImage* Image_86; // 0x4a0(0x08)
	struct USafeZone* SafeZone_1; // 0x4a8(0x08)
	struct UCommonTextBlock* Subtitle; // 0x4b0(0x08)
	struct UCommonTextBlock* Title; // 0x4b8(0x08)
	struct UVerticalBox* VerticalBox_24; // 0x4c0(0x08)

	void SequenceEvent__ENTRYPOINTBattlePassRewardOverviewS17_1(struct UPageNavigator_C* PageNavigator); // Function BattlePassRewardOverviewS17.BattlePassRewardOverviewS17_C.SequenceEvent__ENTRYPOINTBattlePassRewardOverviewS17_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void PageNavigator_Event_1(struct UPageNavigator_C* PageNavigator); // Function BattlePassRewardOverviewS17.BattlePassRewardOverviewS17_C.PageNavigator_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnPageChanged(int32_t PageNumber); // Function BattlePassRewardOverviewS17.BattlePassRewardOverviewS17_C.OnPageChanged // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void BP_OnActivated(); // Function BattlePassRewardOverviewS17.BattlePassRewardOverviewS17_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnInputMethodChanged(enum class ECommonInputType InputType); // Function BattlePassRewardOverviewS17.BattlePassRewardOverviewS17_C.OnInputMethodChanged // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnInitForPageType(enum class ERewardPageType InRewardPageType); // Function BattlePassRewardOverviewS17.BattlePassRewardOverviewS17_C.OnInitForPageType // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BattlePassRewardOverviewS17(int32_t EntryPoint); // Function BattlePassRewardOverviewS17.BattlePassRewardOverviewS17_C.ExecuteUbergraph_BattlePassRewardOverviewS17 // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

