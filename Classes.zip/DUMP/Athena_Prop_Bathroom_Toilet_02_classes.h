// BlueprintGeneratedClass Athena_Prop_Bathroom_Toilet_02.Athena_Prop_Bathroom_Toilet_02_C
// Size: 0xcb8 (Inherited: 0xcb8)
struct AAthena_Prop_Bathroom_Toilet_02_C : ABuildingProp {
};

