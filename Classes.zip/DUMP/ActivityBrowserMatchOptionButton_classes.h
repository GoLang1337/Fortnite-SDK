// WidgetBlueprintGeneratedClass ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C
// Size: 0xd88 (Inherited: 0xcc8)
struct UActivityBrowserMatchOptionButton_C : UFortTextButton_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xcc8(0x08)
	struct UWidgetAnimation* Pressed; // 0xcd0(0x08)
	struct UWidgetAnimation* Hover; // 0xcd8(0x08)
	struct UBorder* ButtonMaterialBorder; // 0xce0(0x08)
	struct UHorizontalBox* ContentHB; // 0xce8(0x08)
	struct UBorder* DynamicPaddingBorder; // 0xcf0(0x08)
	struct USizeBox* MinSizesSB; // 0xcf8(0x08)
	struct UCommonTextBlock* Text_Label; // 0xd00(0x08)
	struct FText ButtonLabel; // 0xd08(0x18)
	float TextShearX; // 0xd20(0x04)
	float TextShearY; // 0xd24(0x04)
	struct FMargin TextPadding; // 0xd28(0x10)
	bool IsDisabled; // 0xd38(0x01)
	char pad_D39[0x7]; // 0xd39(0x07)
	struct UMaterialInterface* ButtonMaterial; // 0xd40(0x08)
	float ButtonSharpnessX; // 0xd48(0x04)
	float ButtonSharpnessY; // 0xd4c(0x04)
	float UseBoxScalingX; // 0xd50(0x04)
	float UseBoxScalingY; // 0xd54(0x04)
	float ButtonBoxScaleSizeX; // 0xd58(0x04)
	float ButtonBoxScaleSizeY; // 0xd5c(0x04)
	struct FName DisabledParamName; // 0xd60(0x08)
	struct FName SharpnessVParamName; // 0xd68(0x08)
	struct FName SharpnessUParamName; // 0xd70(0x08)
	struct FName UseBoxScaleUParamName; // 0xd78(0x08)
	struct FName UseBoxScaleVParamName; // 0xd80(0x08)

	void SetFontMaterial(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.SetFontMaterial // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetButtonMaterial(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.SetButtonMaterial // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetText(struct FText Text); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.SetText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void SetTextStyle(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.SetTextStyle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void Finished_F1DA84B649D830CB5B9AD6B478C16EC5(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.Finished_F1DA84B649D830CB5B9AD6B478C16EC5 // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void PreConstruct(bool IsDesignTime); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void Construct(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHovered(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnClicked(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.BP_OnClicked // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnDisabled(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.BP_OnDisabled // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnEnabled(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.BP_OnEnabled // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnSelected(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnDeselected(); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void SetPublicState(bool IsPublic); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.SetPublicState // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_ActivityBrowserMatchOptionButton(int32_t EntryPoint); // Function ActivityBrowserMatchOptionButton.ActivityBrowserMatchOptionButton_C.ExecuteUbergraph_ActivityBrowserMatchOptionButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

