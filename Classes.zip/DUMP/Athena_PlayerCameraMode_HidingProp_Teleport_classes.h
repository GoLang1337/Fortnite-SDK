// BlueprintGeneratedClass Athena_PlayerCameraMode_HidingProp_Teleport.Athena_PlayerCameraMode_HidingProp_Teleport_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraMode_HidingProp_Teleport_C : UAthena_PlayerCameraModeBase_C {
};

