// BlueprintGeneratedClass Border-MainModal.Border-MainModal_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-MainModal_C : UCommonBorderStyle {
};

