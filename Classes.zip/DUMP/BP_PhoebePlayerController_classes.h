// BlueprintGeneratedClass BP_PhoebePlayerController.BP_PhoebePlayerController_C
// Size: 0xf18 (Inherited: 0xf00)
struct ABP_PhoebePlayerController_C : AFortAthenaAIBotController {
	struct UFortAthenaAIBotBuildingComponent* FortAthenaAIBotBuilding; // 0xf00(0x08)
	struct UAIPerceptionComponent* AIPerception; // 0xf08(0x08)
	struct UBlackboardComponent* Blackboard1; // 0xf10(0x08)
};

