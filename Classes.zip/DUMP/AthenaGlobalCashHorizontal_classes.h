// WidgetBlueprintGeneratedClass AthenaGlobalCashHorizontal.AthenaGlobalCashHorizontal_C
// Size: 0x2f0 (Inherited: 0x2e8)
struct UAthenaGlobalCashHorizontal_C : UFortGlobalCashWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e8(0x08)

	void OnQueryStarted(); // Function AthenaGlobalCashHorizontal.AthenaGlobalCashHorizontal_C.OnQueryStarted // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnQueryCompletedSuccessfully(int32_t GlobalCashBalance); // Function AthenaGlobalCashHorizontal.AthenaGlobalCashHorizontal_C.OnQueryCompletedSuccessfully // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_AthenaGlobalCashHorizontal(int32_t EntryPoint); // Function AthenaGlobalCashHorizontal.AthenaGlobalCashHorizontal_C.ExecuteUbergraph_AthenaGlobalCashHorizontal // (Final|UbergraphFunction) // @ game+0xcda090
};

