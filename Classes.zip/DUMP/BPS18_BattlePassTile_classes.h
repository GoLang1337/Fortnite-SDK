// WidgetBlueprintGeneratedClass BPS18_BattlePassTile.BPS18_BattlePassTile_C
// Size: 0xdbb (Inherited: 0xcb8)
struct UBPS18_BattlePassTile_C : UFortBattlePassTile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xcb8(0x08)
	struct UWidgetAnimation* Hold_Completed; // 0xcc0(0x08)
	struct UWidgetAnimation* Secondary_Hold_Progress; // 0xcc8(0x08)
	struct UWidgetAnimation* Hold_Progress; // 0xcd0(0x08)
	struct UWidgetAnimation* GrowTile; // 0xcd8(0x08)
	struct UWidgetAnimation* Hover_Burst; // 0xce0(0x08)
	struct UWidgetAnimation* Reveal_Hide; // 0xce8(0x08)
	struct UWidgetAnimation* Reveal; // 0xcf0(0x08)
	struct UWidgetAnimation* TintOnpeek; // 0xcf8(0x08)
	struct UWidgetAnimation* Select; // 0xd00(0x08)
	struct UWidgetAnimation* Item_Hover; // 0xd08(0x08)
	struct UCommonVisibilitySwitcher* Availability_Switcher; // 0xd10(0x08)
	struct UOverlay* Available_State; // 0xd18(0x08)
	struct UBorder* Border_FreeViolator; // 0xd20(0x08)
	struct UImage* EmptyBackground; // 0xd28(0x08)
	struct UHorizontalBox* HB_PriceInfo; // 0xd30(0x08)
	struct UHorizontalBox* HBox_locks; // 0xd38(0x08)
	struct UImage* Image; // 0xd40(0x08)
	struct UImage* Image_33; // 0xd48(0x08)
	struct UImage* Image_Lock_Purple; // 0xd50(0x08)
	struct UImage* Image_Lock_Red; // 0xd58(0x08)
	struct UImage* Image_Owned; // 0xd60(0x08)
	struct UImage* Image_Preview; // 0xd68(0x08)
	struct UImage* Image_Progress; // 0xd70(0x08)
	struct UImage* Image_selected_LR; // 0xd78(0x08)
	struct UImage* Image_selected_TB; // 0xd80(0x08)
	struct UImage* Locked_Overlay; // 0xd88(0x08)
	struct UImage* OffscreenOverlay; // 0xd90(0x08)
	struct UOverlay* Overlay_Delayed; // 0xd98(0x08)
	struct UOverlay* Overlay_input; // 0xda0(0x08)
	struct UCommonTextBlock* Text_Price; // 0xda8(0x08)
	struct UCommonVisibilitySwitcher* VisibilitySwitcher_Included; // 0xdb0(0x08)
	bool has prerequisite; // 0xdb8(0x01)
	bool Selected; // 0xdb9(0x01)
	bool Hovered; // 0xdba(0x01)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnRevealed(); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnRevealed // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void OnPeeked(); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnPeeked // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void OnSetCurrencyAndPrice(enum class EBattlePassCurrencyType Currency, int32_t Price); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnSetCurrencyAndPrice // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnAffordabilityChanged(bool bHasEnougCurrency); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnAffordabilityChanged // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnSetTrack(bool bIsFreeTrack, bool bOwnsBattlePass); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnSetTrack // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnLockedProgressUpdated(float Progress, int32_t CurrentlyOwnedRewards, int32_t NeededRewards); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnLockedProgressUpdated // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnPreviewed(); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnPreviewed // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void OnStateChanged(enum class BattlePassTileAvailabilityStates NewState); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnStateChanged // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnUnpreviewed(); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnUnpreviewed // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHovered(); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldStarted(float HoldPercentage, bool bInUseSecondaryHoldAnimation); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.BP_OnHoldStarted // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldEnded(float HoldPercentage, bool bInUseSecondaryHoldAnimation); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.BP_OnHoldEnded // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnHighlighted(); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnHighlighted // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnUnhighlighted(); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnUnhighlighted // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnLockedStateUpdated(bool OwnsBattlePass, bool ParentUnlocked, bool HasRemainingPrerequisites, bool bIsDelayed); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.OnLockedStateUpdated // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldReset(); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.BP_OnHoldReset // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldCompleted(); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.BP_OnHoldCompleted // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_BattlePassTile(int32_t EntryPoint); // Function BPS18_BattlePassTile.BPS18_BattlePassTile_C.ExecuteUbergraph_BPS18_BattlePassTile // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

