// BlueprintGeneratedClass ButtonStyle-Outline-Skew-Blue.ButtonStyle-Outline-Skew-Blue_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Outline-Skew-Blue_C : UCommonButtonStyle {
};

