// BlueprintGeneratedClass Bathroom_ToiletBowl01.Bathroom_ToiletBowl01_C
// Size: 0xcb8 (Inherited: 0xcb8)
struct ABathroom_ToiletBowl01_C : ABuildingProp {
};

