// BlueprintGeneratedClass Athena_PlayerCameraModeTargetingLauncherGrenade.Athena_PlayerCameraModeTargetingLauncherGrenade_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeTargetingLauncherGrenade_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

