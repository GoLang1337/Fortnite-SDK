// BlueprintGeneratedClass ButtonStyle-Right.ButtonStyle-Right_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Right_C : UCommonButtonStyle {
};

