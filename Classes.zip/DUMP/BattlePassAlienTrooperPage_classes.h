// WidgetBlueprintGeneratedClass BattlePassAlienTrooperPage.BattlePassAlienTrooperPage_C
// Size: 0x4d0 (Inherited: 0x4c0)
struct UBattlePassAlienTrooperPage_C : UFortBattlePassCustomSkinPageS17 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4c0(0x08)
	struct UWidgetAnimation* Intro; // 0x4c8(0x08)

	void BP_OnActivated(); // Function BattlePassAlienTrooperPage.BattlePassAlienTrooperPage_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BattlePassAlienTrooperPage(int32_t EntryPoint); // Function BattlePassAlienTrooperPage.BattlePassAlienTrooperPage_C.ExecuteUbergraph_BattlePassAlienTrooperPage // (Final|UbergraphFunction) // @ game+0xcda090
};

