// BlueprintGeneratedClass BGA_Athena_Keycard_Lock_Date.BGA_Athena_Keycard_Lock_Date_C
// Size: 0xae9 (Inherited: 0xae9)
struct ABGA_Athena_Keycard_Lock_Date_C : ABGA_Athena_Keycard_Lock_Parent_C {
};

