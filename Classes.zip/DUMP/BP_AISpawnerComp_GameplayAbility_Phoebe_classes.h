// BlueprintGeneratedClass BP_AISpawnerComp_GameplayAbility_Phoebe.BP_AISpawnerComp_GameplayAbility_Phoebe_C
// Size: 0x70 (Inherited: 0x70)
struct UBP_AISpawnerComp_GameplayAbility_Phoebe_C : UFortAthenaAISpawnerDataComponent_AIBotGameplayAbilityBase {
};

