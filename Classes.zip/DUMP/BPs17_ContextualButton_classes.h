// WidgetBlueprintGeneratedClass BPs17_ContextualButton.BPs17_ContextualButton_C
// Size: 0xd30 (Inherited: 0xc50)
struct UBPs17_ContextualButton_C : UFortHoldableButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc50(0x08)
	struct UWidgetAnimation* HoldCompleted; // 0xc58(0x08)
	struct UWidgetAnimation* HoldProgress; // 0xc60(0x08)
	struct UWidgetAnimation* Hover; // 0xc68(0x08)
	struct UCommonTextBlock* Button_text; // 0xc70(0x08)
	struct UImage* Image_Icon; // 0xc78(0x08)
	struct UImage* Image_material; // 0xc80(0x08)
	struct UImage* Image_Progress; // 0xc88(0x08)
	struct USizeBox* SizeBox_1; // 0xc90(0x08)
	struct USpacer* Spacer_Icon; // 0xc98(0x08)
	struct UCommonTextBlock* Text_Subtitle; // 0xca0(0x08)
	struct UCommonActionWidget* UnbindedInputActionWidget; // 0xca8(0x08)
	struct FText In Text; // 0xcb0(0x18)
	float In Width Override; // 0xcc8(0x04)
	char pad_CCC[0x4]; // 0xccc(0x04)
	struct UMaterialInterface* Material; // 0xcd0(0x08)
	enum class ETextJustify Justification; // 0xcd8(0x01)
	char pad_CD9[0x7]; // 0xcd9(0x07)
	struct UMaterialInstanceDynamic* HoldProgressDMI; // 0xce0(0x08)
	struct FText In SubText; // 0xce8(0x18)
	bool Show BP icon; // 0xd00(0x01)
	char pad_D01[0x3]; // 0xd01(0x03)
	int32_t Size; // 0xd04(0x04)
	float In Height Override; // 0xd08(0x04)
	char pad_D0C[0x4]; // 0xd0c(0x04)
	struct UAudioComponent* FillingSoundAudioComponent; // 0xd10(0x08)
	struct USoundBase* FillingSoundOverride; // 0xd18(0x08)
	struct USoundBase* FillCompleteSoundOverride; // 0xd20(0x08)
	struct UObject* Font Material; // 0xd28(0x08)

	void BP_OnHoldStarted(float HoldPercentage, bool bInUseSecondaryHoldAnimation); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.BP_OnHoldStarted // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnHoldEnded(float HoldPercentage, bool bInUseSecondaryHoldAnimation); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.BP_OnHoldEnded // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnHoldCompleted(); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.BP_OnHoldCompleted // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnHoldIncreased(float HoldPercentage); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.BP_OnHoldIncreased // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnHoldDecreased(float HoldPercentage); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.BP_OnHoldDecreased // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnHoldReset(); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.BP_OnHoldReset // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnPressed(); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.BP_OnPressed // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnUnhovered(); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnHovered(); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void Construct(); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void PreConstruct(bool IsDesignTime); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void Destruct(); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void PlayFillSound(); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.PlayFillSound // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void FillComplete(); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.FillComplete // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void StopFillSound(); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.StopFillSound // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BPs17_ContextualButton(int32_t EntryPoint); // Function BPs17_ContextualButton.BPs17_ContextualButton_C.ExecuteUbergraph_BPs17_ContextualButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

