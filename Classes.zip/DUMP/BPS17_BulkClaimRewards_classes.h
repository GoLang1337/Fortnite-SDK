// WidgetBlueprintGeneratedClass BPS17_BulkClaimRewards.BPS17_BulkClaimRewards_C
// Size: 0x4ec (Inherited: 0x4a0)
struct UBPS17_BulkClaimRewards_C : UFortBattlePassBulkBuyPageS17 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a0(0x08)
	struct UWidgetAnimation* Intro; // 0x4a8(0x08)
	struct UCommonRichTextBlock* CommonRichTextBlock_186; // 0x4b0(0x08)
	struct UCommonTextBlock* Cost; // 0x4b8(0x08)
	struct UImage* Image_132; // 0x4c0(0x08)
	struct UImage* Image_232; // 0x4c8(0x08)
	struct UCommonTextBlock* Text_LevelsAmount; // 0x4d0(0x08)
	struct UCommonTextBlock* Title; // 0x4d8(0x08)
	int32_t First Page to Claim; // 0x4e0(0x04)
	int32_t Last Page to Claim; // 0x4e4(0x04)
	int32_t Add One; // 0x4e8(0x04)

	void OnPageRangeChanged(int32_t FromPage, int32_t ToPage); // Function BPS17_BulkClaimRewards.BPS17_BulkClaimRewards_C.OnPageRangeChanged // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnRewardCountChanged(int32_t Count); // Function BPS17_BulkClaimRewards.BPS17_BulkClaimRewards_C.OnRewardCountChanged // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnCostChanged(int32_t Cost); // Function BPS17_BulkClaimRewards.BPS17_BulkClaimRewards_C.OnCostChanged // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void BP_OnActivated(); // Function BPS17_BulkClaimRewards.BPS17_BulkClaimRewards_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BPS17_BulkClaimRewards(int32_t EntryPoint); // Function BPS17_BulkClaimRewards.BPS17_BulkClaimRewards_C.ExecuteUbergraph_BPS17_BulkClaimRewards // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

