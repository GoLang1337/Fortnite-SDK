// BlueprintGeneratedClass Athena_PlayerCameraModeSniper.Athena_PlayerCameraModeSniper_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeSniper_C : UAthena_PlayerCameraModeRanged_C {
};

