// BlueprintGeneratedClass Athena_PlayerCameraModeTargetingIronSight.Athena_PlayerCameraModeTargetingIronSight_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeTargetingIronSight_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

