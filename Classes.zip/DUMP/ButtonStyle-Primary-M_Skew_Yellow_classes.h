// BlueprintGeneratedClass ButtonStyle-Primary-M_Skew_Yellow.ButtonStyle-Primary-M_Skew_Yellow_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Primary-M_Skew_Yellow_C : UCommonButtonStyle {
};

