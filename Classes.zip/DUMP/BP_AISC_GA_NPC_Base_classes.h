// BlueprintGeneratedClass BP_AISC_GA_NPC_Base.BP_AISC_GA_NPC_Base_C
// Size: 0x70 (Inherited: 0x70)
struct UBP_AISC_GA_NPC_Base_C : UFortAthenaAISpawnerDataComponent_AIBotGameplayAbilityBase {
};

