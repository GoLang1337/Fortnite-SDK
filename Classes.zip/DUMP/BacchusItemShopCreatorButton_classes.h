// WidgetBlueprintGeneratedClass BacchusItemShopCreatorButton.BacchusItemShopCreatorButton_C
// Size: 0xcea (Inherited: 0xcc8)
struct UBacchusItemShopCreatorButton_C : UFortTextButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xcc8(0x08)
	struct UWidgetAnimation* Hover; // 0xcd0(0x08)
	struct UImage* Backing; // 0xcd8(0x08)
	struct UImage* IMG_Arrow; // 0xce0(0x08)
	bool bFlipArrow; // 0xce8(0x01)
	bool bIsTop; // 0xce9(0x01)

	void BP_OnHovered(); // Function BacchusItemShopCreatorButton.BacchusItemShopCreatorButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnUnhovered(); // Function BacchusItemShopCreatorButton.BacchusItemShopCreatorButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BacchusItemShopCreatorButton(int32_t EntryPoint); // Function BacchusItemShopCreatorButton.BacchusItemShopCreatorButton_C.ExecuteUbergraph_BacchusItemShopCreatorButton // (Final|UbergraphFunction) // @ game+0xcda090
};

