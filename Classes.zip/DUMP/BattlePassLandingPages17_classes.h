// WidgetBlueprintGeneratedClass BattlePassLandingPages17.BattlePassLandingPages17_C
// Size: 0x53a (Inherited: 0x490)
struct UBattlePassLandingPages17_C : UBattlePassLandingPageS17 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x490(0x08)
	struct UWidgetAnimation* Intro; // 0x498(0x08)
	struct UHorizontalBox* HorizontalBox_OwnBP; // 0x4a0(0x08)
	struct USeasonalDataWidget_C* SeasonDataWidget; // 0x4a8(0x08)
	struct UCommonVisibilitySwitcher* Switcher_BottonButtons; // 0x4b0(0x08)
	struct FMulticastInlineDelegate On show BP character; // 0x4b8(0x10)
	struct FMulticastInlineDelegate On show Custo Character; // 0x4c8(0x10)
	struct FMulticastInlineDelegate On show Mystery Character; // 0x4d8(0x10)
	struct FMulticastInlineDelegate On show Bonus Character; // 0x4e8(0x10)
	struct FMulticastInlineDelegate On show Crew Character; // 0x4f8(0x10)
	struct FMulticastInlineDelegate On show Buy BP; // 0x508(0x10)
	struct FMulticastInlineDelegate On show Buy Level; // 0x518(0x10)
	struct FMulticastInlineDelegate On show Gift Battle Pass; // 0x528(0x10)
	bool own BP; // 0x538(0x01)
	bool is time locked; // 0x539(0x01)

	void SequenceEvent__ENTRYPOINTBattlePassLandingPages17_8(struct UBattlePassS17_LandingPage_SmallButton_C* Button_BuyBattlePass); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.SequenceEvent__ENTRYPOINTBattlePassLandingPages17_8 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SequenceEvent__ENTRYPOINTBattlePassLandingPages17_7(struct UBattlePassS17_LandingPage_SmallButton_C* Button_GiftBattlePass); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.SequenceEvent__ENTRYPOINTBattlePassLandingPages17_7 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SequenceEvent__ENTRYPOINTBattlePassLandingPages17_6(struct UBattlePassS17_LandingPage_SmallButton_C* Button_BuyResources); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.SequenceEvent__ENTRYPOINTBattlePassLandingPages17_6 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SequenceEvent__ENTRYPOINTBattlePassLandingPages17_5(struct UBattlePassLandingPageButtonS17_C* Button_JoinSubscription); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.SequenceEvent__ENTRYPOINTBattlePassLandingPages17_5 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SequenceEvent__ENTRYPOINTBattlePassLandingPages17_4(struct UBattlePassLandingPageButtonS17_C* Button_BonusRewards); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.SequenceEvent__ENTRYPOINTBattlePassLandingPages17_4 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SequenceEvent__ENTRYPOINTBattlePassLandingPages17_3(struct UBattlePassLandingPageButtonS17_C* Button_MysteryRewards); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.SequenceEvent__ENTRYPOINTBattlePassLandingPages17_3 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SequenceEvent__ENTRYPOINTBattlePassLandingPages17_2(struct UBattlePassLandingPageButtonS17_C* Button_CharacterCustomizer); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.SequenceEvent__ENTRYPOINTBattlePassLandingPages17_2 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SequenceEvent__ENTRYPOINTBattlePassLandingPages17_1(struct UBattlePassLandingPageButtonS17_C* Button_RewardOverview); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.SequenceEvent__ENTRYPOINTBattlePassLandingPages17_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Play intro(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.Play intro // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Button_RewardOverview_Event_3(struct UBattlePassLandingPageButtonS17_C* Button_RewardOverview); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.Button_RewardOverview_Event_3 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Button_CharacterCustomizer_Event_1(struct UBattlePassLandingPageButtonS17_C* Button_CharacterCustomizer); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.Button_CharacterCustomizer_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Button_MysteryRewards_Event_1(struct UBattlePassLandingPageButtonS17_C* Button_MysteryRewards); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.Button_MysteryRewards_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Button_BonusRewards_Event_1(struct UBattlePassLandingPageButtonS17_C* Button_BonusRewards); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.Button_BonusRewards_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Button_JoinSubscription_Event_1(struct UBattlePassLandingPageButtonS17_C* Button_JoinSubscription); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.Button_JoinSubscription_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Button_BuyResources_Event_1(struct UBattlePassS17_LandingPage_SmallButton_C* Button_BuyResources); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.Button_BuyResources_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Button_GiftBattlePass_Event_1(struct UBattlePassS17_LandingPage_SmallButton_C* Button_GiftBattlePass); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.Button_GiftBattlePass_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Button_BuyBattlePass_Event_1(struct UBattlePassS17_LandingPage_SmallButton_C* Button_BuyBattlePass); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.Button_BuyBattlePass_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnBattlePassOwned(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.OnBattlePassOwned // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void BndEvt__Button_RewardOverview_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.BndEvt__Button_RewardOverview_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__Button_CharacterCustomizer_K2Node_ComponentBoundEvent_1_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.BndEvt__Button_CharacterCustomizer_K2Node_ComponentBoundEvent_1_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__Button_MysteryRewards_K2Node_ComponentBoundEvent_2_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.BndEvt__Button_MysteryRewards_K2Node_ComponentBoundEvent_2_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__Button_BonusRewards_K2Node_ComponentBoundEvent_3_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.BndEvt__Button_BonusRewards_K2Node_ComponentBoundEvent_3_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__Button_JoinSubscription_K2Node_ComponentBoundEvent_4_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.BndEvt__Button_JoinSubscription_K2Node_ComponentBoundEvent_4_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__Button_BuyBattlePass_K2Node_ComponentBoundEvent_5_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.BndEvt__Button_BuyBattlePass_K2Node_ComponentBoundEvent_5_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__Button_Quests_K2Node_ComponentBoundEvent_6_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.BndEvt__Button_Quests_K2Node_ComponentBoundEvent_6_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void BndEvt__Button_GiftBattlePass_K2Node_ComponentBoundEvent_7_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.BndEvt__Button_GiftBattlePass_K2Node_ComponentBoundEvent_7_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void On BattlePass completed(bool BPComplete); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.On BattlePass completed // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnEnterSubPage(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.OnEnterSubPage // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void On Level Changed(int32_t Level); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.On Level Changed // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnBattlePassGiftingAllowed(bool bGiftingAllowed); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.OnBattlePassGiftingAllowed // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnBattlePassSubscriptionAllowed(bool bSubscriptionAllowed); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.OnBattlePassSubscriptionAllowed // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void Set Quest Page Delay(bool Is locked); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.Set Quest Page Delay // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BattlePassLandingPages17(int32_t EntryPoint); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.ExecuteUbergraph_BattlePassLandingPages17 // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
	void On show Gift Battle Pass__DelegateSignature(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.On show Gift Battle Pass__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void On show Buy Level__DelegateSignature(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.On show Buy Level__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void On show Buy BP__DelegateSignature(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.On show Buy BP__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void On show Crew Character__DelegateSignature(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.On show Crew Character__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void On show Bonus Character__DelegateSignature(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.On show Bonus Character__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void On show Mystery Character__DelegateSignature(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.On show Mystery Character__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void On show Custo Character__DelegateSignature(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.On show Custo Character__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void On show BP character__DelegateSignature(); // Function BattlePassLandingPages17.BattlePassLandingPages17_C.On show BP character__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
};

