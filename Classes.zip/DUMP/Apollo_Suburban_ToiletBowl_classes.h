// BlueprintGeneratedClass Apollo_Suburban_ToiletBowl.Apollo_Suburban_ToiletBowl_C
// Size: 0xcb8 (Inherited: 0xcb8)
struct AApollo_Suburban_ToiletBowl_C : ABuildingProp {
};

