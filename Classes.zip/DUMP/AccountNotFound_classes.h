// WidgetBlueprintGeneratedClass AccountNotFound.AccountNotFound_C
// Size: 0x498 (Inherited: 0x498)
struct UAccountNotFound_C : UFortAccountNotFound {
};

