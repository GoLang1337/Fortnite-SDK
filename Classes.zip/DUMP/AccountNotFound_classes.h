// WidgetBlueprintGeneratedClass AccountNotFound.AccountNotFound_C
// Size: 0x4a8 (Inherited: 0x4a8)
struct UAccountNotFound_C : UFortAccountNotFound {
};

