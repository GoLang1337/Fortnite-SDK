// BlueprintGeneratedClass BP_BattleMapPawnLive.BP_BattleMapPawnLive_C
// Size: 0x578 (Inherited: 0x578)
struct ABP_BattleMapPawnLive_C : ABattleMapPawnLive {
};

