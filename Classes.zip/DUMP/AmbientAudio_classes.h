// Class AmbientAudio.AmbientAudioComponent
// Size: 0xd0 (Inherited: 0xb8)
struct UAmbientAudioComponent : UAudioGameplayComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	struct UAmbientAudioDataAsset* AmbientAsset; // 0xc0(0x08)
	int32_t Priority; // 0xc8(0x04)
	float CrossfadeTime; // 0xcc(0x04)

	void SetPriority(int32_t InPriority); // Function AmbientAudio.AmbientAudioComponent.SetPriority // (Final|Native|Public|BlueprintCallable) // @ game+0x4288fc4
	void SetCrossfadeTime(float InCrossfadeTime); // Function AmbientAudio.AmbientAudioComponent.SetCrossfadeTime // (Final|Native|Public|BlueprintCallable) // @ game+0x4288de0
	void SetAmbientAsset(struct UAmbientAudioDataAsset* InAmbientAsset); // Function AmbientAudio.AmbientAudioComponent.SetAmbientAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x4288c94
};

// Class AmbientAudio.AmbientAudioDataAsset
// Size: 0x58 (Inherited: 0x30)
struct UAmbientAudioDataAsset : UDataAsset {
	struct TArray<struct FAmbientAudioLoop> LoopingSounds; // 0x30(0x10)
	struct TArray<struct FAmbientAudioOneShot> OneShotSounds; // 0x40(0x10)
	float TagCrossfadeTime; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class AmbientAudio.AmbientAudioSubsystem
// Size: 0x238 (Inherited: 0x30)
struct UAmbientAudioSubsystem : UWorldSubsystem {
	char pad_30[0x8]; // 0x30(0x08)
	struct FMulticastInlineDelegate OnTagChanged; // 0x38(0x10)
	struct FMulticastInlineDelegate OnEntryChanged; // 0x48(0x10)
	struct TArray<struct AAmbientVolume*> GlobalVolumes; // 0x58(0x10)
	char pad_68[0x1d0]; // 0x68(0x1d0)

	void RemoveGameplayTag(struct FGameplayTag GameplayTag); // Function AmbientAudio.AmbientAudioSubsystem.RemoveGameplayTag // (Final|Native|Public|BlueprintCallable) // @ game+0x23abd88
	void RemoveAmbientEntry(struct FName AmbientName); // Function AmbientAudio.AmbientAudioSubsystem.RemoveAmbientEntry // (Final|Native|Public|BlueprintCallable) // @ game+0x4288b60
	void AddGameplayTag(struct FGameplayTag GameplayTag); // Function AmbientAudio.AmbientAudioSubsystem.AddGameplayTag // (Final|Native|Public|BlueprintCallable) // @ game+0x4288ac8
	void AddAmbientEntry(struct FName AmbientName, struct UAmbientAudioDataAsset* Asset, int32_t Priority, float CrossfadeTime); // Function AmbientAudio.AmbientAudioSubsystem.AddAmbientEntry // (Final|Native|Public|BlueprintCallable) // @ game+0x216ebe4
};

// Class AmbientAudio.AmbientVolume
// Size: 0x270 (Inherited: 0x258)
struct AAmbientVolume : AVolume {
	struct UAmbientAudioDataAsset* AmbientAsset; // 0x258(0x08)
	int32_t Priority; // 0x260(0x04)
	float CrossfadeTime; // 0x264(0x04)
	char bEnabled : 1; // 0x268(0x01)
	char bGlobal : 1; // 0x268(0x01)
	char pad_268_2 : 6; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)

	void SetPriority(int32_t NewPriority); // Function AmbientAudio.AmbientVolume.SetPriority // (Final|Native|Public|BlueprintCallable) // @ game+0x4288f2c
	void SetEnabled(bool bNewEnabled); // Function AmbientAudio.AmbientVolume.SetEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x4288e90
	void SetCrossfadeTime(float NewCrossfadeTime); // Function AmbientAudio.AmbientVolume.SetCrossfadeTime // (Final|Native|Public|BlueprintCallable) // @ game+0x4288d40
	void SetAmbientAsset(struct UAmbientAudioDataAsset* NewAmbientAsset); // Function AmbientAudio.AmbientVolume.SetAmbientAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x4288bf8
	void OnRep_bEnabled(); // Function AmbientAudio.AmbientVolume.OnRep_bEnabled // (Native|Protected) // @ game+0x1d238fc
};

