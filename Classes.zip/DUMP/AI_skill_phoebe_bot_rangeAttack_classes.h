// BlueprintGeneratedClass AI_skill_phoebe_bot_rangeAttack.AI_skill_phoebe_bot_rangeAttack_C
// Size: 0x40 (Inherited: 0x40)
struct UAI_skill_phoebe_bot_rangeAttack_C : UFortAthenaAIBotRangeAttackSkillSet {
};

