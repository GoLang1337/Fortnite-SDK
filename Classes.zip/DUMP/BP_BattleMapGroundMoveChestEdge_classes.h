// BlueprintGeneratedClass BP_BattleMapGroundMoveChestEdge.BP_BattleMapGroundMoveChestEdge_C
// Size: 0x288 (Inherited: 0x288)
struct ABP_BattleMapGroundMoveChestEdge_C : ABP_BattleMapBaseEdge_C {
};

