// WidgetBlueprintGeneratedClass BPS17_BattleStarModal.BPS17_BattleStarModal_C
// Size: 0x4f8 (Inherited: 0x3d8)
struct UBPS17_BattleStarModal_C : UFortBattlePassPurchaseResourcesWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d8(0x08)
	struct UWidgetAnimation* PageEnough; // 0x3e0(0x08)
	struct UWidgetAnimation* Intro; // 0x3e8(0x08)
	struct UCommonTextBlock* BattlerStarHeader; // 0x3f0(0x08)
	struct UImage* BattleStarIcon; // 0x3f8(0x08)
	struct UImage* DividerLine; // 0x400(0x08)
	struct UImage* HeaderIcon; // 0x408(0x08)
	struct UImage* Image; // 0x410(0x08)
	struct UImage* Image_2; // 0x418(0x08)
	struct UImage* Image_122; // 0x420(0x08)
	struct UImage* Image_179; // 0x428(0x08)
	struct UImage* Image_210; // 0x430(0x08)
	struct UImage* Image_232; // 0x438(0x08)
	struct UImage* Image_242; // 0x440(0x08)
	struct UImage* Image_bigstar; // 0x448(0x08)
	struct UImage* Image_DarkBackground; // 0x450(0x08)
	struct UImage* Image_Left; // 0x458(0x08)
	struct UImage* Image_Right; // 0x460(0x08)
	struct UOverlay* OriginalCostContainer; // 0x468(0x08)
	struct UCommonRichTextBlock* RichText_UnlockPage; // 0x470(0x08)
	struct USafeZone* SafeZone_27; // 0x478(0x08)
	struct UImage* Strikethrough; // 0x480(0x08)
	struct UCommonVisibilitySwitcher* Switcher_PurchaseButtons; // 0x488(0x08)
	struct USafeZone* SZ_Currency; // 0x490(0x08)
	struct USafeZone* SZ_Legal; // 0x498(0x08)
	struct USafeZone* SZ_MainHeader; // 0x4a0(0x08)
	struct UCommonTextBlock* Text_CurrentBattleStar; // 0x4a8(0x08)
	struct UCommonTextBlock* Text_CurrentVBucks; // 0x4b0(0x08)
	struct UCommonTextBlock* Text_FinalCoin; // 0x4b8(0x08)
	struct UCommonTextBlock* Text_HeaderTitle; // 0x4c0(0x08)
	struct UCommonTextBlock* Text_LevelsAmount; // 0x4c8(0x08)
	struct UCommonTextBlock* Text_OriginalCost; // 0x4d0(0x08)
	struct UImage* VBuck; // 0x4d8(0x08)
	struct UImage* VBuckIcon; // 0x4e0(0x08)
	int32_t BattleStarAmount; // 0x4e8(0x04)
	int32_t Rebate Amount; // 0x4ec(0x04)
	int32_t Last Page to unlock; // 0x4f0(0x04)
	int32_t New Page to unlock; // 0x4f4(0x04)

	void Randomize stars hovering(); // Function BPS17_BattleStarModal.BPS17_BattleStarModal_C.Randomize stars hovering // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BP_OnActivated(); // Function BPS17_BattleStarModal.BPS17_BattleStarModal_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnTotalPriceChanged(int32_t NewPrice); // Function BPS17_BattleStarModal.BPS17_BattleStarModal_C.OnTotalPriceChanged // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnPurchaseAmountChanged(int32_t NewAmount); // Function BPS17_BattleStarModal.BPS17_BattleStarModal_C.OnPurchaseAmountChanged // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnOfferUnavailable(); // Function BPS17_BattleStarModal.BPS17_BattleStarModal_C.OnOfferUnavailable // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void Construct(); // Function BPS17_BattleStarModal.BPS17_BattleStarModal_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void PreConstruct(bool IsDesignTime); // Function BPS17_BattleStarModal.BPS17_BattleStarModal_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BPS17_BattleStarModal(int32_t EntryPoint); // Function BPS17_BattleStarModal.BPS17_BattleStarModal_C.ExecuteUbergraph_BPS17_BattleStarModal // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

