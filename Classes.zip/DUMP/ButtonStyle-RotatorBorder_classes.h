// BlueprintGeneratedClass ButtonStyle-RotatorBorder.ButtonStyle-RotatorBorder_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-RotatorBorder_C : UCommonButtonStyle {
};

