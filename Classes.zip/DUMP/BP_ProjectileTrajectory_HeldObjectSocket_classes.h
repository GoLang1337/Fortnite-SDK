// BlueprintGeneratedClass BP_ProjectileTrajectory_HeldObjectSocket.BP_ProjectileTrajectory_HeldObjectSocket_C
// Size: 0x278 (Inherited: 0x269)
struct ABP_ProjectileTrajectory_HeldObjectSocket_C : ABP_ProjectileTrajectory_C {
	char pad_269[0x7]; // 0x269(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)

	void ReceiveBeginPlay(); // Function BP_ProjectileTrajectory_HeldObjectSocket.BP_ProjectileTrajectory_HeldObjectSocket_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BP_ProjectileTrajectory_HeldObjectSocket(int32_t EntryPoint); // Function BP_ProjectileTrajectory_HeldObjectSocket.BP_ProjectileTrajectory_HeldObjectSocket_C.ExecuteUbergraph_BP_ProjectileTrajectory_HeldObjectSocket // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

