// BlueprintGeneratedClass BPS17_AboutModal_Decorator.BPS17_AboutModal_Decorator_C
// Size: 0x30 (Inherited: 0x30)
struct UBPS17_AboutModal_Decorator_C : URichTextBlockImageDecorator {
};

