// WidgetBlueprintGeneratedClass BPS18_BuyResourcesBundleCheckBox.BPS18_BuyResourcesBundleCheckBox_C
// Size: 0xc20 (Inherited: 0xbd8)
struct UBPS18_BuyResourcesBundleCheckBox_C : UFortBattlePassCheckBoxButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd8(0x08)
	struct UWidgetAnimation* Hover; // 0xbe0(0x08)
	struct UWidgetAnimation* Check; // 0xbe8(0x08)
	struct UWidgetAnimation* burst; // 0xbf0(0x08)
	struct UHorizontalBox* HB_BundleText; // 0xbf8(0x08)
	struct UImage* Image_burst; // 0xc00(0x08)
	struct UImage* Image_Check; // 0xc08(0x08)
	struct UImage* Image_Checkbox; // 0xc10(0x08)
	struct UCommonRichTextBlock* TextBlock; // 0xc18(0x08)

	void OnStateChanged(bool bNewIsChecked); // Function BPS18_BuyResourcesBundleCheckBox.BPS18_BuyResourcesBundleCheckBox_C.OnStateChanged // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHovered(); // Function BPS18_BuyResourcesBundleCheckBox.BPS18_BuyResourcesBundleCheckBox_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function BPS18_BuyResourcesBundleCheckBox.BPS18_BuyResourcesBundleCheckBox_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void Construct(); // Function BPS18_BuyResourcesBundleCheckBox.BPS18_BuyResourcesBundleCheckBox_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_BuyResourcesBundleCheckBox(int32_t EntryPoint); // Function BPS18_BuyResourcesBundleCheckBox.BPS18_BuyResourcesBundleCheckBox_C.ExecuteUbergraph_BPS18_BuyResourcesBundleCheckBox // (Final|UbergraphFunction) // @ game+0xccddc0
};

