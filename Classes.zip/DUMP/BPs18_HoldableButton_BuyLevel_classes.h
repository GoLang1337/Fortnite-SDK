// WidgetBlueprintGeneratedClass BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C
// Size: 0xce8 (Inherited: 0xc50)
struct UBPS18_HoldableButton_BuyLevel_C : UFortHoldableButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc50(0x08)
	struct UWidgetAnimation* HoldCompleted; // 0xc58(0x08)
	struct UWidgetAnimation* HoldProgress; // 0xc60(0x08)
	struct UWidgetAnimation* Hover; // 0xc68(0x08)
	struct UCommonTextBlock* Button_text; // 0xc70(0x08)
	struct UImage* Image_material; // 0xc78(0x08)
	struct USizeBox* SizeBox_1; // 0xc80(0x08)
	struct UCommonTextBlock* Text_Subtitle; // 0xc88(0x08)
	struct UCommonActionWidget* UnbindedInputActionWidget; // 0xc90(0x08)
	struct FText In Text; // 0xc98(0x18)
	float In Width Override; // 0xcb0(0x04)
	char pad_CB4[0x4]; // 0xcb4(0x04)
	struct UMaterialInterface* Material; // 0xcb8(0x08)
	struct UMaterialInstanceDynamic* HoldProgressDMI; // 0xcc0(0x08)
	int32_t Size; // 0xcc8(0x04)
	float In Height Override; // 0xccc(0x04)
	struct UAudioComponent* FillingSoundAudioComponent; // 0xcd0(0x08)
	struct USoundBase* FillingSoundOverride; // 0xcd8(0x08)
	struct USoundBase* FillCompleteSoundOverride; // 0xce0(0x08)

	void BP_OnUnhovered(); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldStarted(float HoldPercentage, bool bInUseSecondaryHoldAnimation); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.BP_OnHoldStarted // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldEnded(float HoldPercentage, bool bInUseSecondaryHoldAnimation); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.BP_OnHoldEnded // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldCompleted(); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.BP_OnHoldCompleted // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldIncreased(float HoldPercentage); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.BP_OnHoldIncreased // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldDecreased(float HoldPercentage); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.BP_OnHoldDecreased // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldReset(); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.BP_OnHoldReset // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnPressed(); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.BP_OnPressed // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHovered(); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void PreConstruct(bool IsDesignTime); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void Construct(); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void Destruct(); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void PlayFillSound(); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.PlayFillSound // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void FillComplete(); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.FillComplete // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void StopFillSound(); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.StopFillSound // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_HoldableButton_BuyLevel(int32_t EntryPoint); // Function BPs18_HoldableButton_BuyLevel.BPS18_HoldableButton_BuyLevel_C.ExecuteUbergraph_BPS18_HoldableButton_BuyLevel // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

