// BlueprintGeneratedClass BB_HoagieMoveDown.BB_HoagieMoveDown_C
// Size: 0xf8 (Inherited: 0xf8)
struct UBB_HoagieMoveDown_C : UFortMobileActionButtonBehavior {
};

