// BlueprintGeneratedClass Barrel_FishingRod_Container_Athena.Barrel_FishingRod_Container_Athena_C
// Size: 0xf69 (Inherited: 0xf69)
struct ABarrel_FishingRod_Container_Athena_C : AHotfix_Container_Parent_C {
};

