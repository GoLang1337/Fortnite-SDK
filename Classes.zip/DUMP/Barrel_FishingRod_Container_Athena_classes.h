// BlueprintGeneratedClass Barrel_FishingRod_Container_Athena.Barrel_FishingRod_Container_Athena_C
// Size: 0xea1 (Inherited: 0xea1)
struct ABarrel_FishingRod_Container_Athena_C : AHotfix_Container_Parent_C {
};

