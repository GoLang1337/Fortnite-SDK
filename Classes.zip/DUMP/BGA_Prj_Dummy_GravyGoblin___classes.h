// BlueprintGeneratedClass BGA_Prj_Dummy_GravyGoblin__.BGA_Prj_Dummy_GravyGoblin___C
// Size: 0x8e0 (Inherited: 0x8cc)
struct ABGA_Prj_Dummy_GravyGoblin___C : ABGA_Athena_Physics_Parent_C {
	bool Thrown; // 0x8cc(0x01)
	char pad_8CD[0x3]; // 0x8cd(0x03)
	struct UFortWorldItemDefinition* ItemDef; // 0x8d0(0x08)
	struct AFortPickup* AttachedPickup; // 0x8d8(0x08)
};

