// BlueprintGeneratedClass ButtonStyle_PageChevron_Right.ButtonStyle_PageChevron_Right_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_PageChevron_Right_C : UButtonStyle-MediumTransparentNoCues_C {
};

