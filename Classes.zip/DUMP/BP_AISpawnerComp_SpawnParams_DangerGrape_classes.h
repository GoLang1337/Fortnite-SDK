// BlueprintGeneratedClass BP_AISpawnerComp_SpawnParams_DangerGrape.BP_AISpawnerComp_SpawnParams_DangerGrape_C
// Size: 0x60 (Inherited: 0x60)
struct UBP_AISpawnerComp_SpawnParams_DangerGrape_C : UBP_AISpawnerComp_SpawnParams_Phoebe_C {
};

