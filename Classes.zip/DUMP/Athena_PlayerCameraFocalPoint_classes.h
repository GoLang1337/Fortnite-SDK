// BlueprintGeneratedClass Athena_PlayerCameraFocalPoint.Athena_PlayerCameraFocalPoint_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraFocalPoint_C : UFortCameraMode_FocalPoint {
};

