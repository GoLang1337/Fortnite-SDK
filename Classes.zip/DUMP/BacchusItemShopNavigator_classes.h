// WidgetBlueprintGeneratedClass BacchusItemShopNavigator.BacchusItemShopNavigator_C
// Size: 0x2d0 (Inherited: 0x2c0)
struct UBacchusItemShopNavigator_C : UAthenaItemShopSectionNavigator {
	struct USafeZone* ForceDownSafeZone; // 0x2c0(0x08)
	struct USafeZone* ForceUpSaveZone; // 0x2c8(0x08)
};

