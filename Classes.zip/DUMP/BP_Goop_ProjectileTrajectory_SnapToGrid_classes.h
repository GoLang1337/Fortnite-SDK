// BlueprintGeneratedClass BP_Goop_ProjectileTrajectory_SnapToGrid.BP_Goop_ProjectileTrajectory_SnapToGrid_C
// Size: 0x548 (Inherited: 0x360)
struct ABP_Goop_ProjectileTrajectory_SnapToGrid_C : ABP_ProjectileTrajectory_Athena_SnapToGridArrow_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x360(0x08)
	float PreviewScale_Scalar_6287EBF9467FA31F97650A806BE1C480; // 0x368(0x04)
	enum class ETimelineDirection PreviewScale__Direction_6287EBF9467FA31F97650A806BE1C480; // 0x36c(0x01)
	char pad_36D[0x3]; // 0x36d(0x03)
	struct UTimelineComponent* PreviewScale; // 0x370(0x08)
	struct FScalableFloat Row_Preview_SpawnOffset_Z; // 0x378(0x28)
	struct FScalableFloat Row_Preview_Size_X; // 0x3a0(0x28)
	struct FScalableFloat Row_Preview_Size_Y; // 0x3c8(0x28)
	struct FScalableFloat Row_Preview_Size_Z; // 0x3f0(0x28)
	char pad_418[0x8]; // 0x418(0x08)
	struct FTransform Transform_Preview; // 0x420(0x30)
	struct FTransform Transform_Spawn; // 0x450(0x30)
	struct FScalableFloat Row_Spawn_SpawnOffset_Z; // 0x480(0x28)
	struct FScalableFloat Row_Spawn_Size_X; // 0x4a8(0x28)
	struct FScalableFloat Row_Spawn_Size_Y; // 0x4d0(0x28)
	struct FScalableFloat Row_Spawn_Size_Z; // 0x4f8(0x28)
	struct FScalableFloat Row_bUseScalingPreview; // 0x520(0x28)

	void PreviewScale__FinishedFunc(); // Function BP_Goop_ProjectileTrajectory_SnapToGrid.BP_Goop_ProjectileTrajectory_SnapToGrid_C.PreviewScale__FinishedFunc // (BlueprintEvent) // @ game+0xcda090
	void PreviewScale__UpdateFunc(); // Function BP_Goop_ProjectileTrajectory_SnapToGrid.BP_Goop_ProjectileTrajectory_SnapToGrid_C.PreviewScale__UpdateFunc // (BlueprintEvent) // @ game+0xcda090
	void ScalePreview(); // Function BP_Goop_ProjectileTrajectory_SnapToGrid.BP_Goop_ProjectileTrajectory_SnapToGrid_C.ScalePreview // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveBeginPlay(); // Function BP_Goop_ProjectileTrajectory_SnapToGrid.BP_Goop_ProjectileTrajectory_SnapToGrid_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BP_Goop_ProjectileTrajectory_SnapToGrid(int32_t EntryPoint); // Function BP_Goop_ProjectileTrajectory_SnapToGrid.BP_Goop_ProjectileTrajectory_SnapToGrid_C.ExecuteUbergraph_BP_Goop_ProjectileTrajectory_SnapToGrid // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

