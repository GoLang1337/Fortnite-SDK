// BlueprintGeneratedClass Athena_Prop_Toilet_Factory_Toilet_Future.Athena_Prop_Toilet_Factory_Toilet_Future_C
// Size: 0xcb8 (Inherited: 0xcb8)
struct AAthena_Prop_Toilet_Factory_Toilet_Future_C : ABuildingProp {
};

