// BlueprintGeneratedClass BP_Frontend_EventLevel_NavObject_MapTable.BP_Frontend_EventLevel_NavObject_MapTable_C
// Size: 0x568 (Inherited: 0x508)
struct ABP_Frontend_EventLevel_NavObject_MapTable_C : AFortNavigationActor_MapTable {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x508(0x08)
	struct UStaticMeshComponent* sm_spybase_table_holo_ring_fx; // 0x510(0x08)
	struct UStaticMeshComponent* sm_spybase_table_holo_ring_lights_meshsprites_fx; // 0x518(0x08)
	struct UNiagaraComponent* Niagara; // 0x520(0x08)
	struct UStaticMeshComponent* SM_Cylinder_Floor_Pad_Glow; // 0x528(0x08)
	struct UFortBangCheckComponent_Map* FortBangCheckComponent_Map; // 0x530(0x08)
	struct UMaterialInstanceDynamic* MiniMapMID; // 0x538(0x08)
	struct UMaterial* MinimapMaterial; // 0x540(0x08)
	struct TArray<struct TSoftObjectPtr<UTexture2D>> MinimapTextures; // 0x548(0x10)
	struct TArray<struct TSoftObjectPtr<UTexture2D>> MinimapDiscoveryMasks; // 0x558(0x10)

	void HasDynamicMinimapTextures(bool& bResult); // Function BP_Frontend_EventLevel_NavObject_MapTable.BP_Frontend_EventLevel_NavObject_MapTable_C.HasDynamicMinimapTextures // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xccddc0
	void GetMinimapIndex(int32_t& Index); // Function BP_Frontend_EventLevel_NavObject_MapTable.BP_Frontend_EventLevel_NavObject_MapTable_C.GetMinimapIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xccddc0
	void GetMinimapTextures(struct TSoftObjectPtr<UTexture2D>& MinimapTexture, struct TSoftObjectPtr<UTexture2D>& MinimapDiscoveryMask, int32_t& MinimapIndex); // Function BP_Frontend_EventLevel_NavObject_MapTable.BP_Frontend_EventLevel_NavObject_MapTable_C.GetMinimapTextures // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnLoaded_F6AE426C44DA5A3F148FEB87D7046DD0(struct UObject* Loaded); // Function BP_Frontend_EventLevel_NavObject_MapTable.BP_Frontend_EventLevel_NavObject_MapTable_C.OnLoaded_F6AE426C44DA5A3F148FEB87D7046DD0 // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnLoaded_A68B6D734D1ACDA59664A699214A131F(struct UObject* Loaded); // Function BP_Frontend_EventLevel_NavObject_MapTable.BP_Frontend_EventLevel_NavObject_MapTable_C.OnLoaded_A68B6D734D1ACDA59664A699214A131F // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ReceiveBeginPlay(); // Function BP_Frontend_EventLevel_NavObject_MapTable.BP_Frontend_EventLevel_NavObject_MapTable_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ApplyMinimapTextures(); // Function BP_Frontend_EventLevel_NavObject_MapTable.BP_Frontend_EventLevel_NavObject_MapTable_C.ApplyMinimapTextures // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnActiveEventsChanged(); // Function BP_Frontend_EventLevel_NavObject_MapTable.BP_Frontend_EventLevel_NavObject_MapTable_C.OnActiveEventsChanged // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP_Frontend_EventLevel_NavObject_MapTable(int32_t EntryPoint); // Function BP_Frontend_EventLevel_NavObject_MapTable.BP_Frontend_EventLevel_NavObject_MapTable_C.ExecuteUbergraph_BP_Frontend_EventLevel_NavObject_MapTable // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

