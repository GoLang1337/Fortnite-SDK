// BlueprintGeneratedClass AnimNotifyState_HolsterWeaponIfNotConsumable.AnimNotifyState_HolsterWeaponIfNotConsumable_C
// Size: 0x31 (Inherited: 0x30)
struct UAnimNotifyState_HolsterWeaponIfNotConsumable_C : UAnimNotifyState {
	bool PlayEquipAnim; // 0x30(0x01)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_HolsterWeaponIfNotConsumable.AnimNotifyState_HolsterWeaponIfNotConsumable_C.Received_NotifyEnd // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0xcda090
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_HolsterWeaponIfNotConsumable.AnimNotifyState_HolsterWeaponIfNotConsumable_C.Received_NotifyBegin // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xcda090
};

