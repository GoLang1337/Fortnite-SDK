// WidgetBlueprintGeneratedClass BPS18_BattlePassRewardGrid.BPS18_BattlePassRewardGrid_C
// Size: 0x418 (Inherited: 0x410)
struct UBPS18_BattlePassRewardGrid_C : UFortBattlePassRewardGrid {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x410(0x08)

	void OnPageUnselected(); // Function BPS18_BattlePassRewardGrid.BPS18_BattlePassRewardGrid_C.OnPageUnselected // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void OnPageSelected(); // Function BPS18_BattlePassRewardGrid.BPS18_BattlePassRewardGrid_C.OnPageSelected // (Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_BattlePassRewardGrid(int32_t EntryPoint); // Function BPS18_BattlePassRewardGrid.BPS18_BattlePassRewardGrid_C.ExecuteUbergraph_BPS18_BattlePassRewardGrid // (Final|UbergraphFunction) // @ game+0xccddc0
};

