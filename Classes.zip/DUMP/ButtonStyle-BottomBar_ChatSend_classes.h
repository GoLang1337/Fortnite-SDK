// BlueprintGeneratedClass ButtonStyle-BottomBar_ChatSend.ButtonStyle-BottomBar_ChatSend_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-BottomBar_ChatSend_C : UCommonButtonStyle {
};

