// BlueprintGeneratedClass BP_AISpawnerComp_Behavior_Phoebe.BP_AISpawnerComp_Behavior_Phoebe_C
// Size: 0x158 (Inherited: 0x158)
struct UBP_AISpawnerComp_Behavior_Phoebe_C : UFortAthenaAISpawnerDataComponent_AIBotBehavior {
};

