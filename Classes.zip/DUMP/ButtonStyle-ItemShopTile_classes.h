// BlueprintGeneratedClass ButtonStyle-ItemShopTile.ButtonStyle-ItemShopTile_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-ItemShopTile_C : UButtonStyle-Base_C {
};

