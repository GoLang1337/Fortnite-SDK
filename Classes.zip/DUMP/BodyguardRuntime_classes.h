// Class BodyguardRuntime.BodyguardPlayerComponent
// Size: 0x140 (Inherited: 0xb0)
struct UBodyguardPlayerComponent : UFortControllerComponent {
	char pad_B0[0x70]; // 0xb0(0x70)
	bool bIsReviving; // 0x120(0x01)
	enum class EBodyguardPlayerRole BodyguardRole; // 0x121(0x01)
	char pad_122[0xe]; // 0x122(0x0e)
	struct AFortAthenaMutator_Bodyguard* ManagingMutator; // 0x130(0x08)
	bool bEnableSkinSwapping; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)

	void SetIsBodyguardTooFarFromVIP(bool bValue); // Function BodyguardRuntime.BodyguardPlayerComponent.SetIsBodyguardTooFarFromVIP // (Final|Native|Public|BlueprintCallable) // @ game+0x3f0c27c
	void OnRep_BodyguardRole(); // Function BodyguardRuntime.BodyguardPlayerComponent.OnRep_BodyguardRole // (Final|Native|Private) // @ game+0x3f0c1f0
	void OnPlayerRevived(struct AController* EventInstigator); // Function BodyguardRuntime.BodyguardPlayerComponent.OnPlayerRevived // (Final|Native|Public) // @ game+0x3dfdeb8
	void OnPlacementSet(struct AFortPlayerStateAthena* Sender, int32_t NewPlace); // Function BodyguardRuntime.BodyguardPlayerComponent.OnPlacementSet // (Final|Native|Public) // @ game+0x3f0c11c
	void OnPawnStartedEmote(struct UFortItemDefinition* MontageItemDef, struct AFortPawn* PawnEmoting); // Function BodyguardRuntime.BodyguardPlayerComponent.OnPawnStartedEmote // (Final|Native|Private) // @ game+0x3be7aac
	void OnFortPCPawnChangedEvent(struct AFortPawn* NewPawn); // Function BodyguardRuntime.BodyguardPlayerComponent.OnFortPCPawnChangedEvent // (Native|Protected) // @ game+0x3f0c07c
	void OnEmoteMontageEnded(struct UAnimMontage* Montage, bool bInterrupted); // Function BodyguardRuntime.BodyguardPlayerComponent.OnEmoteMontageEnded // (Native|Protected) // @ game+0x3f0bf8c
	bool IsSkinSwappingEnabled(); // Function BodyguardRuntime.BodyguardPlayerComponent.IsSkinSwappingEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f0bef8
	void ClientPlayerEliminatedVIP(); // Function BodyguardRuntime.BodyguardPlayerComponent.ClientPlayerEliminatedVIP // (Net|Native|Event|Public|NetClient) // @ game+0x3f0bcec
	void ClientOnVIPHasBeenReassigned(struct AFortPlayerStateAthena* NewVIPlayerState); // Function BodyguardRuntime.BodyguardPlayerComponent.ClientOnVIPHasBeenReassigned // (Net|Native|Event|Public|NetClient) // @ game+0x3f0bc4c
	void ClientOnTeamEliminated(); // Function BodyguardRuntime.BodyguardPlayerComponent.ClientOnTeamEliminated // (Net|Native|Event|Public|NetClient) // @ game+0x3dfec84
	void ClientOnNotifyVIPTeammateIsDowned(); // Function BodyguardRuntime.BodyguardPlayerComponent.ClientOnNotifyVIPTeammateIsDowned // (Net|Native|Event|Public|NetClient) // @ game+0x3f0bc34
	void ClientOnLocalSquadVIPTookDamage(); // Function BodyguardRuntime.BodyguardPlayerComponent.ClientOnLocalSquadVIPTookDamage // (Net|Native|Event|Public|NetClient) // @ game+0x3f0bc1c
	void ClientOnBodyguardIsTooFarFromVIP(); // Function BodyguardRuntime.BodyguardPlayerComponent.ClientOnBodyguardIsTooFarFromVIP // (Net|Native|Event|Public|NetClient) // @ game+0x3dfe820
};

// Class BodyguardRuntime.BodyguardSoundActor
// Size: 0x248 (Inherited: 0x220)
struct ABodyguardSoundActor : AActor {
	char pad_220[0x8]; // 0x220(0x08)
	struct FGameplayTagContainer GameplayTags; // 0x228(0x20)

	void UpdateTeamVIPIsDBNO_BP(bool bIsTeamVIP_DBNO, bool bIsLocalPlayerTheVIP, bool bIsDead); // Function BodyguardRuntime.BodyguardSoundActor.UpdateTeamVIPIsDBNO_BP // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0xcda090
	void UpdateTeamVIPIsBeingRevived_BP(bool bIsBeingRevived, bool bIsTeamVIP_DBNO, bool bIsReviving, bool bIsLocalPlayerTheVIP); // Function BodyguardRuntime.BodyguardSoundActor.UpdateTeamVIPIsBeingRevived_BP // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0xcda090
	void UpdateTeamVIPHealth_BP(float CurrentHealth, float MaxHealth, bool bIsLocalPlayerTheVIP); // Function BodyguardRuntime.BodyguardSoundActor.UpdateTeamVIPHealth_BP // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0xcda090
	void HandleVIPNotAllowItemPickup_BP(); // Function BodyguardRuntime.BodyguardSoundActor.HandleVIPNotAllowItemPickup_BP // (RequiredAPI|Event|Public|BlueprintEvent|Const) // @ game+0xcda090
};

// Class BodyguardRuntime.FortAthenaMutator_Bodyguard
// Size: 0x8f8 (Inherited: 0x3d8)
struct AFortAthenaMutator_Bodyguard : AFortAthenaMutator_GameModeBase {
	char pad_3D8[0x20]; // 0x3d8(0x20)
	struct FGameplayTag VIPKillAccoladeTag; // 0x3f8(0x08)
	struct FGameplayTag VIPMultiKillAccoladeTag; // 0x400(0x08)
	struct FGameplayTag BodyguardReviveAccoladeTag; // 0x408(0x08)
	struct FGameplayTag VIPReviveAccoladeTag; // 0x410(0x08)
	struct FGameplayTag VIPSurviveAccoladeTag; // 0x418(0x08)
	struct FScalableFloat VIPMultikillAccoladeThreshold; // 0x420(0x28)
	struct ABodyguardSoundActor* BodyguardSoundPlayer; // 0x448(0x08)
	struct FGameplayTagContainer VIPLostDeathReasonTagContainter; // 0x450(0x20)
	struct TArray<struct FItemAndCount> VIPItemList; // 0x470(0x10)
	struct TArray<struct FItemAndCount> BodyguardItemList; // 0x480(0x10)
	struct TMap<struct UFortItemDefinition*, int32_t> ItemToDesiredQuickBarSlotMap; // 0x490(0x50)
	struct FGameplayTagContainer VIPProhibitedItemTags; // 0x4e0(0x20)
	struct FGameplayTagContainer BodyguardProhibitedItemTags; // 0x500(0x20)
	struct FScalableFloat RespawnZLocationOffset; // 0x520(0x28)
	struct FText VIPBlockedItemText; // 0x548(0x18)
	struct FSlateBrush VIPMapIconBrush; // 0x560(0x88)
	struct FVector2D MinimapPositionShiftPercent; // 0x5e8(0x08)
	struct FVector2D MiniMapIconScale; // 0x5f0(0x08)
	struct FFortAthenaCompassIcon VIPCompassIconBackDrop; // 0x5f8(0xa0)
	struct FFortAthenaCompassIcon VIPCompassIcon; // 0x698(0xa0)
	struct TArray<struct AActor*> VIPBlockInteractClasses; // 0x738(0x10)
	struct FScalableFloat VIPEliminatedEndGameScreenDelay; // 0x748(0x28)
	enum class EAthenaGamePhase StartingVIPPlayerStateChangeTrackingGamePhase; // 0x770(0x01)
	char pad_771[0xf]; // 0x771(0x0f)
	struct FScalableFloat UpdateIntervalMonitorVIPPlayerStateChanges; // 0x780(0x28)
	struct FScalableFloat HideDBNOVIPPlayerIndicators; // 0x7a8(0x28)
	struct TArray<struct FBodyGuardPartOverrideData> PartOverrideCustomizations; // 0x7d0(0x10)
	struct TArray<struct UCustomCharacterPart*> PartsToSwapInToRemoveExtras; // 0x7e0(0x10)
	struct FScalableFloat ShouldSwapSkins; // 0x7f0(0x28)
	struct FGameplayTagContainer SkinMetaTagsToSkip; // 0x818(0x20)
	struct FGameplayTagContainer SpecialTags; // 0x838(0x20)
	struct FGameplayTagContainer ExtraSpecialTags; // 0x858(0x20)
	struct FScalableFloat EnemyVIPsRemainingUIDelay; // 0x878(0x28)
	char pad_8A0[0x8]; // 0x8a0(0x08)
	struct TArray<struct FBodyguardVIPPlayerData> VIPPlayerDataList; // 0x8a8(0x10)
	struct TArray<struct FBodyguardVIPDeathState> VIPDeathStateList; // 0x8b8(0x10)
	struct FBodyguardVIPPlayerData PreviousTeamVIPPlayerData; // 0x8c8(0x18)
	struct AFortGameplayMutator* MutatorClassToWaitFor; // 0x8e0(0x08)
	struct AFortGameplayMutator* CustomCharacterPartsMutator; // 0x8e8(0x08)
	char RevealPlayerRole; // 0x8f0(0x01)
	char pad_8F1[0x7]; // 0x8f1(0x07)

	void UpdateSquadmatesIsReviving(char VIPTeam); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.UpdateSquadmatesIsReviving // (Final|Native|Public) // @ game+0x3f0bf10
	void ShutOffAnyDBNOSounds(bool bIsDead); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.ShutOffAnyDBNOSounds // (Final|Native|Protected) // @ game+0x3f0c338
	void OnRep_VIPPlayerDataList(); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.OnRep_VIPPlayerDataList // (Final|Native|Protected) // @ game+0x3f0c268
	void OnRep_VIPDeathStateList(); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.OnRep_VIPDeathStateList // (Final|Native|Protected) // @ game+0x3f0c254
	void OnRep_RevealPlayerRole(); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.OnRep_RevealPlayerRole // (Final|Native|Private) // @ game+0x3f0c224
	void NotifyVIPOnTeammateDBNO(char VIPTeam); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.NotifyVIPOnTeammateDBNO // (Final|Native|Public|BlueprintCallable) // @ game+0x3f0bf10
	void NotifySquadmatesOnVIPTookDamage(char VIPTeam); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.NotifySquadmatesOnVIPTookDamage // (Final|Native|Public|BlueprintCallable) // @ game+0x3f0bf10
	bool IsReviving(struct AFortPlayerStateAthena* PlayerState); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.IsReviving // (Final|RequiredAPI|Native|Public|Const) // @ game+0x3f0be60
	bool GetTeamVIPPlayerData(char TeamNum, struct FBodyguardVIPPlayerData OutVIPPlayerData); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.GetTeamVIPPlayerData // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f0bd4c
	float GetEnemyVIPsRemainingUIDelay(); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.GetEnemyVIPsRemainingUIDelay // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f0bd18
	void EndGameShutOffAnyDBNOSounds(); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.EndGameShutOffAnyDBNOSounds // (Final|Native|Protected) // @ game+0x3f0bd04
	void AssignPlayerRolesForSquads(); // Function BodyguardRuntime.FortAthenaMutator_Bodyguard.AssignPlayerRolesForSquads // (Native|Protected) // @ game+0x3f0bc04
};

// Class BodyguardRuntime.FortAthenaMutator_BodyguardRumble
// Size: 0x8f8 (Inherited: 0x8f8)
struct AFortAthenaMutator_BodyguardRumble : AFortAthenaMutator_Bodyguard {
};

