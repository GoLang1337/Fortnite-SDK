// BlueprintGeneratedClass BB_Focus.BB_Focus_C
// Size: 0x100 (Inherited: 0x100)
struct UBB_Focus_C : UFortMobileActionButtonBehavior_Focus {
};

