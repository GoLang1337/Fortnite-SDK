// BlueprintGeneratedClass BP_PlayerPawn_Athena_Phoebe.BP_PlayerPawn_Athena_Phoebe_C
// Size: 0x4978 (Inherited: 0x4968)
struct ABP_PlayerPawn_Athena_Phoebe_C : APlayerPawn_Athena_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4968(0x08)
	struct FName AIEvaluator_CharacterLaunchedKeyName; // 0x4970(0x08)

	void OnLaunched(struct FVector LaunchVelocity, bool bXYOverride, bool bZOverride); // Function BP_PlayerPawn_Athena_Phoebe.BP_PlayerPawn_Athena_Phoebe_C.OnLaunched // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BP_PlayerPawn_Athena_Phoebe(int32_t EntryPoint); // Function BP_PlayerPawn_Athena_Phoebe.BP_PlayerPawn_Athena_Phoebe_C.ExecuteUbergraph_BP_PlayerPawn_Athena_Phoebe // (Final|UbergraphFunction) // @ game+0xcda090
};

