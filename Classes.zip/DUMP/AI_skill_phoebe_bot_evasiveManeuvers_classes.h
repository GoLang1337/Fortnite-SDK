// BlueprintGeneratedClass AI_skill_phoebe_bot_evasiveManeuvers.AI_skill_phoebe_bot_evasiveManeuvers_C
// Size: 0x5d0 (Inherited: 0x5d0)
struct UAI_skill_phoebe_bot_evasiveManeuvers_C : UFortAthenaAIBotEvasiveManeuversSkillSet {
};

