// BlueprintGeneratedClass BP_BroadcastPost.BP_BroadcastPost_C
// Size: 0x239 (Inherited: 0x220)
struct ABP_BroadcastPost_C : AActor {
	struct UPostProcessComponent* Extreme; // 0x220(0x08)
	struct UPostProcessComponent* PostProcess; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	bool ExtremePostEnabled; // 0x238(0x01)

	void UserConstructionScript(); // Function BP_BroadcastPost.BP_BroadcastPost_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
};

