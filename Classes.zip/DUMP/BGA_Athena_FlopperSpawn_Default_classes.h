// BlueprintGeneratedClass BGA_Athena_FlopperSpawn_Default.BGA_Athena_FlopperSpawn_Default_C
// Size: 0xd18 (Inherited: 0xd18)
struct ABGA_Athena_FlopperSpawn_Default_C : ABGA_Athena_FlopperSpawn_Parent_C {
};

