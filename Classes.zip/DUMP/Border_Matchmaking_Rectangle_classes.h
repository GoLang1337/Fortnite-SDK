// BlueprintGeneratedClass Border_Matchmaking_Rectangle.Border_Matchmaking_Rectangle_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_Matchmaking_Rectangle_C : UCommonBorderStyle {
};

