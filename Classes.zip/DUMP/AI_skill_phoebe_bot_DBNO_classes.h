// BlueprintGeneratedClass AI_skill_phoebe_bot_DBNO.AI_skill_phoebe_bot_DBNO_C
// Size: 0xf8 (Inherited: 0xf8)
struct UAI_skill_phoebe_bot_DBNO_C : UFortAthenaAIBotDBNOSkillSet {
};

