// BlueprintGeneratedClass BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C
// Size: 0xbd0 (Inherited: 0xba0)
struct ABP_DamageBalloon_Athena_C : ABuildingSMActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xba0(0x08)
	struct UParticleSystemComponent* ExplosionParticle; // 0xba8(0x08)
	struct UFortHealthBarComponent* FortHealthBar; // 0xbb0(0x08)
	bool DestroyBalloon; // 0xbb8(0x01)
	bool DontPlayDestroyAudio; // 0xbb9(0x01)
	char pad_BBA[0x6]; // 0xbba(0x06)
	struct FMulticastInlineDelegate OnBalloonDestroyed; // 0xbc0(0x10)

	void OnRep_DestroyBalloon(); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.OnRep_DestroyBalloon // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnDamageServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void CrateIsGone(); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.CrateIsGone // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveBeginPlay(); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BP_DamageBalloon_Athena(int32_t EntryPoint); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.ExecuteUbergraph_BP_DamageBalloon_Athena // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
	void OnBalloonDestroyed__DelegateSignature(); // Function BP_DamageBalloon_Athena.BP_DamageBalloon_Athena_C.OnBalloonDestroyed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
};

