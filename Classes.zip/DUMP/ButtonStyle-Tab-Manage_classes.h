// BlueprintGeneratedClass ButtonStyle-Tab-Manage.ButtonStyle-Tab-Manage_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Tab-Manage_C : UCommonButtonStyle {
};

