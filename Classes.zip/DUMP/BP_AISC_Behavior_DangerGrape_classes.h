// BlueprintGeneratedClass BP_AISC_Behavior_DangerGrape.BP_AISC_Behavior_DangerGrape_C
// Size: 0x158 (Inherited: 0x158)
struct UBP_AISC_Behavior_DangerGrape_C : UFortAthenaAISpawnerDataComponent_AIBotBehavior {
};

