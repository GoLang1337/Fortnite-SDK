// BlueprintGeneratedClass BP_AISC_Gameplay_DangerGrape.BP_AISC_Gameplay_DangerGrape_C
// Size: 0x448 (Inherited: 0x448)
struct UBP_AISC_Gameplay_DangerGrape_C : UBP_AISpawnerComp_Gameplay_Phoebe_C {
};

