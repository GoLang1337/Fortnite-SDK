// BlueprintGeneratedClass BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C
// Size: 0xf11 (Inherited: 0xef0)
struct ABuildingContainer_Physics_Parent_C : ABuildingContainer {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xef0(0x08)
	struct UFortLinkToActorComponent* FortLinkToActor; // 0xef8(0x08)
	struct UFortPhysicsObjectComponent* FortPhysicsObject; // 0xf00(0x08)
	struct AActor* LinkedActor; // 0xf08(0x08)
	bool Rep_WakeUp; // 0xf10(0x01)

	void OnRep_Rep_WakeUp(); // Function BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C.OnRep_Rep_WakeUp // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_1_OnLinkedActorDestroyed__DelegateSignature(); // Function BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C.BndEvt__FortLinkToActor_K2Node_ComponentBoundEvent_1_OnLinkedActorDestroyed__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__FortPhysicsObject_K2Node_ComponentBoundEvent_0_OnPhysicsObjectAwakeChanged__DelegateSignature(struct UPrimitiveComponent* SimulatingComponent, bool bIsAwake); // Function BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C.BndEvt__FortPhysicsObject_K2Node_ComponentBoundEvent_0_OnPhysicsObjectAwakeChanged__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void ReceiveBeginPlay(); // Function BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BuildingContainer_Physics_Parent(int32_t EntryPoint); // Function BuildingContainer_Physics_Parent.BuildingContainer_Physics_Parent_C.ExecuteUbergraph_BuildingContainer_Physics_Parent // (Final|UbergraphFunction) // @ game+0xccddc0
};

