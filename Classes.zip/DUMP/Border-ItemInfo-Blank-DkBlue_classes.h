// BlueprintGeneratedClass Border-ItemInfo-Blank-DkBlue.Border-ItemInfo-Blank-DkBlue_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-ItemInfo-Blank-DkBlue_C : UBorder-ItemInfo-Unlocked_C {
};

