// BlueprintGeneratedClass Apollo_Suburban_Toilet_04.Apollo_Suburban_Toilet_04_C
// Size: 0xcb8 (Inherited: 0xcb8)
struct AApollo_Suburban_Toilet_04_C : ABuildingProp {
};

