// BlueprintGeneratedClass Border_AthenaStore_OfferHeaderBacking.Border_AthenaStore_OfferHeaderBacking_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_AthenaStore_OfferHeaderBacking_C : UBorder-TabM_C {
};

