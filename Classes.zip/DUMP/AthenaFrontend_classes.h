// WidgetBlueprintGeneratedClass AthenaFrontend.AthenaFrontend_C
// Size: 0x818 (Inherited: 0x778)
struct UAthenaFrontend_C : UAthenaUIStateWidget_Frontend {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x778(0x08)
	struct UAthenaFPS_C* AthenaFPS; // 0x780(0x08)
	struct UAthenaTemperature_C* AthenaTemperature; // 0x788(0x08)
	struct UBuildWatermark_C* BuildWatermark; // 0x790(0x08)
	struct UButton* Button_PTT; // 0x798(0x08)
	struct UCommonTextBlock* CommonTextBlock_FrontendFlowDebug; // 0x7a0(0x08)
	struct UContentOnDemand_C* ContentOnDemand; // 0x7a8(0x08)
	struct UFortVoiceChannelSpeakerContainer_C* FortVoiceChannelSpeakerContainer; // 0x7b0(0x08)
	struct UImage* PTT_Image; // 0x7b8(0x08)
	struct USafeZone* SafeZone_2; // 0x7c0(0x08)
	struct USafeZone* SafeZone_Bottom; // 0x7c8(0x08)
	struct USizeBox* SizeBoxPTT; // 0x7d0(0x08)
	bool StartedPlayingVideo; // 0x7d8(0x01)
	char pad_7D9[0x3]; // 0x7d9(0x03)
	int32_t TransitionIndex; // 0x7dc(0x04)
	struct TArray<struct FS12_CineTransitionData> TransitionAudioData; // 0x7e0(0x10)
	struct UMediaPlayer* MovieMediaPlayer; // 0x7f0(0x08)
	struct USoundBase* TransitionSound01; // 0x7f8(0x08)
	struct USoundBase* TransitionSound02; // 0x800(0x08)
	struct TArray<struct FTimerHandle> AudioTimerHandles; // 0x808(0x10)

	void OnTrailerMediaEnded(); // Function AthenaFrontend.AthenaFrontend_C.OnTrailerMediaEnded // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnTrailerMediaOpened(struct FString OpenedUrl); // Function AthenaFrontend.AthenaFrontend_C.OnTrailerMediaOpened // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnTrailerTransitionAudioCheck(); // Function AthenaFrontend.AthenaFrontend_C.OnTrailerTransitionAudioCheck // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void PlayTrailer(); // Function AthenaFrontend.AthenaFrontend_C.PlayTrailer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void InitChatVisibilityButton(); // Function AthenaFrontend.AthenaFrontend_C.InitChatVisibilityButton // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void UpdatePttVisibility(enum class EPTTState PTTState); // Function AthenaFrontend.AthenaFrontend_C.UpdatePttVisibility // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SetOverlayTitleBarVisibility(bool Visible); // Function AthenaFrontend.AthenaFrontend_C.SetOverlayTitleBarVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SetChatWidgetVisibility(bool Visible); // Function AthenaFrontend.AthenaFrontend_C.SetChatWidgetVisibility // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BndEvt__ButtonToggleChat_K2Node_ComponentBoundEvent_39_CommonSelectedStateChanged__DelegateSignature(struct UCommonButtonLegacy* Button, bool Selected); // Function AthenaFrontend.AthenaFrontend_C.BndEvt__ButtonToggleChat_K2Node_ComponentBoundEvent_39_CommonSelectedStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void On Can PTT(); // Function AthenaFrontend.AthenaFrontend_C.On Can PTT // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Construct(); // Function AthenaFrontend.AthenaFrontend_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void BndEvt__Button_PTT_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function AthenaFrontend.AthenaFrontend_C.BndEvt__Button_PTT_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void OnSetFrontendVisibilityMode(enum class EFrontendVisibilityMode InFrontendVisibilityMode); // Function AthenaFrontend.AthenaFrontend_C.OnSetFrontendVisibilityMode // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void StartTrailerTransitionAudioCheck(struct UMediaPlayer* MediaPlayer); // Function AthenaFrontend.AthenaFrontend_C.StartTrailerTransitionAudioCheck // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void StopTrailerTransitionAudioCheck(); // Function AthenaFrontend.AthenaFrontend_C.StopTrailerTransitionAudioCheck // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void DisplayDebugFlowText(struct FText DebugFlowText); // Function AthenaFrontend.AthenaFrontend_C.DisplayDebugFlowText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void HideDebugFlowText(); // Function AthenaFrontend.AthenaFrontend_C.HideDebugFlowText // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_AthenaFrontend(int32_t EntryPoint); // Function AthenaFrontend.AthenaFrontend_C.ExecuteUbergraph_AthenaFrontend // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

