// BlueprintGeneratedClass BP_PhoebeController_NonParticipant.BP_PhoebeController_NonParticipant_C
// Size: 0xf18 (Inherited: 0xf18)
struct ABP_PhoebeController_NonParticipant_C : ABP_PhoebePlayerController_C {
};

