// BlueprintGeneratedClass ButtonStyle_CycleArrow_Left_Double.ButtonStyle_CycleArrow_Left_Double_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_CycleArrow_Left_Double_C : UButtonStyle-MediumTransparentNoCues_C {
};

