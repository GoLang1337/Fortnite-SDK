// BlueprintGeneratedClass Athena_PlayerCameraModeRangedTargeting.Athena_PlayerCameraModeRangedTargeting_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCameraModeRangedTargeting_C : UAthena_PlayerCameraModeBase_C {
};

