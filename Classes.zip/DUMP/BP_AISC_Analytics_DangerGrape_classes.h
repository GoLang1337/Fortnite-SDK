// BlueprintGeneratedClass BP_AISC_Analytics_DangerGrape.BP_AISC_Analytics_DangerGrape_C
// Size: 0x78 (Inherited: 0x78)
struct UBP_AISC_Analytics_DangerGrape_C : UBP_AISpawnerComp_Analytic_Phoebe_C {
};

