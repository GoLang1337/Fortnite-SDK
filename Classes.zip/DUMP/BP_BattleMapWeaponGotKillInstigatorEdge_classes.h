// BlueprintGeneratedClass BP_BattleMapWeaponGotKillInstigatorEdge.BP_BattleMapWeaponGotKillInstigatorEdge_C
// Size: 0x288 (Inherited: 0x288)
struct ABP_BattleMapWeaponGotKillInstigatorEdge_C : ABP_BattleMapBaseEdge_C {
};

