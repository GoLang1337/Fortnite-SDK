// BlueprintGeneratedClass Border-SolidBG_White.Border-SolidBG_White_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-SolidBG_White_C : UBorder-ShellTopBar_C {
};

