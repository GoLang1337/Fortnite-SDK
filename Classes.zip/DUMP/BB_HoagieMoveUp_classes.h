// BlueprintGeneratedClass BB_HoagieMoveUp.BB_HoagieMoveUp_C
// Size: 0xf8 (Inherited: 0xf8)
struct UBB_HoagieMoveUp_C : UFortMobileActionButtonBehavior {
};

