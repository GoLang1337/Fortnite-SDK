// BlueprintGeneratedClass ButtonStyle-BacchusBottomBar.ButtonStyle-BacchusBottomBar_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-BacchusBottomBar_C : UCommonButtonStyle {
};

