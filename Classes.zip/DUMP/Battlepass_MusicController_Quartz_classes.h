// BlueprintGeneratedClass Battlepass_MusicController_Quartz.Battlepass_MusicController_Quartz_C
// Size: 0x250 (Inherited: 0x240)
struct ABattlepass_MusicController_Quartz_C : ABP_QuartzMusicController_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)
	struct UQuartzMusicTrackComponent_C* QuartzMusicTrackComponent; // 0x248(0x08)

	void ReceiveBeginPlay(); // Function Battlepass_MusicController_Quartz.Battlepass_MusicController_Quartz_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ReceiveDestroyed(); // Function Battlepass_MusicController_Quartz.Battlepass_MusicController_Quartz_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_Battlepass_MusicController_Quartz(int32_t EntryPoint); // Function Battlepass_MusicController_Quartz.Battlepass_MusicController_Quartz_C.ExecuteUbergraph_Battlepass_MusicController_Quartz // (Final|UbergraphFunction) // @ game+0xcda090
};

