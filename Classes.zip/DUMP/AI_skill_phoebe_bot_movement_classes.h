// BlueprintGeneratedClass AI_skill_phoebe_bot_movement.AI_skill_phoebe_bot_movement_C
// Size: 0x798 (Inherited: 0x798)
struct UAI_skill_phoebe_bot_movement_C : UFortAthenaAIBotMovementSkillSet {
};

