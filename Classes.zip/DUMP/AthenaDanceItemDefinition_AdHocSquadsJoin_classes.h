// BlueprintGeneratedClass AthenaDanceItemDefinition_AdHocSquadsJoin.AthenaDanceItemDefinition_AdHocSquadsJoin_C
// Size: 0x900 (Inherited: 0x8e0)
struct UAthenaDanceItemDefinition_AdHocSquadsJoin_C : UAthenaDanceItemDefinition {
	struct UAthenaDanceItemDefinition* GroupEmoteToStartLeader_AutoSquadUp; // 0x8e0(0x08)
	struct UAthenaDanceItemDefinition* GroupEmoteToStartFollower_AdHocSquadUp; // 0x8e8(0x08)
	struct UAthenaDanceItemDefinition* GroupEmoteToStartLeaderIfBothOwn_AdHocSquadUp; // 0x8f0(0x08)
	struct UAthenaDanceItemDefinition* GroupEmoteToStartFollowerIfBothOwn_AdHocSquadUp; // 0x8f8(0x08)
};

