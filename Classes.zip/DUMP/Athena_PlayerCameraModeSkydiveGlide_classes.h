// BlueprintGeneratedClass Athena_PlayerCameraModeSkydiveGlide.Athena_PlayerCameraModeSkydiveGlide_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeSkydiveGlide_C : UAthena_PlayerCameraModeBase_C {
};

