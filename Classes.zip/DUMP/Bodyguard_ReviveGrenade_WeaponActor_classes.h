// BlueprintGeneratedClass Bodyguard_ReviveGrenade_WeaponActor.Bodyguard_ReviveGrenade_WeaponActor_C
// Size: 0xe09 (Inherited: 0xe09)
struct ABodyguard_ReviveGrenade_WeaponActor_C : AB_ConsumableSmall_Athena_C {
};

