// BlueprintGeneratedClass ButtonStyle-Skew_LessTransparent.ButtonStyle-Skew_LessTransparent_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Skew_LessTransparent_C : UCommonButtonStyle {
};

