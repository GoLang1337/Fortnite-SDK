// WidgetBlueprintGeneratedClass BPS18_GetAllButton.BPS18_GetAllButton_C
// Size: 0xc21 (Inherited: 0xbd0)
struct UBPS18_GetAllButton_C : UCommonButtonBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd0(0x08)
	struct UWidgetAnimation* Hover; // 0xbd8(0x08)
	struct UImage* Image; // 0xbe0(0x08)
	struct UImage* Image_35; // 0xbe8(0x08)
	struct UImage* Image_Hover; // 0xbf0(0x08)
	struct UCommonRichTextBlock* MainText; // 0xbf8(0x08)
	struct UCommonRichTextBlock* MainText_hover; // 0xc00(0x08)
	struct UOverlay* Overlay_24; // 0xc08(0x08)
	struct UOverlay* Overlay_input; // 0xc10(0x08)
	struct USizeBox* SizeBox_1; // 0xc18(0x08)
	bool Page Complete; // 0xc20(0x01)

	void UpdateTextAndStyle(enum class ECommonInputType Input Type); // Function BPS18_GetAllButton.BPS18_GetAllButton_C.UpdateTextAndStyle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void Set Text Data(bool Page Complete, int32_t Starting Page, int32_t Ending Page, int32_t Cost); // Function BPS18_GetAllButton.BPS18_GetAllButton_C.Set Text Data // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHovered(); // Function BPS18_GetAllButton.BPS18_GetAllButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function BPS18_GetAllButton.BPS18_GetAllButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void Construct(); // Function BPS18_GetAllButton.BPS18_GetAllButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void Destruct(); // Function BPS18_GetAllButton.BPS18_GetAllButton_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_GetAllButton(int32_t EntryPoint); // Function BPS18_GetAllButton.BPS18_GetAllButton_C.ExecuteUbergraph_BPS18_GetAllButton // (Final|UbergraphFunction) // @ game+0xccddc0
};

