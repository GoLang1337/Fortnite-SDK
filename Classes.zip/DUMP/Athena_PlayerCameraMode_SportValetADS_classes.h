// BlueprintGeneratedClass Athena_PlayerCameraMode_SportValetADS.Athena_PlayerCameraMode_SportValetADS_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraMode_SportValetADS_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

