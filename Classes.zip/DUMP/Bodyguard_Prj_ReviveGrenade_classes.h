// BlueprintGeneratedClass Bodyguard_Prj_ReviveGrenade.Bodyguard_Prj_ReviveGrenade_C
// Size: 0xa10 (Inherited: 0x9f8)
struct ABodyguard_Prj_ReviveGrenade_C : AB_Prj_Athena_Grenade_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x9f8(0x08)
	struct UNiagaraComponent* Fuse; // 0xa00(0x08)
	struct UGameplayEffect* GE_Heal; // 0xa08(0x08)

	void OnExploded(struct TArray<struct AActor*> HitActors, struct TArray<struct FHitResult> HitResults); // Function Bodyguard_Prj_ReviveGrenade.Bodyguard_Prj_ReviveGrenade_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void FuseEnded(); // Function Bodyguard_Prj_ReviveGrenade.Bodyguard_Prj_ReviveGrenade_C.FuseEnded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult SweepResult); // Function Bodyguard_Prj_ReviveGrenade.Bodyguard_Prj_ReviveGrenade_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0xcda090
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function Bodyguard_Prj_ReviveGrenade.Bodyguard_Prj_ReviveGrenade_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_0_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void OnStop(struct FHitResult Hit); // Function Bodyguard_Prj_ReviveGrenade.Bodyguard_Prj_ReviveGrenade_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_Bodyguard_Prj_ReviveGrenade(int32_t EntryPoint); // Function Bodyguard_Prj_ReviveGrenade.Bodyguard_Prj_ReviveGrenade_C.ExecuteUbergraph_Bodyguard_Prj_ReviveGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

