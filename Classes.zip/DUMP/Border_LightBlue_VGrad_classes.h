// BlueprintGeneratedClass Border_LightBlue_VGrad.Border_LightBlue_VGrad_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_LightBlue_VGrad_C : UCommonBorderStyle {
};

