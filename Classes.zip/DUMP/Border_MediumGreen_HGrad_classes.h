// BlueprintGeneratedClass Border_MediumGreen_HGrad.Border_MediumGreen_HGrad_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_MediumGreen_HGrad_C : UCommonBorderStyle {
};

