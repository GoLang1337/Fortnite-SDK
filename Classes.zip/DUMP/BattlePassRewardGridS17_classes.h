// WidgetBlueprintGeneratedClass BattlePassRewardGridS17.BattlePassRewardGridS17_C
// Size: 0x408 (Inherited: 0x400)
struct UBattlePassRewardGridS17_C : UFortBattlePassRewardGrid {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)

	void OnPageUnselected(); // Function BattlePassRewardGridS17.BattlePassRewardGridS17_C.OnPageUnselected // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnPageSelected(); // Function BattlePassRewardGridS17.BattlePassRewardGridS17_C.OnPageSelected // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BattlePassRewardGridS17(int32_t EntryPoint); // Function BattlePassRewardGridS17.BattlePassRewardGridS17_C.ExecuteUbergraph_BattlePassRewardGridS17 // (Final|UbergraphFunction) // @ game+0xcda090
};

