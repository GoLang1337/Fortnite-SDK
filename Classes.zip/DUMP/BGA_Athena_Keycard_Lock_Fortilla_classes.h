// BlueprintGeneratedClass BGA_Athena_Keycard_Lock_Fortilla.BGA_Athena_Keycard_Lock_Fortilla_C
// Size: 0xae9 (Inherited: 0xae9)
struct ABGA_Athena_Keycard_Lock_Fortilla_C : ABGA_Athena_Keycard_Lock_Parent_C {
};

