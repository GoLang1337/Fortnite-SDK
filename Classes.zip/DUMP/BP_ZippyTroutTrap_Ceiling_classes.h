// BlueprintGeneratedClass BP_ZippyTroutTrap_Ceiling.BP_ZippyTroutTrap_Ceiling_C
// Size: 0xf01 (Inherited: 0xf01)
struct ABP_ZippyTroutTrap_Ceiling_C : ABP_ZippyTroutTrap_Floor_C {
};

