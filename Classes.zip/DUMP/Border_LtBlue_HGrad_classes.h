// BlueprintGeneratedClass Border_LtBlue_HGrad.Border_LtBlue_HGrad_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_LtBlue_HGrad_C : UBorder-TabM_C {
};

