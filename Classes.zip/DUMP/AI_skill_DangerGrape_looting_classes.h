// BlueprintGeneratedClass AI_skill_DangerGrape_looting.AI_skill_DangerGrape_looting_C
// Size: 0x270 (Inherited: 0x270)
struct UAI_skill_DangerGrape_looting_C : UFortAthenaAIBotLootingSkillSet {
};

