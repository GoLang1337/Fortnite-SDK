// BlueprintGeneratedClass BB_ValetHandbrake.BB_ValetHandbrake_C
// Size: 0xf8 (Inherited: 0xf8)
struct UBB_ValetHandbrake_C : UFortMobileActionButtonBehavior {
};

