// WidgetBlueprintGeneratedClass Athena_ProgressModal.Athena_ProgressModal_C
// Size: 0x390 (Inherited: 0x358)
struct UAthena_ProgressModal_C : UAthenaProgressModal {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x358(0x08)
	struct UWidgetAnimation* Intro; // 0x360(0x08)
	struct UImage* Image_67; // 0x368(0x08)
	struct UImage* Image_Separator_Down; // 0x370(0x08)
	struct UImage* Image_Separator_Up; // 0x378(0x08)
	struct ULightbox_C* Lightbox; // 0x380(0x08)
	struct UImage* ProgressSpinner; // 0x388(0x08)

	void BP_OnActivated(); // Function Athena_ProgressModal.Athena_ProgressModal_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_Athena_ProgressModal(int32_t EntryPoint); // Function Athena_ProgressModal.Athena_ProgressModal_C.ExecuteUbergraph_Athena_ProgressModal // (Final|UbergraphFunction) // @ game+0xccddc0
};

