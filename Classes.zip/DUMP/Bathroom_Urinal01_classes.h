// BlueprintGeneratedClass Bathroom_Urinal01.Bathroom_Urinal01_C
// Size: 0xcb8 (Inherited: 0xcb8)
struct ABathroom_Urinal01_C : ABuildingProp {
};

