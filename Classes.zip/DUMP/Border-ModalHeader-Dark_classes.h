// BlueprintGeneratedClass Border-ModalHeader-Dark.Border-ModalHeader-Dark_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-ModalHeader-Dark_C : UBorder-ModalHeader_C {
};

