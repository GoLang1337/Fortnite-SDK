// BlueprintGeneratedClass ButtonStyle-Clear.ButtonStyle-Clear_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Clear_C : UCommonButtonStyle {
};

