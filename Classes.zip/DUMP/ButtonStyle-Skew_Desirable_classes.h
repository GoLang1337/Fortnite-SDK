// BlueprintGeneratedClass ButtonStyle-Skew_Desirable.ButtonStyle-Skew_Desirable_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Skew_Desirable_C : UCommonButtonStyle {
};

