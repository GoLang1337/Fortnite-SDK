// WidgetBlueprintGeneratedClass AthenaItemTextureVariantPicker.AthenaItemTextureVariantPicker_C
// Size: 0x328 (Inherited: 0x328)
struct UAthenaItemTextureVariantPicker_C : UFortVariantItemTexturePicker {
};

