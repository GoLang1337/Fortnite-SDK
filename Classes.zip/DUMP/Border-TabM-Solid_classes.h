// BlueprintGeneratedClass Border-TabM-Solid.Border-TabM-Solid_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-TabM-Solid_C : UBorder-TabM_C {
};

