// WidgetBlueprintGeneratedClass AgeGateFlow.AgeGateFlow_C
// Size: 0x560 (Inherited: 0x540)
struct UAgeGateFlow_C : UFortAgeGateFlow {
	struct UCommonActionWidget* CommonActionWidget_795; // 0x540(0x08)
	struct UImage* Image; // 0x548(0x08)
	struct UImage* Image_2; // 0x550(0x08)
	struct UImage* Image_256; // 0x558(0x08)
};

