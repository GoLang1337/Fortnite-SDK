// BlueprintGeneratedClass Border_StatRow_DeltaPositive.Border_StatRow_DeltaPositive_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_StatRow_DeltaPositive_C : UCommonBorderStyle {
};

