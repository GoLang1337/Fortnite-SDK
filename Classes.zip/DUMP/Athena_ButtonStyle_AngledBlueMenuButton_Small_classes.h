// BlueprintGeneratedClass Athena_ButtonStyle_AngledBlueMenuButton_Small.Athena_ButtonStyle_AngledBlueMenuButton_Small_C
// Size: 0x570 (Inherited: 0x570)
struct UAthena_ButtonStyle_AngledBlueMenuButton_Small_C : UCommonButtonStyle {
};

