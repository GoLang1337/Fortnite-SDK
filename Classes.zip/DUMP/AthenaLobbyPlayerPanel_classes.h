// WidgetBlueprintGeneratedClass AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C
// Size: 0x7c8 (Inherited: 0x540)
struct UAthenaLobbyPlayerPanel_C : UAthenaLobbyPlayerPanel {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x540(0x08)
	struct UHorizontalBox* BattlePassRow; // 0x548(0x08)
	struct UBorder* Border_1; // 0x550(0x08)
	struct FFortTeamMemberInfo TeamMemberInfo; // 0x558(0x200)
	struct FMulticastInlineDelegate OnGadgetsClicked; // 0x758(0x10)
	struct FText AddFriendText; // 0x768(0x18)
	struct FText AcceptInviteText; // 0x780(0x18)
	struct FText SentInviteText; // 0x798(0x18)
	struct FText AcceptedInviteText; // 0x7b0(0x18)

	struct FEventReply OnMouseButtonDown_1(struct FGeometry MyGeometry, struct FPointerEvent MouseEvent); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.OnMouseButtonDown_1 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnHasBattlePassUpdated(bool bHasBattlePass); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.OnHasBattlePassUpdated // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnFriendStatusUpdated(enum class EFortFriendRequestStatus FriendRequestStatus); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.OnFriendStatusUpdated // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnIsMutedUpdated(bool bIsMuted); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.OnIsMutedUpdated // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_AthenaLobbyPlayerPanel(int32_t EntryPoint); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.ExecuteUbergraph_AthenaLobbyPlayerPanel // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
	void OnGadgetsClicked__DelegateSignature(); // Function AthenaLobbyPlayerPanel.AthenaLobbyPlayerPanel_C.OnGadgetsClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
};

