// WidgetBlueprintGeneratedClass AccountLinkingWindow.AccountLinkingWindow_C
// Size: 0x580 (Inherited: 0x580)
struct UAccountLinkingWindow_C : UFortAccountLinkingWindow {
};

