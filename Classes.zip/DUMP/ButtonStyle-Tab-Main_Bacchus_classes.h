// BlueprintGeneratedClass ButtonStyle-Tab-Main_Bacchus.ButtonStyle-Tab-Main_Bacchus_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Tab-Main_Bacchus_C : UButtonStyle-Tab-Main_C {
};

