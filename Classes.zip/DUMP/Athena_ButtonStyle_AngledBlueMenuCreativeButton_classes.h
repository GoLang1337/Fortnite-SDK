// BlueprintGeneratedClass Athena_ButtonStyle_AngledBlueMenuCreativeButton.Athena_ButtonStyle_AngledBlueMenuCreativeButton_C
// Size: 0x570 (Inherited: 0x570)
struct UAthena_ButtonStyle_AngledBlueMenuCreativeButton_C : UCommonButtonStyle {
};

