// BlueprintGeneratedClass BP_AISpawnerComp_Gameplay_Phoebe.BP_AISpawnerComp_Gameplay_Phoebe_C
// Size: 0x448 (Inherited: 0x448)
struct UBP_AISpawnerComp_Gameplay_Phoebe_C : UFortAthenaAISpawnerDataComponent_AIBotGameplay {
};

