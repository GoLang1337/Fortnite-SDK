// BlueprintGeneratedClass ButtonStyle-Solo.ButtonStyle-Solo_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Solo_C : UCommonButtonStyle {
};

