// BlueprintGeneratedClass AISpawnerData_DangerGrape_NoStartingWeapons.AISpawnerData_DangerGrape_NoStartingWeapons_C
// Size: 0xe0 (Inherited: 0xe0)
struct UAISpawnerData_DangerGrape_NoStartingWeapons_C : UBP_AISpawnerData_Phoebe_C {
};

