// BlueprintGeneratedClass Border-PowerToastGlow.Border-PowerToastGlow_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-PowerToastGlow_C : UCommonBorderStyle {
};

