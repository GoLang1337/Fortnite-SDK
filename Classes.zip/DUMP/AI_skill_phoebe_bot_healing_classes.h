// BlueprintGeneratedClass AI_skill_phoebe_bot_healing.AI_skill_phoebe_bot_healing_C
// Size: 0x70 (Inherited: 0x70)
struct UAI_skill_phoebe_bot_healing_C : UFortAthenaAIBotHealingSkillSet {
};

