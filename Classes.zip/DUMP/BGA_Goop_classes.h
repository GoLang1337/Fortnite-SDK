// BlueprintGeneratedClass BGA_Goop.BGA_Goop_C
// Size: 0xb88 (Inherited: 0x998)
struct ABGA_Goop_C : ABGA_Alpaca_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x998(0x08)
	struct UFortAudioShapeBoxComponent* FortAudioShapeBox; // 0x9a0(0x08)
	struct UBoxComponent* Box; // 0x9a8(0x08)
	struct UNiagaraComponent* NS_Biome_Volume_InWorld; // 0x9b0(0x08)
	float InsideSweep_Inside_8FCAC35C485793586ED950B6186BEA1B; // 0x9b8(0x04)
	enum class ETimelineDirection InsideSweep__Direction_8FCAC35C485793586ED950B6186BEA1B; // 0x9bc(0x01)
	char pad_9BD[0x3]; // 0x9bd(0x03)
	struct UTimelineComponent* InsideSweep; // 0x9c0(0x08)
	struct FScalableFloat Row_Size_X; // 0x9c8(0x28)
	struct FScalableFloat Row_Size_Y; // 0x9f0(0x28)
	struct FScalableFloat Row_Size_Z; // 0xa18(0x28)
	struct FScalableFloat Row_SpawnOffset_Z; // 0xa40(0x28)
	struct FB_Goop_Intersection PawnIntersectWorldLocation; // 0xa68(0x18)
	struct FVector Box Extent; // 0xa80(0x0c)
	char pad_A8C[0x4]; // 0xa8c(0x04)
	struct TArray<enum class EObjectTypeQuery> Object Types; // 0xa90(0x10)
	struct UObject* Actor Class Filter; // 0xaa0(0x08)
	struct FScalableFloat Row_MinXYDistanceBetweenBiomes; // 0xaa8(0x28)
	struct FScalableFloat Row_MinZDistanceBetweenBiomes; // 0xad0(0x28)
	bool IsDying; // 0xaf8(0x01)
	char pad_AF9[0x3]; // 0xaf9(0x03)
	float DelayDeletingOverlappingGoopVolumes; // 0xafc(0x04)
	struct FGameplayTagContainer Tags_Parachuting; // 0xb00(0x20)
	struct AAGV_Actor_Goop_C* AGVActor; // 0xb20(0x08)
	struct FGameplayTagContainer Tag_PreventIntersectVFX; // 0xb28(0x20)
	bool IsDynamicTransform; // 0xb48(0x01)
	bool bShouldTestForOtherBiomes; // 0xb49(0x01)
	char pad_B4A[0x6]; // 0xb4a(0x06)
	struct TArray<struct UPrimitiveComponent*> OverlappedStaticMeshComponents; // 0xb50(0x10)
	struct FScalableFloat Row_bSelfDestructIfOverlappingVent; // 0xb60(0x28)

	void UpdateAudioShapeTransform(bool IsDynamicUpdate); // Function BGA_Goop.BGA_Goop_C.UpdateAudioShapeTransform // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	struct FVector GetPawnIntersectLocation(struct ACharacter* Target); // Function BGA_Goop.BGA_Goop_C.GetPawnIntersectLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0xcda090
	void OnRep_PawnIntersectWorldLocation(); // Function BGA_Goop.BGA_Goop_C.OnRep_PawnIntersectWorldLocation // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void RemovePawnEffects(struct AFortPawn* Pawn); // Function BGA_Goop.BGA_Goop_C.RemovePawnEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ApplyPawnEffects(struct AFortPawn* Pawn); // Function BGA_Goop.BGA_Goop_C.ApplyPawnEffects // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void UserConstructionScript(); // Function BGA_Goop.BGA_Goop_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void InsideSweep__FinishedFunc(); // Function BGA_Goop.BGA_Goop_C.InsideSweep__FinishedFunc // (BlueprintEvent) // @ game+0xcda090
	void InsideSweep__UpdateFunc(); // Function BGA_Goop.BGA_Goop_C.InsideSweep__UpdateFunc // (BlueprintEvent) // @ game+0xcda090
	void PlayIntersectEffect(struct FVector Intersect Position, bool ExitingVolume, struct AFortPawn* Pawn); // Function BGA_Goop.BGA_Goop_C.PlayIntersectEffect // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ResetIntersectDoOnce(); // Function BGA_Goop.BGA_Goop_C.ResetIntersectDoOnce // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveBeginPlay(); // Function BGA_Goop.BGA_Goop_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BndEvt__FortAudioShapeBox_K2Node_ComponentBoundEvent_1_OnAudioShapeInsideStateChanged__DelegateSignature(bool bIsInside); // Function BGA_Goop.BGA_Goop_C.BndEvt__FortAudioShapeBox_K2Node_ComponentBoundEvent_1_OnAudioShapeInsideStateChanged__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BGA_Goop.BGA_Goop_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BGA_Goop(int32_t EntryPoint); // Function BGA_Goop.BGA_Goop_C.ExecuteUbergraph_BGA_Goop // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

