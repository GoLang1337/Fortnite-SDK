// WidgetBlueprintGeneratedClass ArenaViewMeTab.ArenaViewMeTab_C
// Size: 0x358 (Inherited: 0x350)
struct UArenaViewMeTab_C : UFortArenaPersonalViewTab {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x350(0x08)

	void Colorize(struct FFortTournamentDisplayInfo ColorInfo); // Function ArenaViewMeTab.ArenaViewMeTab_C.Colorize // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_ArenaViewMeTab(int32_t EntryPoint); // Function ArenaViewMeTab.ArenaViewMeTab_C.ExecuteUbergraph_ArenaViewMeTab // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

