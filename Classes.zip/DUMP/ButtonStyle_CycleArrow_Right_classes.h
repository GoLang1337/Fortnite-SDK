// BlueprintGeneratedClass ButtonStyle_CycleArrow_Right.ButtonStyle_CycleArrow_Right_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_CycleArrow_Right_C : UButtonStyle-MediumTransparentNoCues_C {
};

