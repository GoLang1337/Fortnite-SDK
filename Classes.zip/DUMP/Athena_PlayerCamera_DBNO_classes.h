// BlueprintGeneratedClass Athena_PlayerCamera_DBNO.Athena_PlayerCamera_DBNO_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCamera_DBNO_C : UAthena_PlayerCameraModeBase_C {
};

