// BlueprintGeneratedClass Border-SolidBG-ShellBlue.Border-SolidBG-ShellBlue_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-SolidBG-ShellBlue_C : UBorder-ShellTopBar_C {
};

