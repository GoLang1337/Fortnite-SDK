// BlueprintGeneratedClass ButtonStyle-Outline-FadedBlue.ButtonStyle-Outline-FadedBlue_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Outline-FadedBlue_C : UCommonButtonStyle {
};

