// BlueprintGeneratedClass BP_AISpawnerData_Phoebe.BP_AISpawnerData_Phoebe_C
// Size: 0xe0 (Inherited: 0xe0)
struct UBP_AISpawnerData_Phoebe_C : UFortAthenaAIBotSpawnerData {
};

