// BlueprintGeneratedClass ButtonStyle-Tab-Main-Recolor-Red.ButtonStyle-Tab-Main-Recolor-Red_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Tab-Main-Recolor-Red_C : UCommonButtonStyle {
};

