// BlueprintGeneratedClass Athena_PlayerCameraModeTargetingTethered.Athena_PlayerCameraModeTargetingTethered_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCameraModeTargetingTethered_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

