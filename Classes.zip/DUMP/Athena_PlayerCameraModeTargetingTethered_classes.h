// BlueprintGeneratedClass Athena_PlayerCameraModeTargetingTethered.Athena_PlayerCameraModeTargetingTethered_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeTargetingTethered_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

