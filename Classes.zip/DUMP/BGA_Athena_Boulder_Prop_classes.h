// BlueprintGeneratedClass BGA_Athena_Boulder_Prop.BGA_Athena_Boulder_Prop_C
// Size: 0xd80 (Inherited: 0xd80)
struct ABGA_Athena_Boulder_Prop_C : ABuildingProp {
};

