// BlueprintGeneratedClass BGA_Athena_Boulder_Prop.BGA_Athena_Boulder_Prop_C
// Size: 0xcb8 (Inherited: 0xcb8)
struct ABGA_Athena_Boulder_Prop_C : ABuildingProp {
};

