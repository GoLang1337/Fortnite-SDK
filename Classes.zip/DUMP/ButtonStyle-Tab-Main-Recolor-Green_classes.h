// BlueprintGeneratedClass ButtonStyle-Tab-Main-Recolor-Green.ButtonStyle-Tab-Main-Recolor-Green_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Tab-Main-Recolor-Green_C : UCommonButtonStyle {
};

