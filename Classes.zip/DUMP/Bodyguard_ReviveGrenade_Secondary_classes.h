// BlueprintGeneratedClass Bodyguard_ReviveGrenade_Secondary.Bodyguard_ReviveGrenade_Secondary_C
// Size: 0xe88 (Inherited: 0xe88)
struct UBodyguard_ReviveGrenade_Secondary_C : UGA_Athena_DanceGrenade_Secondary_C {
};

