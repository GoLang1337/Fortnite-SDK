// WidgetBlueprintGeneratedClass BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C
// Size: 0xcd8 (Inherited: 0xc50)
struct UBPS18_HoldableCloseButton_C : UFortHoldableButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc50(0x08)
	struct UWidgetAnimation* Hover; // 0xc58(0x08)
	struct UWidgetAnimation* HoldCompleted; // 0xc60(0x08)
	struct UWidgetAnimation* HoldProgress; // 0xc68(0x08)
	struct UImage* Image_Background; // 0xc70(0x08)
	struct UImage* Image_GamepadProgress; // 0xc78(0x08)
	struct UOverlay* Overlay_input; // 0xc80(0x08)
	struct UProgressBar* ProgressBar_51; // 0xc88(0x08)
	struct USizeBox* SizeBox_Height; // 0xc90(0x08)
	struct USizeBox* SizeBox_KBM; // 0xc98(0x08)
	struct UCommonTextBlock* TextButton_Text; // 0xca0(0x08)
	struct FText In Text; // 0xca8(0x18)
	float In Min Desired Width; // 0xcc0(0x04)
	float In Min Desired Height; // 0xcc4(0x04)
	struct FMulticastInlineDelegate Hold Completed; // 0xcc8(0x10)

	void Update style(bool Using Gamepad); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.Update style // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void UpdateTextAndStyle(enum class ECommonInputType Input Type); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.UpdateTextAndStyle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldStarted(float HoldPercentage, bool bInUseSecondaryHoldAnimation); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.BP_OnHoldStarted // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldEnded(float HoldPercentage, bool bInUseSecondaryHoldAnimation); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.BP_OnHoldEnded // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldCompleted(); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.BP_OnHoldCompleted // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldIncreased(float HoldPercentage); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.BP_OnHoldIncreased // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldDecreased(float HoldPercentage); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.BP_OnHoldDecreased // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHoldReset(); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.BP_OnHoldReset // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnPressed(); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.BP_OnPressed // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void PreConstruct(bool IsDesignTime); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHovered(); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void Construct(); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void Destruct(); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_HoldableCloseButton(int32_t EntryPoint); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.ExecuteUbergraph_BPS18_HoldableCloseButton // (Final|UbergraphFunction) // @ game+0xccddc0
	void Hold Completed__DelegateSignature(); // Function BPS18_HoldableCloseButton.BPS18_HoldableCloseButton_C.Hold Completed__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
};

