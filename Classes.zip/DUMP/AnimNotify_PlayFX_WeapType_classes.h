// BlueprintGeneratedClass AnimNotify_PlayFX_WeapType.AnimNotify_PlayFX_WeapType_C
// Size: 0x60 (Inherited: 0x38)
struct UAnimNotify_PlayFX_WeapType_C : UAnimNotify {
	struct FString Socket; // 0x38(0x10)
	struct FRotator Rotation; // 0x48(0x0c)
	struct FVector Location; // 0x54(0x0c)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_PlayFX_WeapType.AnimNotify_PlayFX_WeapType_C.Received_Notify // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0xcda090
};

