// WidgetBlueprintGeneratedClass AthenaLoadoutTile.AthenaLoadoutTile_C
// Size: 0xc40 (Inherited: 0xc38)
struct UAthenaLoadoutTile_C : UFortCosmeticLoadoutListEntry {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc38(0x08)

	void BP_OnHovered(); // Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnItemSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnEntryReleased(); // Function AthenaLoadoutTile.AthenaLoadoutTile_C.BP_OnEntryReleased // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_AthenaLoadoutTile(int32_t EntryPoint); // Function AthenaLoadoutTile.AthenaLoadoutTile_C.ExecuteUbergraph_AthenaLoadoutTile // (Final|UbergraphFunction) // @ game+0xccddc0
};

