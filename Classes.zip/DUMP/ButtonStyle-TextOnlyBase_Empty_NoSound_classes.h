// BlueprintGeneratedClass ButtonStyle-TextOnlyBase_Empty_NoSound.ButtonStyle-TextOnlyBase_Empty_NoSound_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-TextOnlyBase_Empty_NoSound_C : UButtonStyle-Base_C {
};

