// BlueprintGeneratedClass BP_BattleMapBaseNode.BP_BattleMapBaseNode_C
// Size: 0x358 (Inherited: 0x348)
struct ABP_BattleMapBaseNode_C : ABattleMapNode {
	struct UStaticMeshComponent* StaticMesh; // 0x348(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x350(0x08)
};

