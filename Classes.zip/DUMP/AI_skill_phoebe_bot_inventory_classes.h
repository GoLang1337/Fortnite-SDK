// BlueprintGeneratedClass AI_skill_phoebe_bot_inventory.AI_skill_phoebe_bot_inventory_C
// Size: 0x208 (Inherited: 0x208)
struct UAI_skill_phoebe_bot_inventory_C : UFortAthenaAIBotInventorySkillSet {
};

