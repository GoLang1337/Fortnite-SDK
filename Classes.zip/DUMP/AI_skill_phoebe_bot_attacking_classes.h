// BlueprintGeneratedClass AI_skill_phoebe_bot_attacking.AI_skill_phoebe_bot_attacking_C
// Size: 0x278 (Inherited: 0x278)
struct UAI_skill_phoebe_bot_attacking_C : UFortAthenaAIBotAttackingSkillSet {
};

