// BlueprintGeneratedClass Athena_PlayerCameraModeRanged.Athena_PlayerCameraModeRanged_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeRanged_C : UAthena_PlayerCameraModeBase_C {
};

