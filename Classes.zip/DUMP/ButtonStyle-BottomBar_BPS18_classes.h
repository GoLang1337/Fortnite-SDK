// BlueprintGeneratedClass ButtonStyle-BottomBar_BPS18.ButtonStyle-BottomBar_BPS18_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-BottomBar_BPS18_C : UCommonButtonStyle {
};

