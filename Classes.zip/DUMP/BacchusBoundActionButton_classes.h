// WidgetBlueprintGeneratedClass BacchusBoundActionButton.BacchusBoundActionButton_C
// Size: 0xc48 (Inherited: 0xc28)
struct UBacchusBoundActionButton_C : UBacchusBoundActionButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc28(0x08)
	struct UBorder* ContentBorder; // 0xc30(0x08)
	struct UFortMobileImage* FortMobileImageInputAction; // 0xc38(0x08)
	struct UScaleBox* InputActionIconScale; // 0xc40(0x08)

	void UpdateInputActionIconSize(); // Function BacchusBoundActionButton.BacchusBoundActionButton_C.UpdateInputActionIconSize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnUpdateInputAction(); // Function BacchusBoundActionButton.BacchusBoundActionButton_C.OnUpdateInputAction // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void Construct(); // Function BacchusBoundActionButton.BacchusBoundActionButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BacchusBoundActionButton(int32_t EntryPoint); // Function BacchusBoundActionButton.BacchusBoundActionButton_C.ExecuteUbergraph_BacchusBoundActionButton // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

