// BlueprintGeneratedClass BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C
// Size: 0xba8 (Inherited: 0xb7c)
struct ABP_DeimosRift_Dynamic_C : ABP_DeimosRift_C {
	char pad_B7C[0x4]; // 0xb7c(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb80(0x08)
	float LifeTime; // 0xb88(0x04)
	char pad_B8C[0x4]; // 0xb8c(0x04)
	struct FTimerHandle LifeTimeTimerHandle; // 0xb90(0x08)
	float TimeLastSetLifeTimeTimer; // 0xb98(0x04)
	float ThrottleTime; // 0xb9c(0x04)
	struct UGameplayEffect* GE_LifeTimeLapsed; // 0xba0(0x08)

	void OnRep_ServerSpawnTime(); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.OnRep_ServerSpawnTime // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void UserConstructionScript(); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ReceiveBeginPlay(); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnDamageServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.OnDamageServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xccddc0
	void SetLifeTimeTimer(); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.SetLifeTimeTimer // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void LifetimeExpired(); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.LifetimeExpired // (BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BP_Cosmetic_Intro(); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.BP_Cosmetic_Intro // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_Cosmetic_Idle(); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.BP_Cosmetic_Idle // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_Cosmetic_RampUp(); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.BP_Cosmetic_RampUp // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_Cosmetic_ShouldDie(); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.BP_Cosmetic_ShouldDie // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP_DeimosRift_Dynamic(int32_t EntryPoint); // Function BP_DeimosRift_Dynamic.BP_DeimosRift_Dynamic_C.ExecuteUbergraph_BP_DeimosRift_Dynamic // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

