// BlueprintGeneratedClass BP_BattleMapGroundMoveChestNode.BP_BattleMapGroundMoveChestNode_C
// Size: 0x358 (Inherited: 0x358)
struct ABP_BattleMapGroundMoveChestNode_C : ABP_BattleMapBaseNode_C {
};

