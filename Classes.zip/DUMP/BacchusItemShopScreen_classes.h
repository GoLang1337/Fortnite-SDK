// WidgetBlueprintGeneratedClass BacchusItemShopScreen.BacchusItemShopScreen_C
// Size: 0x630 (Inherited: 0x5f0)
struct UBacchusItemShopScreen_C : UAthenaItemShopScreen {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5f0(0x08)
	struct UCommonBorder* NoOffersBox; // 0x5f8(0x08)
	struct UImage* ProgressSpinner; // 0x600(0x08)
	struct USafeZone* SafeZone_1; // 0x608(0x08)
	struct USafeZone* SafeZone_3; // 0x610(0x08)
	struct USafeZone* SafeZone_4; // 0x618(0x08)
	struct UWidgetSwitcher* Switcher_Sections; // 0x620(0x08)
	struct UVerticalBox* VerticalBox_Sections; // 0x628(0x08)

	void Construct(); // Function BacchusItemShopScreen.BacchusItemShopScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnSectionsEstablished(bool bEmpty); // Function BacchusItemShopScreen.BacchusItemShopScreen_C.OnSectionsEstablished // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void OnEstablishingSections(); // Function BacchusItemShopScreen.BacchusItemShopScreen_C.OnEstablishingSections // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BacchusItemShopScreen(int32_t EntryPoint); // Function BacchusItemShopScreen.BacchusItemShopScreen_C.ExecuteUbergraph_BacchusItemShopScreen // (Final|UbergraphFunction) // @ game+0xcda090
};

