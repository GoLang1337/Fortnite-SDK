// BlueprintGeneratedClass Border_StatRow_WhiteLowOpacity.Border_StatRow_WhiteLowOpacity_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_StatRow_WhiteLowOpacity_C : UCommonBorderStyle {
};

