// BlueprintGeneratedClass Athena_PlayerCameraModeTargetingShotgun.Athena_PlayerCameraModeTargetingShotgun_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeTargetingShotgun_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

