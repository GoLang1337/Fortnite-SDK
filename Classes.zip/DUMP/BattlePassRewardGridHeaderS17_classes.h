// WidgetBlueprintGeneratedClass BattlePassRewardGridHeaderS17.BattlePassRewardGridHeaderS17_C
// Size: 0x2f8 (Inherited: 0x268)
struct UBattlePassRewardGridHeaderS17_C : UFortBattlePassRewardGridHeader {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x268(0x08)
	struct UWidgetAnimation* burst; // 0x270(0x08)
	struct UBorder* Border_Locked; // 0x278(0x08)
	struct UImage* Image; // 0x280(0x08)
	struct UImage* Image_123; // 0x288(0x08)
	struct UImage* Image_Progress; // 0x290(0x08)
	struct UCommonRichTextBlock* PageNumberText; // 0x298(0x08)
	struct UCommonRichTextBlock* RichText_LockDescription; // 0x2a0(0x08)
	struct UCommonVisibilitySwitcher* Switcher_PageState; // 0x2a8(0x08)
	struct UCommonTextBlock* Text_BattlePass; // 0x2b0(0x08)
	struct UCommonRichTextBlock* Text_Progress; // 0x2b8(0x08)
	struct UVerticalBox* VerticalBox_Unlocked; // 0x2c0(0x08)
	struct FText Plural Items; // 0x2c8(0x18)
	struct FText Complete text; // 0x2e0(0x18)

	void OnPageLocked(int32_t RequiredLevel, int32_t RequiredRewards); // Function BattlePassRewardGridHeaderS17.BattlePassRewardGridHeaderS17_C.OnPageLocked // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnPageNumberSet(int32_t InPageNumber); // Function BattlePassRewardGridHeaderS17.BattlePassRewardGridHeaderS17_C.OnPageNumberSet // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnPageUnlocked(int32_t PurchasedRewards, int32_t TotalRewards); // Function BattlePassRewardGridHeaderS17.BattlePassRewardGridHeaderS17_C.OnPageUnlocked // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void OnSetPageType(enum class ERewardPageType PageType); // Function BattlePassRewardGridHeaderS17.BattlePassRewardGridHeaderS17_C.OnSetPageType // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BattlePassRewardGridHeaderS17(int32_t EntryPoint); // Function BattlePassRewardGridHeaderS17.BattlePassRewardGridHeaderS17_C.ExecuteUbergraph_BattlePassRewardGridHeaderS17 // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

