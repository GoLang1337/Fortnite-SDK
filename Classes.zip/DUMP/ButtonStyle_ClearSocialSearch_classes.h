// BlueprintGeneratedClass ButtonStyle_ClearSocialSearch.ButtonStyle_ClearSocialSearch_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_ClearSocialSearch_C : UButtonStyle-MediumTransparentNoCues_C {
};

