// BlueprintGeneratedClass ButtonStyle_Feature_M_Yellow.ButtonStyle_Feature_M_Yellow_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle_Feature_M_Yellow_C : UCommonButtonStyle {
};

