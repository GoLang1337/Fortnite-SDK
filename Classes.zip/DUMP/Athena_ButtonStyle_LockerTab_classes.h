// BlueprintGeneratedClass Athena_ButtonStyle_LockerTab.Athena_ButtonStyle_LockerTab_C
// Size: 0x570 (Inherited: 0x570)
struct UAthena_ButtonStyle_LockerTab_C : UCommonButtonStyle {
};

