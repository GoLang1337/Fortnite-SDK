// BlueprintGeneratedClass BP_Camera_Shake_Pulse_Zoom_Small.BP_Camera_Shake_Pulse_Zoom_Small_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UBP_Camera_Shake_Pulse_Zoom_Small_C : UMatineeCameraShake {
};

