// BlueprintGeneratedClass BP_AISpawnerComp_Affiliation_Phoebe.BP_AISpawnerComp_Affiliation_Phoebe_C
// Size: 0x260 (Inherited: 0x260)
struct UBP_AISpawnerComp_Affiliation_Phoebe_C : UFortAthenaAISpawnerDataComponent_AIBotAffiliation {
};

