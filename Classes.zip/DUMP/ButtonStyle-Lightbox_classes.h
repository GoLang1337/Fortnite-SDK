// BlueprintGeneratedClass ButtonStyle-Lightbox.ButtonStyle-Lightbox_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Lightbox_C : UButtonStyle-Base_C {
};

