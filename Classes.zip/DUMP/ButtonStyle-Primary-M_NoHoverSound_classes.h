// BlueprintGeneratedClass ButtonStyle-Primary-M_NoHoverSound.ButtonStyle-Primary-M_NoHoverSound_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Primary-M_NoHoverSound_C : UCommonButtonStyle {
};

