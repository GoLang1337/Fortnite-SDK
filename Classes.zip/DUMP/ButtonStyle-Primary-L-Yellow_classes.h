// BlueprintGeneratedClass ButtonStyle-Primary-L-Yellow.ButtonStyle-Primary-L-Yellow_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-Primary-L-Yellow_C : UCommonButtonStyle {
};

