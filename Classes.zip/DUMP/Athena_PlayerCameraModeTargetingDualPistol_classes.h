// BlueprintGeneratedClass Athena_PlayerCameraModeTargetingDualPistol.Athena_PlayerCameraModeTargetingDualPistol_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraModeTargetingDualPistol_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

