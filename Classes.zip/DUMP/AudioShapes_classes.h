// Class AudioShapes.AudioShapeComponent
// Size: 0x150 (Inherited: 0xb8)
struct UAudioShapeComponent : UAudioGameplayComponent {
	char pad_B8[0x8]; // 0xb8(0x08)
	float MaxDistanceOffset; // 0xc0(0x04)
	float SmoothingDistance; // 0xc4(0x04)
	float FadeTime; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct FMulticastInlineDelegate OnAudibleStateChanged; // 0xd0(0x10)
	struct TMap<struct FName, struct UAudioComponent*> AudioComponents; // 0xe0(0x50)
	struct TArray<struct APlayerController*> LocalControllers; // 0x130(0x10)
	char pad_140[0x10]; // 0x140(0x10)

	void UpdateAudioShape(struct TArray<struct APlayerController*>& InLocalControllers); // Function AudioShapes.AudioShapeComponent.UpdateAudioShape // (Final|Native|Public|HasOutParms) // @ game+0x428b73c
};

// Class AudioShapes.AudioShapePrimitiveComponent
// Size: 0x1b0 (Inherited: 0x150)
struct UAudioShapePrimitiveComponent : UAudioShapeComponent {
	struct USoundBase* SoundOnEdge; // 0x150(0x08)
	struct USoundBase* SoundOnInside; // 0x158(0x08)
	struct FMulticastInlineDelegate OnInsideStateChanged; // 0x160(0x10)
	bool bUseOwningActorTransform; // 0x170(0x01)
	bool bAutoRefreshShape; // 0x171(0x01)
	char pad_172[0x2]; // 0x172(0x02)
	struct FVector ActorTransformScale; // 0x174(0x0c)
	char pad_180[0x30]; // 0x180(0x30)

	bool GetIsPlayerInside(); // Function AudioShapes.AudioShapePrimitiveComponent.GetIsPlayerInside // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x428b38c
	struct UAudioComponent* GetInsideAudioComponent(); // Function AudioShapes.AudioShapePrimitiveComponent.GetInsideAudioComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x428b368
	struct UAudioComponent* GetEdgeAudioComponent(); // Function AudioShapes.AudioShapePrimitiveComponent.GetEdgeAudioComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x18f9eb8
};

// Class AudioShapes.AudioShapeBoxComponent
// Size: 0x1e0 (Inherited: 0x1b0)
struct UAudioShapeBoxComponent : UAudioShapePrimitiveComponent {
	struct FTransform BoxTransform; // 0x1b0(0x30)

	void SetBoxTransform(struct FTransform& InTransform); // Function AudioShapes.AudioShapeBoxComponent.SetBoxTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x428b3a8
};

// Class AudioShapes.AudioShapeCylinderComponent
// Size: 0x1b8 (Inherited: 0x1b0)
struct UAudioShapeCylinderComponent : UAudioShapePrimitiveComponent {
	float HalfHeight; // 0x1b0(0x04)
	float Radius; // 0x1b4(0x04)

	void SetRadius(float InRadius); // Function AudioShapes.AudioShapeCylinderComponent.SetRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x428b5f0
	void SetHalfHeight(float InHalfHeight); // Function AudioShapes.AudioShapeCylinderComponent.SetHalfHeight // (Final|Native|Public|BlueprintCallable) // @ game+0x428b54c
};

// Class AudioShapes.AudioShapeLineComponent
// Size: 0x1c8 (Inherited: 0x1b0)
struct UAudioShapeLineComponent : UAudioShapePrimitiveComponent {
	struct FVector StartPoint; // 0x1b0(0x0c)
	struct FVector EndPoint; // 0x1bc(0x0c)

	void SetStartPoint(struct FVector& InStartPoint); // Function AudioShapes.AudioShapeLineComponent.SetStartPoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x428b694
	void SetEndPoint(struct FVector& InEndPoint); // Function AudioShapes.AudioShapeLineComponent.SetEndPoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x428b4a4
};

// Class AudioShapes.AudioShapeSphereComponent
// Size: 0x1b8 (Inherited: 0x1b0)
struct UAudioShapeSphereComponent : UAudioShapePrimitiveComponent {
	float Radius; // 0x1b0(0x04)
	char pad_1B4[0x4]; // 0x1b4(0x04)

	void SetRadius(float InRadius); // Function AudioShapes.AudioShapeSphereComponent.SetRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x428b54c
};

// Class AudioShapes.AudioShapeSubsystem
// Size: 0x88 (Inherited: 0x30)
struct UAudioShapeSubsystem : UWorldSubsystem {
	char pad_30[0x28]; // 0x30(0x28)
	struct TArray<struct UAudioShapeComponent*> AudioShapes; // 0x58(0x10)
	struct TArray<struct APlayerController*> LocalControllers; // 0x68(0x10)
	char pad_78[0x10]; // 0x78(0x10)
};

