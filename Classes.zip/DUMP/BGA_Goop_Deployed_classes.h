// BlueprintGeneratedClass BGA_Goop_Deployed.BGA_Goop_Deployed_C
// Size: 0xc00 (Inherited: 0xb88)
struct ABGA_Goop_Deployed_C : ABGA_Goop_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb88(0x08)
	float TransitionInLength; // 0xb90(0x04)
	float TransitionOutLength; // 0xb94(0x04)
	struct FScalableFloat Row_VolumeExpirationWarningDuration; // 0xb98(0x28)
	float MeshZBias; // 0xbc0(0x04)
	struct FActiveGameplayEffectHandle Handle_TrackerGE; // 0xbc4(0x08)
	char pad_BCC[0x4]; // 0xbcc(0x04)
	struct UGameplayEffect* GE_Tracker; // 0xbd0(0x08)
	struct FGameplayTag Tag_GoopTracker; // 0xbd8(0x08)
	struct FGameplayTag EventTag_GoopTracker_AddVolume; // 0xbe0(0x08)
	struct FGameplayTag EventTag_GoopTracker_RemoveVolume; // 0xbe8(0x08)
	struct FGameplayTag EventTag_Goop_KillVolume; // 0xbf0(0x08)
	float DelayParticleEffectAfterFirstSpawn; // 0xbf8(0x04)
	float SpawnTime; // 0xbfc(0x04)

	void OnRep_SpawnTime(); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.OnRep_SpawnTime // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ActivateVisualsExpireWarning(); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.ActivateVisualsExpireWarning // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void TransitionGoopOut(); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.TransitionGoopOut // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void TransitionGoopIn(float TransitionInLength); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.TransitionGoopIn // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void Added_350557D441717B6FB95F66A691D2F0C4(); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.Added_350557D441717B6FB95F66A691D2F0C4 // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void EventReceived_159D2F074BDE4709F32BC89676C674FA(struct FGameplayEventData Payload); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.EventReceived_159D2F074BDE4709F32BC89676C674FA // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveBeginPlay(); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void KillSelf(); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.KillSelf // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void AddTracker(); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.AddTracker // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void OnDeathServer(float Damage, struct FGameplayTagContainer DamageTags, struct FVector Momentum, struct FHitResult HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0xcda090
	void PlaySpawnFX(); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.PlaySpawnFX // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void SetExpireWarningAndTransitionOutTimers(); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.SetExpireWarningAndTransitionOutTimers // (BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void Client Kill Self Cleanup(); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.Client Kill Self Cleanup // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BGA_Goop_Deployed(int32_t EntryPoint); // Function BGA_Goop_Deployed.BGA_Goop_Deployed_C.ExecuteUbergraph_BGA_Goop_Deployed // (Final|UbergraphFunction|HasDefaults) // @ game+0xcda090
};

