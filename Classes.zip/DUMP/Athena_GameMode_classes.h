// BlueprintGeneratedClass Athena_GameMode.Athena_GameMode_C
// Size: 0x1678 (Inherited: 0x1670)
struct AAthena_GameMode_C : AFortGameModeBR {
	struct USceneComponent* DefaultSceneRoot; // 0x1670(0x08)
};

