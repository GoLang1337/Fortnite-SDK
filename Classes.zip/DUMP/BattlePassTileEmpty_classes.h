// WidgetBlueprintGeneratedClass BattlePassTileEmpty.BattlePassTileEmpty_C
// Size: 0xca0 (Inherited: 0xca0)
struct UBattlePassTileEmpty_C : UFortBattlePassTileBase {
};

