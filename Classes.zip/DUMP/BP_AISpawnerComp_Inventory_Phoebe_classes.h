// BlueprintGeneratedClass BP_AISpawnerComp_Inventory_Phoebe.BP_AISpawnerComp_Inventory_Phoebe_C
// Size: 0xc0 (Inherited: 0xc0)
struct UBP_AISpawnerComp_Inventory_Phoebe_C : UFortAthenaAISpawnerDataComponent_AIBotInventory {
};

