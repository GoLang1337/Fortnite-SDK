// WidgetBlueprintGeneratedClass AthenaGenericLobbyViolator.AthenaGenericLobbyViolator_C
// Size: 0x270 (Inherited: 0x260)
struct UAthenaGenericLobbyViolator_C : UUserWidget {
	struct UCommonTextBlock* ModeName; // 0x260(0x08)
	struct UCommonTextBlock* SubText; // 0x268(0x08)

	void SetGamemodeName(struct FText Name, struct FText SubText); // Function AthenaGenericLobbyViolator.AthenaGenericLobbyViolator_C.SetGamemodeName // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
};

