// BlueprintGeneratedClass BP_Valet_AudioController_SedanV4.BP_Valet_AudioController_SedanV4_C
// Size: 0x598 (Inherited: 0x598)
struct ABP_Valet_AudioController_SedanV4_C : ABP_Valet_AudioController_Parent_C {
};

