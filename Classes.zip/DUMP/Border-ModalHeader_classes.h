// BlueprintGeneratedClass Border-ModalHeader.Border-ModalHeader_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-ModalHeader_C : UCommonBorderStyle {
};

