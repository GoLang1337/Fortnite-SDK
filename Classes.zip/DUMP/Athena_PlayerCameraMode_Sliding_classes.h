// BlueprintGeneratedClass Athena_PlayerCameraMode_Sliding.Athena_PlayerCameraMode_Sliding_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCameraMode_Sliding_C : UAthena_PlayerCameraModeBase_C {
};

