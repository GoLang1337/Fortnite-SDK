// BlueprintGeneratedClass Athena_Prop_Bathroom_POI_FlushFactory_ToiletXL.Athena_Prop_Bathroom_POI_FlushFactory_ToiletXL_C
// Size: 0xcb8 (Inherited: 0xcb8)
struct AAthena_Prop_Bathroom_POI_FlushFactory_ToiletXL_C : ABuildingProp {
};

