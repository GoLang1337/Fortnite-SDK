// BlueprintGeneratedClass BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C
// Size: 0x558 (Inherited: 0x528)
struct ABP13_StyleChallenge_Mannequin_C : AFortPlayerMannequin {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x528(0x08)
	struct UCustomCharacterPart* NewPart; // 0x530(0x08)
	struct UNiagaraComponent* ProfPupVFXs; // 0x538(0x08)
	struct UParticleSystemComponent* RacerZeroBody1VFX; // 0x540(0x08)
	struct UParticleSystemComponent* Racer Zero Body2VFX; // 0x548(0x08)
	struct UParticleSystemComponent* Racer Zero Head VFX; // 0x550(0x08)

	void RacerZeroSetup(); // Function BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C.RacerZeroSetup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void ProfPupSetup(); // Function BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C.ProfPupSetup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnVariantChanged(struct FGameplayTag VariantChannel, struct FGameplayTag OldVariantTag, struct FGameplayTag NewVariantTag); // Function BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C.OnVariantChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnPartChanged(struct UCustomCharacterPart* OldPart, struct UCustomCharacterPart* NewPart, enum class EFortCustomPartType PartType); // Function BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C.OnPartChanged // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BP13_StyleChallenge_Mannequin(int32_t EntryPoint); // Function BP13_StyleChallenge_Mannequin.BP13_StyleChallenge_Mannequin_C.ExecuteUbergraph_BP13_StyleChallenge_Mannequin // (Final|UbergraphFunction|HasDefaults) // @ game+0xccddc0
};

