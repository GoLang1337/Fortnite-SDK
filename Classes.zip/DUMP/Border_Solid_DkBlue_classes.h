// BlueprintGeneratedClass Border_Solid_DkBlue.Border_Solid_DkBlue_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_Solid_DkBlue_C : UCommonBorderStyle {
};

