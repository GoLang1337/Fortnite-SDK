// BlueprintGeneratedClass Border-TabM-Solid-White60pc.Border-TabM-Solid-White60pc_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-TabM-Solid-White60pc_C : UBorder-TabM-Solid_C {
};

