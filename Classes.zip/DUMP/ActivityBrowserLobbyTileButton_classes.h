// WidgetBlueprintGeneratedClass ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C
// Size: 0xc9c (Inherited: 0xc58)
struct UActivityBrowserLobbyTileButton_C : UFortActivityLobbyTile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc58(0x08)
	struct UWidgetAnimation* SelectedMatchmaking; // 0xc60(0x08)
	struct UWidgetAnimation* Hover; // 0xc68(0x08)
	struct UHorizontalBox* ButtonPromptHB; // 0xc70(0x08)
	struct UImage* Image_KeyArt; // 0xc78(0x08)
	struct USizeBox* TileSize; // 0xc80(0x08)
	bool IsDisabled; // 0xc88(0x01)
	char pad_C89[0x3]; // 0xc89(0x03)
	struct FName KeyArtParameter; // 0xc8c(0x08)
	struct FName MissingArtParameter; // 0xc94(0x08)

	void OnUnSelectedMatchmakingCanceled(); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.OnUnSelectedMatchmakingCanceled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void OnSelectedMatchmaking(); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.OnSelectedMatchmaking // (Public|BlueprintCallable|BlueprintEvent) // @ game+0xccddc0
	void BP_OnClicked(); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.BP_OnClicked // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnUnhovered(); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnHovered(); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnSelected(); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnDeselected(); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnDisabled(); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.BP_OnDisabled // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BP_OnEnabled(); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.BP_OnEnabled // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_ActivityBrowserLobbyTileButton(int32_t EntryPoint); // Function ActivityBrowserLobbyTileButton.ActivityBrowserLobbyTileButton_C.ExecuteUbergraph_ActivityBrowserLobbyTileButton // (Final|UbergraphFunction) // @ game+0xccddc0
};

