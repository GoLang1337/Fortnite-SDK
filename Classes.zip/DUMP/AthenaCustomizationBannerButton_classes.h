// WidgetBlueprintGeneratedClass AthenaCustomizationBannerButton.AthenaCustomizationBannerButton_C
// Size: 0xc30 (Inherited: 0xc28)
struct UAthenaCustomizationBannerButton_C : UFortBannerSlotButton {
	struct UNormalBangWrapper_C* NormalBangWrapper; // 0xc28(0x08)
};

