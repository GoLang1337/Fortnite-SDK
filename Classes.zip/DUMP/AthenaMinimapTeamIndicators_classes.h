// BlueprintGeneratedClass AthenaMinimapTeamIndicators.AthenaMinimapTeamIndicators_C
// Size: 0x590 (Inherited: 0x590)
struct UAthenaMinimapTeamIndicators_C : UFortMiniMapTeamIndicators {
};

