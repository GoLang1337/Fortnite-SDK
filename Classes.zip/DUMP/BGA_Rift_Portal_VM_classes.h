// BlueprintGeneratedClass BGA_Rift_Portal_VM.BGA_Rift_Portal_VM_C
// Size: 0xaf0 (Inherited: 0xaf0)
struct ABGA_Rift_Portal_VM_C : ABGA_RiftPortal_Item_Athena_C {
};

