// BlueprintGeneratedClass BPS18_AboutModal_Decorator.BPS18_AboutModal_Decorator_C
// Size: 0x30 (Inherited: 0x30)
struct UBPS18_AboutModal_Decorator_C : URichTextBlockImageDecorator {
};

