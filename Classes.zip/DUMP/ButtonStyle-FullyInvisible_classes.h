// BlueprintGeneratedClass ButtonStyle-FullyInvisible.ButtonStyle-FullyInvisible_C
// Size: 0x570 (Inherited: 0x570)
struct UButtonStyle-FullyInvisible_C : UCommonButtonStyle {
};

