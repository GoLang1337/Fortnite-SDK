// BlueprintGeneratedClass Border-SolidBG-StatItem.Border-SolidBG-StatItem_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-SolidBG-StatItem_C : UBorder-ShellTopBar_C {
};

