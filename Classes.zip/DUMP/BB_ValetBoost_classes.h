// BlueprintGeneratedClass BB_ValetBoost.BB_ValetBoost_C
// Size: 0x100 (Inherited: 0x100)
struct UBB_ValetBoost_C : UFortMobileActionButtonBehavior_ValetBoost {
};

