// BlueprintGeneratedClass BP_BattleMapZoneNode.BP_BattleMapZoneNode_C
// Size: 0x360 (Inherited: 0x358)
struct ABP_BattleMapZoneNode_C : ABP_BattleMapBaseNode_C {
	struct UStaticMeshComponent* StaticMesh_Inverted; // 0x358(0x08)
};

