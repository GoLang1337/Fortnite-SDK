// WidgetBlueprintGeneratedClass BPS18_LobbySeasonalResources.BPS18_LobbySeasonalResources_C
// Size: 0x300 (Inherited: 0x2d0)
struct UBPS18_LobbySeasonalResources_C : UFortBattlePassResourcesWidgetS18 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct UAthenaGlobalCashHorizontal_C* AthenaGlobalCashHorizontal; // 0x2d8(0x08)
	struct UImage* Image; // 0x2e0(0x08)
	struct UImage* Image_2; // 0x2e8(0x08)
	struct UMoreInfo_Ressources_Button_C* MoreInfo_Ressources_Button_68; // 0x2f0(0x08)
	struct UMoreInfo_Ressources_MobileButton_C* MoreInfo_Ressources_MobileButton_20; // 0x2f8(0x08)

	void OnStylePointsRewardsSet(int32_t Rewards); // Function BPS18_LobbySeasonalResources.BPS18_LobbySeasonalResources_C.OnStylePointsRewardsSet // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void OnBattleStarRewardsSet(int32_t Rewards); // Function BPS18_LobbySeasonalResources.BPS18_LobbySeasonalResources_C.OnBattleStarRewardsSet // (Event|Protected|BlueprintEvent) // @ game+0xccddc0
	void BndEvt__MoreInfo_Ressources_Button_67_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function BPS18_LobbySeasonalResources.BPS18_LobbySeasonalResources_C.BndEvt__MoreInfo_Ressources_Button_67_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void BndEvt__MoreInfo_Ressources_MobileButton_19_K2Node_ComponentBoundEvent_2_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function BPS18_LobbySeasonalResources.BPS18_LobbySeasonalResources_C.BndEvt__MoreInfo_Ressources_MobileButton_19_K2Node_ComponentBoundEvent_2_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0xccddc0
	void ExecuteUbergraph_BPS18_LobbySeasonalResources(int32_t EntryPoint); // Function BPS18_LobbySeasonalResources.BPS18_LobbySeasonalResources_C.ExecuteUbergraph_BPS18_LobbySeasonalResources // (Final|UbergraphFunction) // @ game+0xccddc0
};

