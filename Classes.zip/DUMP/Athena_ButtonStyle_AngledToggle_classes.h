// BlueprintGeneratedClass Athena_ButtonStyle_AngledToggle.Athena_ButtonStyle_AngledToggle_C
// Size: 0x570 (Inherited: 0x570)
struct UAthena_ButtonStyle_AngledToggle_C : UCommonButtonStyle {
};

