// WidgetBlueprintGeneratedClass AthenaItemShopOfferStyleScreen.AthenaItemShopOfferStyleScreen_C
// Size: 0x500 (Inherited: 0x4c8)
struct UAthenaItemShopOfferStyleScreen_C : UAthenaItemShopOfferStyleScreen {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4c8(0x08)
	struct UCloseButton_C* CloseButton; // 0x4d0(0x08)
	bool OfferSet; // 0x4d8(0x01)
	char pad_4D9[0x3]; // 0x4d9(0x03)
	int32_t IndexIntoOffersWithVariantsList; // 0x4dc(0x04)
	struct TArray<int32_t> OfferSubIndicesWithVariants; // 0x4e0(0x10)
	struct UFortItemDefinition* InitialTriggeringItemDef; // 0x4f0(0x08)
	struct UFortItem* CharacterItem_1; // 0x4f8(0x08)

	void HandleBack(bool bPassThrough); // Function AthenaItemShopOfferStyleScreen.AthenaItemShopOfferStyleScreen_C.HandleBack // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BndEvt__CloseButton_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature(struct UCommonButtonLegacy* Button); // Function AthenaItemShopOfferStyleScreen.AthenaItemShopOfferStyleScreen_C.BndEvt__CloseButton_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0xcda090
	void HandleBackAction(); // Function AthenaItemShopOfferStyleScreen.AthenaItemShopOfferStyleScreen_C.HandleBackAction // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_AthenaItemShopOfferStyleScreen(int32_t EntryPoint); // Function AthenaItemShopOfferStyleScreen.AthenaItemShopOfferStyleScreen_C.ExecuteUbergraph_AthenaItemShopOfferStyleScreen // (Final|UbergraphFunction) // @ game+0xcda090
};

