// BlueprintGeneratedClass Border-SolidBG-DkBlue.Border-SolidBG-DkBlue_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-SolidBG-DkBlue_C : UCommonBorderStyle {
};

