// WidgetBlueprintGeneratedClass BacchusItemShopNavigationButton.BacchusItemShopNavigationButton_C
// Size: 0xc7a (Inherited: 0xc30)
struct UBacchusItemShopNavigationButton_C : UAthenaItemShopNavigationButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc30(0x08)
	struct UWidgetAnimation* FadeOutBacking; // 0xc38(0x08)
	struct UWidgetAnimation* Translate_Bottom; // 0xc40(0x08)
	struct UWidgetAnimation* Translate_Top; // 0xc48(0x08)
	struct UWidgetAnimation* InitialState; // 0xc50(0x08)
	struct UImage* Backing; // 0xc58(0x08)
	struct UBorder* BorderButton; // 0xc60(0x08)
	struct UBorder* GridBoundBorder; // 0xc68(0x08)
	struct UImage* IMG_Arrow; // 0xc70(0x08)
	bool bFlipArrow; // 0xc78(0x01)
	bool bIsTop; // 0xc79(0x01)

	void PreConstruct(bool IsDesignTime); // Function BacchusItemShopNavigationButton.BacchusItemShopNavigationButton_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0xcda090
	void BP_OnHovered(); // Function BacchusItemShopNavigationButton.BacchusItemShopNavigationButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void BP_OnUnhovered(); // Function BacchusItemShopNavigationButton.BacchusItemShopNavigationButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_BacchusItemShopNavigationButton(int32_t EntryPoint); // Function BacchusItemShopNavigationButton.BacchusItemShopNavigationButton_C.ExecuteUbergraph_BacchusItemShopNavigationButton // (Final|UbergraphFunction) // @ game+0xcda090
};

