// BlueprintGeneratedClass Border_LightNavy_VGrad.Border_LightNavy_VGrad_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder_LightNavy_VGrad_C : UCommonBorderStyle {
};

