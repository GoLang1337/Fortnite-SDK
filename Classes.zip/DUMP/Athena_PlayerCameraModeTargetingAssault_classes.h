// BlueprintGeneratedClass Athena_PlayerCameraModeTargetingAssault.Athena_PlayerCameraModeTargetingAssault_C
// Size: 0xde0 (Inherited: 0xde0)
struct UAthena_PlayerCameraModeTargetingAssault_C : UAthena_PlayerCameraModeRangedTargeting_C {
};

