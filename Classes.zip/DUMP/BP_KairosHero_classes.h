// BlueprintGeneratedClass BP_KairosHero.BP_KairosHero_C
// Size: 0x258 (Inherited: 0x250)
struct ABP_KairosHero_C : AKairosHeroBase {
	struct USceneCaptureComponent2D* SceneCaptureComponent2D_AA; // 0x250(0x08)
};

