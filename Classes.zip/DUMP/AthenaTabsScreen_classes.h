// WidgetBlueprintGeneratedClass AthenaTabsScreen.AthenaTabsScreen_C
// Size: 0x380 (Inherited: 0x370)
struct UAthenaTabsScreen_C : UFortAthenaTabsScreenBase {
	struct UItemShopScreen_C* CatabaScreen; // 0x370(0x08)
	struct USafeZone* SafeZoneContent; // 0x378(0x08)
};

