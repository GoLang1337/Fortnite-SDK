// WidgetBlueprintGeneratedClass AthenaTabsScreen.AthenaTabsScreen_C
// Size: 0x390 (Inherited: 0x380)
struct UAthenaTabsScreen_C : UFortAthenaTabsScreenBase {
	struct UItemShopScreen_C* CatabaScreen; // 0x380(0x08)
	struct USafeZone* SafeZoneContent; // 0x388(0x08)
};

