// BlueprintGeneratedClass Athena_PlayerCameraMode_HeldObject.Athena_PlayerCameraMode_HeldObject_C
// Size: 0xdd0 (Inherited: 0xdd0)
struct UAthena_PlayerCameraMode_HeldObject_C : UAthena_PlayerCameraModeRanged_C {
};

