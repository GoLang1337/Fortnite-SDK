// BlueprintGeneratedClass BP_BattleMapPawnReplay.BP_BattleMapPawnReplay_C
// Size: 0x598 (Inherited: 0x598)
struct ABP_BattleMapPawnReplay_C : ABattleMapPawnReplay {
};

