// AnimBlueprintGeneratedClass AnimBP_FlintLock_Pistol.AnimBP_FlintLock_Pistol_C
// Size: 0x661 (Inherited: 0x2c0)
struct UAnimBP_FlintLock_Pistol_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2c8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot_2; // 0x2f8(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x340(0x80)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x3c0(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0x518(0x28)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum; // 0x540(0xb0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x5f0(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x618(0x48)
	enum class EFortCustomGender Gender; // 0x660(0x01)

	void AnimGraph(struct FPoseLink AnimGraph); // Function AnimBP_FlintLock_Pistol.AnimBP_FlintLock_Pistol_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function AnimBP_FlintLock_Pistol.AnimBP_FlintLock_Pistol_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0xcda090
	void ExecuteUbergraph_AnimBP_FlintLock_Pistol(int32_t EntryPoint); // Function AnimBP_FlintLock_Pistol.AnimBP_FlintLock_Pistol_C.ExecuteUbergraph_AnimBP_FlintLock_Pistol // (Final|UbergraphFunction) // @ game+0xcda090
};

