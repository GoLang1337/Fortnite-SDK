// BlueprintGeneratedClass Athena_ButtonStyle_ChallengesTab.Athena_ButtonStyle_ChallengesTab_C
// Size: 0x570 (Inherited: 0x570)
struct UAthena_ButtonStyle_ChallengesTab_C : UCommonButtonStyle {
};

