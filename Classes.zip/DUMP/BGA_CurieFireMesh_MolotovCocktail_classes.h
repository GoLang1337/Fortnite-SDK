// BlueprintGeneratedClass BGA_CurieFireMesh_MolotovCocktail.BGA_CurieFireMesh_MolotovCocktail_C
// Size: 0x948 (Inherited: 0x920)
struct ABGA_CurieFireMesh_MolotovCocktail_C : ABGA_GenericCurieFuel_Parent_C {
	struct FScalableFloat SelfPropagationFuelRowValue; // 0x920(0x28)

	void UserConstructionScript(); // Function BGA_CurieFireMesh_MolotovCocktail.BGA_CurieFireMesh_MolotovCocktail_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xcda090
};

