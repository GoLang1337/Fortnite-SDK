// BlueprintGeneratedClass Border-SolidBG.Border-SolidBG_C
// Size: 0xb0 (Inherited: 0xb0)
struct UBorder-SolidBG_C : UBorder-ShellTopBar_C {
};

